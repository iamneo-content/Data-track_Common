from pyspark.sql import SparkSession

def main():
    # Initialize Spark with Hive support
    spark = (
        SparkSession.builder
        .appName("SparkHiveIntegrationDemo")
        .enableHiveSupport()
        .config("spark.sql.warehouse.dir", "/user/hive/warehouse")
        .config("hive.metastore.uris", "thrift://127.0.0.1:9083")
        .getOrCreate()
    )

    print("\n=== SparkSession with Hive Support Initialized ===")
    print(f"Current Databases in Hive:")
    spark.sql("SHOW DATABASES").show()

    # Use default database
    spark.sql("USE default")

    # Drop old table if exists
    spark.sql("DROP TABLE IF EXISTS employees")

    # Create Hive table
    print("\n=== Creating Hive Table 'employees' ===")
    spark.sql("""
        CREATE TABLE employees (
            emp_id INT,
            emp_name STRING,
            department STRING,
            salary DOUBLE
        )
        STORED AS PARQUET
    """)

    # Insert some records
    print("\n=== Inserting Records ===")
    spark.sql("""
        INSERT INTO employees VALUES
        (101, 'Arjun', 'IT', 80000.0),
        (102, 'Beena', 'HR', 65000.0),
        (103, 'Chirag', 'Finance', 70000.0),
        (104, 'Diya', 'IT', 90000.0)
    """)

    # Query the Hive table
    print("\n=== Query Results: Employees from IT Department ===")
    result_df = spark.sql("""
        SELECT emp_id, emp_name, salary
        FROM employees
        WHERE department = 'IT'
    """)
    result_df.show()

    # Save result to Hive as new table
    print("\n=== Creating Derived Table: high_paid_employees ===")
    result_df.write.mode("overwrite").saveAsTable("high_paid_employees")

    print("\n=== Verify Derived Table ===")
    spark.sql("SHOW TABLES").show()
    spark.sql("SELECT * FROM high_paid_employees").show()

    spark.stop()


if __name__ == "__main__":
    main()
