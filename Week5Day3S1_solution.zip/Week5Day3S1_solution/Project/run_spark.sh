#!/bin/bash
echo " Configuring Spark log suppression..."
mkdir -p $SPARK_HOME/conf
cat > $SPARK_HOME/conf/log4j2.properties <<'EOF'
status = error
appender.console.type = Console
appender.console.name = console
appender.console.target = SYSTEM_ERR
appender.console.layout.type = PatternLayout
appender.console.layout.pattern = %m%n
rootLogger.level = error
rootLogger.appenderRefs = console
rootLogger.appenderRef.console.ref = console
EOF

hdfs dfs -rm -r -f /user/hive/warehouse/*
hdfs dfs -rm -r -f /tmp/*

echo " Running Spark job..."
$SPARK_HOME/bin/spark-submit \
  --master local[*] \
  --conf "spark.driver.extraJavaOptions=-Dlog4j.configurationFile=$SPARK_HOME/conf/log4j2.properties" \
  --conf spark.eventLog.enabled=false \
  solution.py
