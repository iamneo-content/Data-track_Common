#!/bin/sh
set -e

echo "[HDFS] Starting NameNode/DataNode/SecondaryNameNode..."
hdfs --daemon start namenode          || true
hdfs --daemon start datanode          || true
hdfs --daemon start secondarynamenode || true

echo "[YARN] Starting ResourceManager/NodeManager..."
yarn --daemon start resourcemanager   || true
yarn --daemon start nodemanager       || true

# Wait for HDFS to accept RPCs
echo "[HDFS] Waiting for NameNode RPC on 9000..."
for i in 1 2 3 4 5 6 7 8 9 10; do
  hdfs dfs -ls / >/dev/null 2>&1 && break
  sleep 1
done
hdfs dfs -ls / >/dev/null 2>&1 || { echo "✗ HDFS not responding"; exit 1; }

echo "[HDFS] Ensuring warehouse and tmp dirs..."
hdfs dfs -mkdir -p /user/hive/warehouse || true
hdfs dfs -chmod -R 775 /user/hive/warehouse || true
hdfs dfs -mkdir -p /tmp || true
hdfs dfs -chmod -R 1777 /tmp || true

echo "✓ HDFS/YARN up. UIs (if exposed): NameNode 9870, YARN 8088"
