#!/bin/bash
echo " Starting Hive Metastore..."
/opt/hive/bin/hive --hiveconf hive.metastore.uris=thrift://127.0.0.1:9083 \
  --hiveconf javax.jdo.option.ConnectionURL="jdbc:mysql://127.0.0.1:3306/metastore?allowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC" \
  --hiveconf javax.jdo.option.ConnectionDriverName=com.mysql.cj.jdbc.Driver \
  --hiveconf javax.jdo.option.ConnectionUserName=root \
  --hiveconf javax.jdo.option.ConnectionPassword=examly \
  --hiveconf hive.metastore.warehouse.dir=/user/hive/warehouse \
  --service metastore
