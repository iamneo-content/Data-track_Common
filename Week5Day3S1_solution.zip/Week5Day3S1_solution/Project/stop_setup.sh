#!/bin/bash
set -e
echo "=========================================="
echo "CLEAN SHUTDOWN: HDFS → YARN → HIVE"
echo "=========================================="

# Stop Spark (if any running jobs)
echo "[Spark] Killing all spark-submit processes..."
pkill -f 'org.apache.spark.deploy.SparkSubmit' 2>/dev/null || true
pkill -f 'spark-submit' 2>/dev/null || true

# Stop HiveServer2 and Metastore
echo "[Hive] Stopping HiveServer2 and Metastore..."
pkill -f 'hiveserver2' 2>/dev/null || true
pkill -f 'HiveMetaStore' 2>/dev/null || true
sleep 3

# Stop YARN daemons
echo "[YARN] Stopping ResourceManager and NodeManager..."
yarn --daemon stop resourcemanager || true
yarn --daemon stop nodemanager || true

# Stop HDFS daemons
echo "[HDFS] Stopping NameNode, DataNode, and SecondaryNameNode..."
hdfs --daemon stop namenode || true
hdfs --daemon stop datanode || true
hdfs --daemon stop secondarynamenode || true

# Kill leftover Java/Hadoop daemons if still running
echo "[Cleanup] Killing any leftover Java daemons..."
pkill -f 'org.apache.hadoop.hdfs.server' 2>/dev/null || true
pkill -f 'org.apache.hadoop.yarn.server' 2>/dev/null || true

# Check if all ports are cleared
echo "[Check] Active ports for Hive or HDFS:"
ss -lntp | grep -E '9083|10000|9000' || echo " All key ports free (9083, 10000, 9000)"

echo "=========================================="
echo " CLEAN SHUTDOWN COMPLETE"
echo "=========================================="
