from pyspark.sql import SparkSession

DATABASE_NAME = "employee_db"
SOURCE_TABLE = "employee_records"
SUMMARY_TABLE = "department_summary"
TOP_EARNER_TABLE = "top_earners"

def main():
    """
    Analyze employee salary data from Hive using Spark SQL.
    Generates department-level summaries and top-earner reports.
    """
    spark = (
        SparkSession.builder
        .appName("EmployeeAnalytics")
        .enableHiveSupport()
        .config("spark.sql.warehouse.dir", "/user/hive/warehouse")
        .config("hive.metastore.uris", "thrift://127.0.0.1:9083")
        .getOrCreate()
    )

    spark.sql(f"USE {DATABASE_NAME}")

    # Department-wise salary summary
    print("\n=== Department Salary Summary ===")
    summary_df = spark.sql(f"""
        SELECT
            department,
            ROUND(AVG(salary), 2) AS average_salary,
            COUNT(*) AS employee_count,
            ROUND(SUM(salary), 2) AS total_salary
        FROM {SOURCE_TABLE}
        GROUP BY department
        ORDER BY average_salary DESC
    """)
    summary_df.show()
    summary_df.write.mode("overwrite").saveAsTable(SUMMARY_TABLE)

    # Identify top earner in each department
    print("\n=== Top Earner per Department ===")
    top_df = spark.sql(f"""
        SELECT e.department, e.emp_id, e.emp_name, e.salary
        FROM {SOURCE_TABLE} e
        JOIN (
            SELECT department, MAX(salary) AS max_salary
            FROM {SOURCE_TABLE}
            GROUP BY department
        ) t
        ON e.department = t.department AND e.salary = t.max_salary
        ORDER BY e.department
    """)
    top_df.show()
    top_df.write.mode("overwrite").saveAsTable(TOP_EARNER_TABLE)

    print("\n=== Hive Tables in Database ===")
    spark.sql("SHOW TABLES").show()

    spark.stop()

if __name__ == "__main__":
    main()
