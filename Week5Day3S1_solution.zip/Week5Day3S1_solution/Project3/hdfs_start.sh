#!/bin/sh
set -e

echo "[HDFS] Starting NameNode/DataNode/SecondaryNameNode..."
hdfs --daemon start namenode          || true
hdfs --daemon start datanode          || true
hdfs --daemon start secondarynamenode || true

echo "[YARN] Starting ResourceManager/NodeManager..."
yarn --daemon start resourcemanager   || true
yarn --daemon start nodemanager       || true

# Wait for HDFS RPCs to be available
echo "[HDFS] Waiting for HDFS to become available..."
i=0
while [ $i -lt 20 ]; do
  if hdfs dfs -ls / >/dev/null 2>&1; then
    break
  fi
  i=$((i+1))
  sleep 1
done
hdfs dfs -ls / >/dev/null 2>&1 || { echo "[HDFS] Not responding after timeout"; exit 1; }

echo "[HDFS] Ensuring standard directories and permissions..."
# HDFS user home (useful for Hive scratch paths)
hdfs dfs -mkdir -p "/user/$(whoami)" || true
hdfs dfs -chmod 755 "/user/$(whoami)" || true

# Hive warehouse and tmp
hdfs dfs -mkdir -p /user/hive/warehouse || true
hdfs dfs -chmod -R 775 /user/hive/warehouse || true
hdfs dfs -mkdir -p /tmp || true
hdfs dfs -chmod -R 1777 /tmp || true

# Local Spark event log dir to prevent startup errors when event logging is enabled
echo "[Local] Ensuring /tmp/spark-events exists..."
mkdir -p /tmp/spark-events
chmod 1777 /tmp /tmp/spark-events 2>/dev/null || true

echo "[OK] HDFS and YARN are up."
echo "     UIs (if exposed): NameNode 9870, YARN 8088"
