#!/bin/bash
set -e

echo "Configuring Spark log suppression..."
mkdir -p "$SPARK_HOME/conf"

cat > "$SPARK_HOME/conf/log4j2.properties" <<'EOF'
status = error
appender.console.type = Console
appender.console.name = console
appender.console.target = SYSTEM_ERR
appender.console.layout.type = PatternLayout
appender.console.layout.pattern = %m%n
rootLogger.level = error
rootLogger.appenderRefs = console
rootLogger.appenderRef.console.ref = console
EOF

echo "Cleaning HDFS warehouse and temp directories..."
hdfs dfs -rm -r -f /user/hive/warehouse/* || true
hdfs dfs -rm -r -f /tmp/* || true

echo " Initializing Hive database and loading data..."
"$SPARK_HOME/bin/spark-submit" \
  --master local[*] \
  --conf "spark.driver.extraJavaOptions=-Dlog4j.configurationFile=$SPARK_HOME/conf/log4j2.properties" \
  --conf spark.eventLog.enabled=false \
  database.py

echo " Running Spark SQL analysis..."
"$SPARK_HOME/bin/spark-submit" \
  --master local[*] \
  --conf "spark.driver.extraJavaOptions=-Dlog4j.configurationFile=$SPARK_HOME/conf/log4j2.properties" \
  --conf spark.eventLog.enabled=false \
  solution.py

echo " Spark job completed successfully."
