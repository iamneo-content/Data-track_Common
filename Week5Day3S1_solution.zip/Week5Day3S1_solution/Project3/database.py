from pyspark.sql import SparkSession

DATABASE_NAME = "employee_db"
TABLE_NAME = "employee_records"

def main():
    """
    Initialize Hive database and populate the base employee table.
    This script prepares data for subsequent Spark SQL exercises.
    """
    spark = (
        SparkSession.builder
        .appName("EmployeeDataInitializer")
        .enableHiveSupport()
        .config("spark.sql.warehouse.dir", "/user/hive/warehouse")
        .config("hive.metastore.uris", "thrift://127.0.0.1:9083")
        .getOrCreate()
    )

    # Create database and table
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {DATABASE_NAME}")
    spark.sql(f"USE {DATABASE_NAME}")
    spark.sql(f"DROP TABLE IF EXISTS {TABLE_NAME}")

    spark.sql(f"""
        CREATE TABLE {TABLE_NAME} (
            emp_id INT,
            emp_name STRING,
            department STRING,
            designation STRING,
            salary DOUBLE,
            experience_years INT
        )
        STORED AS PARQUET
    """)

    # Insert realistic employee data
    spark.sql(f"""
        INSERT INTO {TABLE_NAME} VALUES
        (101, 'Arjun',  'IT', 'Software Engineer',        80000.0, 3),
        (102, 'Beena',  'HR', 'HR Executive',             65000.0, 4),
        (103, 'Chirag', 'Finance', 'Accountant',          70000.0, 5),
        (104, 'Diya',   'IT', 'Senior Developer',         90000.0, 6),
        (105, 'Esha',   'Finance', 'Financial Analyst',   72000.0, 3),
        (106, 'Farah',  'HR', 'HR Specialist',            68000.0, 5),
        (107, 'Gaurav', 'Sales', 'Sales Executive',       61000.0, 4),
        (108, 'Hari',   'Sales', 'Sales Manager',         78000.0, 7),
        (109, 'Indira', 'IT', 'Data Engineer',            95000.0, 6),
        (110, 'Jay',    'IT', 'DevOps Engineer',          87000.0, 5),
        (111, 'Kiran',  'Finance', 'Senior Accountant',   83000.0, 8),
        (112, 'Leena',  'Marketing', 'Digital Strategist',68000.0, 3),
        (113, 'Manoj',  'Marketing', 'Content Lead',      72000.0, 4),
        (114, 'Nisha',  'Sales', 'Sales Coordinator',     64000.0, 2),
        (115, 'Omkar',  'IT', 'Data Analyst',             75000.0, 3),
        (116, 'Pooja',  'HR', 'Talent Acquisition Lead',  85000.0, 7),
        (117, 'Qasim',  'Finance', 'Auditor',             79000.0, 6),
        (118, 'Ravi',   'Operations', 'Operations Lead',  82000.0, 8),
        (119, 'Sneha',  'Operations', 'Process Manager',  87000.0, 9),
        (120, 'Tanya',  'IT', 'Backend Developer',        88000.0, 5),
        (121, 'Usha',   'Finance', 'Tax Consultant',      76000.0, 4),
        (122, 'Vijay',  'Sales', 'Regional Manager',      91000.0, 10),
        (123, 'Wasim',  'IT', 'AI Specialist',           105000.0, 7),
        (124, 'Xavier', 'IT', 'Cloud Engineer',           95000.0, 6),
        (125, 'Yamini', 'Marketing', 'Campaign Manager',  88000.0, 8),
        (126, 'Zara',   'Finance', 'Investment Analyst',  97000.0, 9),
        (127, 'Akhil',  'Operations', 'Logistics Lead',   80000.0, 6),
        (128, 'Bhavna', 'IT', 'UI/UX Designer',           73000.0, 4),
        (129, 'Chetan', 'Sales', 'Business Executive',    67000.0, 5),
        (130, 'Deepa',  'Marketing', 'Brand Consultant',  78000.0, 5)
    """)

    print("\nEmployee data successfully inserted into Hive.")
    spark.sql(f"SELECT * FROM {TABLE_NAME} ORDER BY emp_id").show(10, truncate=False)

    spark.stop()

if __name__ == "__main__":
    main()
