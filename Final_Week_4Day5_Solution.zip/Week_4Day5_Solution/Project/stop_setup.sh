#!/bin/sh

# Stop YARN
yarn --daemon stop nodemanager
yarn --daemon stop resourcemanager

# Stop HDFS
hdfs --daemon stop datanode
hdfs --daemon stop secondarynamenode
hdfs --daemon stop namenode

# Optionally stop Hive services if you started them
pkill -f 'hive.*metastore' 2>/dev/null || true
pkill -f 'hive.*hiveserver2' 2>/dev/null || true
