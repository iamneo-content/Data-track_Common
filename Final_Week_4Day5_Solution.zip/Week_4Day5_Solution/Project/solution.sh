#!/bin/sh

# Metastore init (safe to re-run; will no-op if already initialized)
schematool -dbType mysql -initSchema \
  --userName root --passWord examly \
  --url "jdbc:mysql://127.0.0.1:3306/metastore?createDatabaseIfNotExist=true" >/tmp/hms_init.out 2>&1 || true

# Hive SQL
hive -e "
CREATE DATABASE IF NOT EXISTS training;
USE training;

DROP TABLE IF EXISTS users_managed;
CREATE TABLE users_managed (
  user_id INT, name STRING, age INT, region STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
TBLPROPERTIES('skip.header.line.count'='1');

LOAD DATA LOCAL INPATH 'users.csv' INTO TABLE users_managed;

SELECT * FROM users_managed;
SELECT region, COUNT(*) AS cnt FROM users_managed GROUP BY region ORDER BY region;
"
