#!/bin/sh

# --- Fix MapReduce (MRAppMaster) classpath + YARN shuffle ---
sudo tee /opt/hadoop/etc/hadoop/mapred-site.xml >/dev/null <<'XML'
<?xml version="1.0"?>
<configuration>
  <property>
    <name>mapreduce.framework.name</name>
    <value>yarn</value>
  </property>

  <!-- Ensure AM and tasks see Hadoop MR jars -->
  <property>
    <name>yarn.app.mapreduce.am.env</name>
    <value>HADOOP_MAPRED_HOME=/opt/hadoop</value>
  </property>
  <property>
    <name>mapreduce.map.env</name>
    <value>HADOOP_MAPRED_HOME=/opt/hadoop</value>
  </property>
  <property>
    <name>mapreduce.reduce.env</name>
    <value>HADOOP_MAPRED_HOME=/opt/hadoop</value>
  </property>

  <!-- Full MR classpath used by containers -->
  <property>
    <name>mapreduce.application.classpath</name>
    <value>
/opt/hadoop/share/hadoop/mapreduce/*,
/opt/hadoop/share/hadoop/mapreduce/lib/*,
/opt/hadoop/share/hadoop/common/*,
/opt/hadoop/share/hadoop/common/lib/*,
/opt/hadoop/share/hadoop/hdfs/*,
/opt/hadoop/share/hadoop/hdfs/lib/*,
/opt/hadoop/share/hadoop/yarn/*,
/opt/hadoop/share/hadoop/yarn/lib/*
    </value>
  </property>
</configuration>
XML

sudo tee /opt/hadoop/etc/hadoop/yarn-site.xml >/dev/null <<'XML'
<?xml version="1.0"?>
<configuration>
  <property>
    <name>yarn.nodemanager.aux-services</name>
    <value>mapreduce_shuffle</value>
  </property>
  <property>
    <name>yarn.nodemanager.aux-services.mapreduce.shuffle.class</name>
    <value>org.apache.hadoop.mapred.ShuffleHandler</value>
  </property>
</configuration>
XML

# --- Start HDFS ---
hdfs --daemon start namenode
hdfs --daemon start datanode
hdfs --daemon start secondarynamenode

# --- Start YARN (pick up new configs) ---
yarn --daemon stop nodemanager >/dev/null 2>&1 || true
yarn --daemon stop resourcemanager >/dev/null 2>&1 || true
yarn --daemon start resourcemanager
yarn --daemon start nodemanager

# --- Wait for HDFS out of Safe Mode and prepare Hive dirs ---
hdfs dfsadmin -safemode wait
hdfs dfs -mkdir -p /tmp /user/hive/warehouse
hdfs dfs -chmod 1777 /tmp
hdfs dfs -chmod 777  /user/hive/warehouse
hdfs dfs -rm -r -f /tmp/hadoop-yarn/staging/$USER/.staging >/dev/null 2>&1 || true

# --- Optionally start Hive services (ignore errors if not present) ---
(hive --service metastore  >/tmp/hms.out 2>&1 &) 2>/dev/null || true
(hive --service hiveserver2 >/tmp/hs2.out 2>&1 &) 2>/dev/null || true
