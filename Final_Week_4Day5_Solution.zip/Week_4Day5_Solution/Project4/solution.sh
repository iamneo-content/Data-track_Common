# Upload input files to HDFS
hdfs dfs -mkdir -p /user/$USER/input
hdfs dfs -put -f logs.txt /user/$USER/input/
hdfs dfs -put -f sales.csv /user/$USER/input/

# Verify upload
hdfs dfs -ls /user/$USER/input/

# Check disk usage and file stats
hdfs dfs -du -h /user/$USER/input/
hdfs dfs -stat "%n %r %b bytes" /user/$USER/input/logs.txt
hdfs dfs -stat "%n %r %b bytes" /user/$USER/input/sales.csv