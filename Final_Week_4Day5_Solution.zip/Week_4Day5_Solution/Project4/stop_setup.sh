#!/bin/bash
yarn --daemon stop nodemanager
yarn --daemon stop resourcemanager
hdfs --daemon stop datanode
hdfs --daemon stop secondarynamenode
hdfs --daemon stop namenode
