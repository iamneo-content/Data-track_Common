#!/bin/sh
# Stop YARN then HDFS
yarn --daemon stop nodemanager
yarn --daemon stop resourcemanager
hdfs --daemon stop datanode
hdfs --daemon stop secondarynamenode
hdfs --daemon stop namenode
