#!/bin/sh
set -eu

# 2) External-table HDFS location
hdfs dfs -mkdir -p /data/hive_ext/customers
hdfs dfs -put -f customers.csv /data/hive_ext/customers/

# 3) Managed table: create DB, table, load, query
hive -e "
CREATE DATABASE IF NOT EXISTS eco;
USE eco;
DROP TABLE IF EXISTS customers_managed;
CREATE TABLE customers_managed(
  id INT, name STRING, region STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
TBLPROPERTIES('skip.header.line.count'='1');

LOAD DATA LOCAL INPATH 'customers.csv' INTO TABLE customers_managed;
SELECT * FROM customers_managed;
"

# 4) External table pointing to HDFS path; query
hive -e "
USE eco;
DROP TABLE IF EXISTS customers_external;
CREATE EXTERNAL TABLE customers_external(
  id INT, name STRING, region STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
LOCATION '/data/hive_ext/customers'
TBLPROPERTIES('skip.header.line.count'='1');

SELECT * FROM customers_external;
"

# 5) Drop both, then verify data paths
# Managed-table default locations vary. Check both common layouts:
#   A) /user/hive/warehouse/eco.db/customers_managed
#   B) /warehouse/tablespace/managed/hive/eco.db/customers_managed
hive -e "USE eco; DROP TABLE customers_managed; DROP TABLE customers_external;"

echo "— Checking managed table path(s) —"
hdfs dfs -ls -R /user/hive/warehouse/eco.db/customers_managed 2>/dev/null || echo "Managed path (user/warehouse) not found (expected deleted)."
hdfs dfs -ls -R /warehouse/tablespace/managed/hive/eco.db/customers_managed 2>/dev/null || echo "Managed path (tablespace/managed) not found (expected deleted)."

echo "— Checking external table path —"
hdfs dfs -ls -R /data/hive_ext/customers
