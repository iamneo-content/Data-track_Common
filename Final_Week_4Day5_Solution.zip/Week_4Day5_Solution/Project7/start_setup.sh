#!/bin/sh
# Start HDFS & YARN
hdfs --daemon start namenode
hdfs --daemon start datanode
hdfs --daemon start secondarynamenode
yarn --daemon start resourcemanager
yarn --daemon start nodemanager

# Wait for NN to leave safe mode and prep Hive dirs
hdfs dfsadmin -safemode wait
hdfs dfs -mkdir -p /tmp /user/hive/warehouse
hdfs dfs -chmod 1777 /tmp
hdfs dfs -chmod 777 /user/hive/warehouse
