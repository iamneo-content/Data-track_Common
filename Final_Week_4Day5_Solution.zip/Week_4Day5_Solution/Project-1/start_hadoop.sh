# Start HDFS daemons
hdfs --daemon start namenode
hdfs --daemon start datanode
hdfs --daemon start secondarynamenode

# Start YARN daemons
yarn --daemon start resourcemanager
yarn --daemon start nodemanager