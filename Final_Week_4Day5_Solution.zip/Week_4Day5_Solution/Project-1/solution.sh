hdfs dfs -mkdir -p /user/$USER/hdfs_basics
hdfs dfs -put -f sample_data.txt /user/$USER/hdfs_basics/
hdfs dfs -ls /user/$USER/hdfs_basics/
hdfs dfs -cat /user/$USER/hdfs_basics/sample_data.txt
hdfs dfs -stat "%r" /user/$USER/hdfs_basics/sample_data.txt