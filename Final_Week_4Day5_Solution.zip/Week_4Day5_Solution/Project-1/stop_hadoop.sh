# Stop HDFS daemons
hdfs --daemon stop secondarynamenode
hdfs --daemon stop datanode
hdfs --daemon stop namenode


yarn --daemon stop nodemanager
yarn --daemon stop resourcemanager
