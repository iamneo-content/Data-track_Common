#!/bin/sh
set -eu

# HDFS: full report
hdfs dfsadmin -report > /tmp/hdfs_report.txt 2>/dev/null || true

# Extract counts safely
live_count=$(sed -n 's/^Live datanodes (\([0-9][0-9]*\)).*/\1/p' /tmp/hdfs_report.txt | head -n1 2>/dev/null || echo 0)
dead_count=$(sed -n 's/^Dead datanodes (\([0-9][0-9]*\)).*/\1/p' /tmp/hdfs_report.txt | head -n1 2>/dev/null || echo 0)

echo "=== HDFS Summary ==="
echo "Live DataNodes: ${live_count}; Dead DataNodes: ${dead_count}"

# Print each DataNode’s last contact time
awk '
  /^Live datanodes/ {state=1; next}
  /^Dead datanodes/ {state=0}
  state && /^Name:/ {name=$0}
  state && /^Last contact:/ {printf "Last contact for %s — %s\n", name, $0}
' /tmp/hdfs_report.txt | sed -e 's/^Name: //' -e 's/^Last contact: /Last contact: /'

# --- YARN Node info ---
yarn node -list -all > /tmp/yarn_nodes.txt 2>/dev/null || true
echo "=== YARN Nodes ==="
awk '
  /^Total Nodes:/ {print; next}
  /^Node-Id/ {header=1; next}
  header && NF>0 {
    nid=$1; nstate=$2; health=$NF
    printf "%s — %s — %s\n", nid, nstate, health
  }
' /tmp/yarn_nodes.txt
