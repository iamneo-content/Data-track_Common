#!/bin/bash

# Stop YARN daemons
yarn --daemon stop nodemanager
yarn --daemon stop resourcemanager

# Stop HDFS daemons
hdfs --daemon stop datanode
hdfs --daemon stop secondarynamenode
hdfs --daemon stop namenode
