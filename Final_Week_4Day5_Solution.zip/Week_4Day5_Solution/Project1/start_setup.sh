#!/bin/bash

# Create storage directories
sudo mkdir -p /hadoop/dfs/name /hadoop/dfs/data
sudo chown -R "$USER":"$USER" /hadoop/dfs

# Fix MapReduce and YARN configs
sudo tee /opt/hadoop/etc/hadoop/mapred-site.xml >/dev/null <<'XML'
<?xml version="1.0"?>
<configuration>
  <property>
    <name>mapreduce.framework.name</name>
    <value>yarn</value>
  </property>
  <property>
    <name>yarn.app.mapreduce.am.env</name>
    <value>HADOOP_MAPRED_HOME=/opt/hadoop</value>
  </property>
  <property>
    <name>mapreduce.map.env</name>
    <value>HADOOP_MAPRED_HOME=/opt/hadoop</value>
  </property>
  <property>
    <name>mapreduce.reduce.env</name>
    <value>HADOOP_MAPRED_HOME=/opt/hadoop</value>
  </property>
  <property>
    <name>mapreduce.application.classpath</name>
    <value>
/opt/hadoop/share/hadoop/mapreduce/*,
/opt/hadoop/share/hadoop/mapreduce/lib/*,
/opt/hadoop/share/hadoop/common/*,
/opt/hadoop/share/hadoop/common/lib/*,
/opt/hadoop/share/hadoop/hdfs/*,
/opt/hadoop/share/hadoop/hdfs/lib/*,
/opt/hadoop/share/hadoop/yarn/*,
/opt/hadoop/share/hadoop/yarn/lib/*
    </value>
  </property>
</configuration>
XML

sudo tee /opt/hadoop/etc/hadoop/yarn-site.xml >/dev/null <<'XML'
<?xml version="1.0"?>
<configuration>
  <property>
    <name>yarn.nodemanager.aux-services</name>
    <value>mapreduce_shuffle</value>
  </property>
  <property>
    <name>yarn.nodemanager.aux-services.mapreduce.shuffle.class</name>
    <value>org.apache.hadoop.mapred.ShuffleHandler</value>
  </property>
</configuration>
XML

# Format NameNode only if first-time setup
if [ ! -f /hadoop/dfs/name/current/VERSION ]; then
  hdfs namenode -format -force -nonInteractive
fi

# Start HDFS daemons
hdfs --daemon start namenode
hdfs --daemon start secondarynamenode
hdfs --daemon start datanode

# Start YARN daemons
yarn --daemon start resourcemanager
yarn --daemon start nodemanager

