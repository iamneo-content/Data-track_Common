# Upload input file to HDFS
hdfs dfs -mkdir -p /user/$USER/input
hdfs dfs -put -f input.txt /user/$USER/input/

# Run WordCount MapReduce example
hadoop jar /opt/hadoop/share/hadoop/mapreduce/hadoop-mapreduce-examples-*.jar \
  wordcount /user/$USER/input /user/$USER/output

# Display results
hdfs dfs -ls /user/$USER/output/
hdfs dfs -cat /user/$USER/output/part-r-00000


# # Step 1: Create the input directory in HDFS and upload input.txt
# hdfs dfs -mkdir -p /user/$USER/input
# hdfs dfs -put input.txt /user/$USER/input

# # Step 2: Run the WordCount MapReduce job
# hadoop jar /usr/lib/hadoop-mapreduce/hadoop-mapreduce-examples.jar wordcount /user/$USER/input /user/$USER/output

# # Step 3: Inspect the output
# hdfs dfs -cat /user/$USER/output/part-r-00000

# # Step 4: Shutdown Hadoop and YARN daemons
# # Replace shutdown script path with your actual script location if different
# bash /path/to/shutdown-all.sh
