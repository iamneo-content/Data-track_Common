# import numpy as np

# def flatten_and_sum(data):
#     arr = np.array(data)
#     flat = arr.ravel()
#     total = np.sum(flat)
#     return total

# if __name__ == "__main__":
#     sales = [[10, 20, 30], [15, 25, 35]]
#     result = flatten_and_sum(sales)
#     print(result)


import numpy as np

def flatten_and_sum(data):
    arr = np.array(data)
    flat = arr.flatten()
    total = flat.sum()
    return total

if __name__ == "__main__":
    # Test case 1: Nested list
    data1 = [[100, 200, 300], [400, 500, 600]]
    print(flatten_and_sum(data1))  # Expected output: 2100

    # Test case 2: NumPy 2D array
    data2 = np.array([[100, 200], [300, 400]])
    print(flatten_and_sum(data2))  # Expected output: 1000

    # Test case 3: 1D list
    data3 = [100, 200, 300]
    print(flatten_and_sum(data3))  # Expected output: 600
