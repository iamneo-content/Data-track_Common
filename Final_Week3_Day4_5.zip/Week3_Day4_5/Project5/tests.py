# tests.py
import ast
import re
from pathlib import Path
import numpy as np
import pytest
import main

FUNCTIONS = ["flatten_and_sum"]

HARD_CODE_LITERALS = {
    100, 200, 300, 400, 500, 600, 700, 800, 900,
    1000, 1100, 1200, 1300, 1400, 1500,
    1600, 1700, 1800, 1900, 2000,
    -100, -200, -300
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        n = _get_fn(tree, fn)
        assert n is not None, f"Required function `{fn}` missing in main.py."
        func_bodies.append(n)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _is_number(x):
    return isinstance(x, (int, float, np.integer, np.floating))

def test_basic_sum_nested_lists():
    data = [[100, 200, 300], [400, 500, 600]]
    got = main.flatten_and_sum(data)
    exp = 2100
    assert _is_number(got), f"Return type incorrect. expected=number, actual={type(got).__name__}"
    assert got == exp, f"Incorrect total for nested lists. expected={exp}, actual={got}"

def test_numpy_array_input():
    data = np.array([[100, 200], [300, 400]])
    got = main.flatten_and_sum(data)
    exp = 1000
    assert got == exp, f"Incorrect total for numpy array. expected={exp}, actual={got}"

def test_1d_list_input():
    data = [100, 200, 300]
    got = main.flatten_and_sum(data)
    exp = 600
    assert got == exp, f"Incorrect total for 1D list. expected={exp}, actual={got}"

def test_sum_with_negatives():
    data = [[-100, 200, -300], [400, 500, 0]]
    got = main.flatten_and_sum(data)
    exp = 700
    assert got == exp, f"Incorrect total with negatives. expected={exp}, actual={got}"

def test_sum_with_large_numbers():
    data = [[1000, 1100, 1200], [1300, 1400, 1500]]
    got = main.flatten_and_sum(data)
    exp = 7500
    assert got == exp, f"Incorrect total for large numbers. expected={exp}, actual={got}"

def test_sum_all_zero():
    data = [[0, 0, 0], [0, 0, 0]]
    got = main.flatten_and_sum(data)
    exp = 0
    assert got == exp, f"Incorrect total for all zeros. expected={exp}, actual={got}"

def test_return_type_is_scalar():
    data = [[100, 200], [300, 400]]
    got = main.flatten_and_sum(data)
    assert np.isscalar(got), f"Return not scalar. expected=scalar, actual={type(got)}"

def test_flatten_behavior_does_not_modify_input():
    data = np.array([[100, 200, 300], [400, 500, 600]])
    orig_copy = data.copy()
    _ = main.flatten_and_sum(data)
    assert np.array_equal(data, orig_copy), f"Input array modified. expected={orig_copy.tolist()}, actual={data.tolist()}"