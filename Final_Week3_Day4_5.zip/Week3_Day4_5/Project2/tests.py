# tests.py
import ast
import re
from pathlib import Path
import pytest
import main

FUNCTIONS = ["calculate_average_from_file"]

HARD_CODE_LITERALS = {
    "a.txt", "floats.txt", "blanks.txt", "negatives.txt", "large.txt", "one.txt", "empty.txt", "bad.txt", "win.txt", "spaces.txt", "scores.txt",
    "abc",
    3, 4, 5, 7, 8, 9, 10, 20, 1000,
    -2, -3,
    1.23, 2.34, 3.45, 2.34, 1.25, 8.0, 42.75, -2.5, 5.0, 3.3
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root; ensure the file is named 'main.py'."
    return p.read_text(encoding="utf-8")

def _get_function_node(tree: ast.AST, name: str) -> ast.FunctionDef | None:
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        fn_node = _get_function_node(tree, fn)
        assert fn_node is not None, f"Required function `{fn}` is missing in main.py."
        func_bodies.append(fn_node)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write(tmp_path: Path, name: str, text: str) -> Path:
    p = tmp_path / name
    p.write_text(text, encoding="utf-8", newline="\n")
    return p

def test_basic_integers_average(tmp_path):
    fp = _write(tmp_path, "a.txt", "2\n4\n")
    got = main.calculate_average_from_file(str(fp))
    exp = 3.0
    assert got == exp, f"Average of integers incorrect: expected {exp} for [2,4], got {got}."

def test_floats_average_rounds_two_decimals(tmp_path):
    fp = _write(tmp_path, "floats.txt", "1.23\n2.34\n3.45\n")
    got = main.calculate_average_from_file(str(fp))
    exp = 2.34
    assert got == exp, f"Rounding to two decimals failed: expected {exp} for [1.23,2.34,3.45], got {got}."

def test_ignores_blank_and_space_only_lines(tmp_path):
    fp = _write(tmp_path, "blanks.txt", "10\n\n   \n20\n")
    got = main.calculate_average_from_file(str(fp))
    exp = 15.0
    assert got == exp, f"Blank/space-only lines should be ignored: expected average {exp}, got {got}."

def test_handles_negative_numbers(tmp_path):
    fp = _write(tmp_path, "negatives.txt", "-2.5\n5.0\n")
    got = main.calculate_average_from_file(str(fp))
    exp = 1.25
    assert got == exp, f"Negative numbers not handled correctly: expected {exp} for [-2.5,5.0], got {got}."

def test_large_dataset_average(tmp_path):
    text = ("1\n" * 1000)
    fp = _write(tmp_path, "large.txt", text)
    got = main.calculate_average_from_file(str(fp))
    exp = 1.0
    assert got == exp, f"Large dataset average incorrect: expected {exp} over 1000 ones, got {got}."

def test_single_value_returns_that_value(tmp_path):
    fp = _write(tmp_path, "one.txt", "42.75\n")
    got = main.calculate_average_from_file(str(fp))
    exp = 42.75
    assert got == exp, f"Single-value file should return the value itself: expected {exp}, got {got}."

def test_empty_file_raises_zero_division_error(tmp_path):
    fp = _write(tmp_path, "empty.txt", "")
    with pytest.raises(ZeroDivisionError):
        _ = main.calculate_average_from_file(str(fp))

def test_invalid_value_raises_value_error(tmp_path):
    fp = _write(tmp_path, "bad.txt", "3.3\nabc\n")
    with pytest.raises(ValueError):
        _ = main.calculate_average_from_file(str(fp))

def test_crlf_newlines_ok(tmp_path):
    p = tmp_path / "win.txt"
    p.write_bytes(b"7\r\n8\r\n9\r\n")
    got = main.calculate_average_from_file(str(p))
    exp = 8.0
    assert got == exp, f"CRLF line endings not handled: expected {exp} for [7,8,9], got {got}."

def test_leading_trailing_tabs_spaces_ok(tmp_path):
    fp = _write(tmp_path, "spaces.txt", "   1\n\t2\n  3  \n")
    got = main.calculate_average_from_file(str(fp))
    exp = 2.0
    assert got == exp, f"Whitespace around numbers should be stripped: expected {exp} for [1,2,3], got {got}."
