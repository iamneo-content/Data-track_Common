# def calculate_average_from_file(filename):
#     with open(filename, "r") as f:
#         numbers = [float(line.strip()) for line in f if line.strip()]
#         avg = sum(numbers) / len(numbers)
#         return round(avg, 2)

# if __name__ == "__main__":
#     result = calculate_average_from_file("scores.txt")
#     print(result)

def calculate_average_from_file(filename):
    numbers = []
    with open(filename, "r") as f:
        for line in f:
            line = line.strip()
            if line == "":
                continue
            try:
                number = float(line)
                numbers.append(number)
            except ValueError:
                raise ValueError(f"Invalid data encountered: '{line}'")
    if not numbers:
        raise ZeroDivisionError("No valid numeric data found.")
    avg = round(sum(numbers) / len(numbers), 2)
    return avg

if __name__ == "__main__":
    # Example test cases
    try:
        print(calculate_average_from_file("scores.txt"))  # Replace with your test file name
    except Exception as e:
        print(f"Error: {e}")
