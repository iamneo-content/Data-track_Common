# import pandas as pd

# def top_n_products_per_category(top_n: int = 2) -> pd.DataFrame:
#     items_df = pd.read_csv("product_sales.csv")
#     df = items_df.copy()
#     df["rank"] = df.groupby("category")["revenue"].rank(ascending=False, method="first")
#     out = (
#         df[df["rank"] <= top_n]
#         .sort_values(["category", "rank", "product"])
#         .reset_index(drop=True)
#     )
#     return out

# if __name__ == "__main__":
#     result_cod4 = top_n_products_per_category(top_n=3)
#     print(result_cod4)

import pandas as pd

def top_n_products_per_category(top_n) -> pd.DataFrame:
    # Read the CSV into a DataFrame
    df = pd.read_csv("product_sales.csv")
    
    # Compute rank within each category by 'revenue', breaking ties by first appearance
    df["rank"] = df.groupby("category")["revenue"].rank(method="first", ascending=False)
    
    # Filter rows where rank <= top_n
    result = df[df["rank"] <= top_n].copy()
    
    # Sort by category, rank, product
    result.sort_values(by=["category", "rank", "product"], inplace=True)
    
    # Reset index to start at 0
    result.reset_index(drop=True, inplace=True)
    
    return result

if __name__ == "__main__":
    # Example: Top 3 products per category
    output_df = top_n_products_per_category(3)
    print(output_df)
