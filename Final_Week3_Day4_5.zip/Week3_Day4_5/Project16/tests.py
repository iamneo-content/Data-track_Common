# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["top_n_products_per_category"]

HARD_CODE_LITERALS = {
    "mini.csv", "tiny.csv", "empty.csv", "big.csv",
    "Electronics", "Furniture", "Grocery", "Clothing", "CategoryA", "CategoryB", "CategoryC",
    "Smartphone X", "Laptop Pro", "Bluetooth Speaker", "Smartwatch Elite", "Wireless Earbuds",
    "Office Chair", "Study Table", "Bookshelf", "Recliner Sofa", "Dining Set",
    "Rice Pack 10kg", "Olive Oil 1L", "Breakfast Cereal", "Organic Honey", "Almonds 500g",
    "Formal Shirt", "Jeans Classic", "Jacket Winter", "T-Shirt Graphic", "Sneakers Casual",
    "A1", "A2", "A3", "B1", "B2", "B3",
    72000, 55000, 25000, 18000, 16000, 40000, 35000, 22000, 15000, 13000,
    1500, 1200, 1100, 950, 800, 4200, 3800, 2500, 1800, 1300,
    100, 200, 300, 1000, 2000, 3000
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_nodes = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` is missing in main.py."
        func_nodes.append(node)

    found = set()
    for fn_node in func_nodes:
        for node in ast.walk(fn_node):
            if isinstance(node, ast.Constant):
                found.add(node.value)

    overlap = {v for v in found if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn_node in func_nodes:
        for inner in ast.walk(fn_node):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_sales_csv(tmp_path: Path, rows: list[dict], name: str = "product_sales.csv") -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p

def test_default_top2_selection_and_order(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales_csv(tmp_path, [
        {"category": "Electronics", "product": "Laptop Pro", "revenue": 72000},
        {"category": "Electronics", "product": "Smartphone X", "revenue": 55000},
        {"category": "Electronics", "product": "Bluetooth Speaker", "revenue": 18000},
        {"category": "Furniture", "product": "Recliner Sofa", "revenue": 40000},
        {"category": "Furniture", "product": "Dining Set", "revenue": 35000},
        {"category": "Furniture", "product": "Bookshelf", "revenue": 13000},
    ])
    got = main.top_n_products_per_category(top_n=2)
    exp_categories = ["Electronics", "Electronics", "Furniture", "Furniture"]
    actual_categories = got["category"].tolist()
    assert actual_categories == exp_categories, (
        f"Category ordering incorrect. expected={exp_categories}, actual={actual_categories}"
    )
    exp_products = ["Laptop Pro", "Smartphone X", "Recliner Sofa", "Dining Set"]
    actual_products = got["product"].tolist()
    assert actual_products == exp_products, (
        f"Top-2 selection/order incorrect. expected={exp_products}, actual={actual_products}"
    )

def test_custom_top3_single_category(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales_csv(tmp_path, [
        {"category": "Grocery", "product": "Almonds 500g", "revenue": 1500},
        {"category": "Grocery", "product": "Olive Oil 1L", "revenue": 1200},
        {"category": "Grocery", "product": "Organic Honey", "revenue": 1100},
        {"category": "Grocery", "product": "Breakfast Cereal", "revenue": 950},
        {"category": "Grocery", "product": "Rice Pack 10kg", "revenue": 800},
    ])
    got = main.top_n_products_per_category(top_n=3)
    exp = ["Almonds 500g", "Olive Oil 1L", "Organic Honey"]
    actual = got["product"].tolist()
    assert actual == exp, f"Top-3 selection incorrect. expected={exp}, actual={actual}"

def test_category_with_fewer_than_n_items(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales_csv(tmp_path, [
        {"category": "Clothing", "product": "Jeans Classic", "revenue": 2500},
        {"category": "Clothing", "product": "Formal Shirt", "revenue": 1800},
    ])
    got = main.top_n_products_per_category(top_n=3)
    exp_len = 2
    actual_len = len(got)
    assert actual_len == exp_len, f"Category with < N items should return all. expected={exp_len}, actual={actual_len}"

def test_ties_ranked_by_first_occurrence_then_sorted_by_product(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales_csv(tmp_path, [
        {"category": "CategoryA", "product": "A2", "revenue": 1000},  # rank 1
        {"category": "CategoryA", "product": "A1", "revenue": 1000},  # rank 2
        {"category": "CategoryA", "product": "A3", "revenue": 1000},  # rank 3
    ])
    got = main.top_n_products_per_category(top_n=2)
    exp_products = ["A2", "A1"]  # rank 1 then rank 2
    actual_products = got["product"].tolist()
    assert actual_products == exp_products, (
        f"Tie handling/sort incorrect. expected={exp_products}, actual={actual_products}"
    )
    exp_ranks = [1.0, 2.0]
    actual_ranks = got["rank"].tolist()
    assert actual_ranks == exp_ranks, (
        f"Ranks incorrect under ties. expected={exp_ranks}, actual={actual_ranks}"
    )


def test_includes_rank_and_preserves_other_columns(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales_csv(tmp_path, [
        {"category": "Furniture", "product": "Office Chair", "revenue": 15000},
        {"category": "Furniture", "product": "Study Table", "revenue": 22000},
        {"category": "Furniture", "product": "Bookshelf", "revenue": 13000},
    ])
    got = main.top_n_products_per_category(top_n=2)
    for col in ["category", "product", "revenue", "rank"]:
        assert col in got.columns, f"Missing expected column. expected to include '{col}', actual={got.columns.tolist()}"

def test_top1_per_category_multiple_groups(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales_csv(tmp_path, [
        {"category": "Electronics", "product": "Laptop Pro", "revenue": 72000},
        {"category": "Electronics", "product": "Smartphone X", "revenue": 55000},
        {"category": "Grocery", "product": "Almonds 500g", "revenue": 1500},
        {"category": "Grocery", "product": "Breakfast Cereal", "revenue": 950},
    ])
    got = main.top_n_products_per_category(top_n=1)
    exp = ["Electronics", "Grocery"]
    actual = got["category"].tolist()
    assert actual == exp, f"Top-1 categories mismatch. expected={exp}, actual={actual}"
    exp_products = ["Laptop Pro", "Almonds 500g"]
    actual_products = got["product"].tolist()
    assert actual_products == exp_products, f"Top-1 products mismatch. expected={exp_products}, actual={actual_products}"

def test_top_n_zero_returns_empty(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales_csv(tmp_path, [
        {"category": "CategoryB", "product": "B1", "revenue": 2000},
        {"category": "CategoryB", "product": "B2", "revenue": 1000},
    ])
    got = main.top_n_products_per_category(top_n=0)
    exp_len = 0
    actual_len = len(got)
    assert actual_len == exp_len, f"top_n=0 should return empty DataFrame. expected={exp_len}, actual={actual_len}"

def test_sort_keys_category_rank_product(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales_csv(tmp_path, [
        {"category": "CategoryB", "product": "B2", "revenue": 200},
        {"category": "CategoryA", "product": "A2", "revenue": 300},
        {"category": "CategoryA", "product": "A1", "revenue": 100},
        {"category": "CategoryB", "product": "B1", "revenue": 300},
    ])
    got = main.top_n_products_per_category(top_n=2)
    exp = [("CategoryA", "A2"), ("CategoryA", "A1"), ("CategoryB", "B1"), ("CategoryB", "B2")]
    actual = list(zip(got["category"], got["product"]))
    assert actual == exp, f"Sort by category, rank, product incorrect. expected={exp}, actual={actual}"

def test_large_dataset_counts_per_category_equal_n(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = []
    for c in ["CategoryA", "CategoryB", "CategoryC"]:
        for i, rev in enumerate([3000, 2000, 1000, 300, 200, 100], start=1):
            rows.append({"category": c, "product": f"{c}_P{i}", "revenue": rev})
    _write_sales_csv(tmp_path, rows)
    got = main.top_n_products_per_category(top_n=3)
    counts = got.groupby("category").size().to_dict()
    exp = {"CategoryA": 3, "CategoryB": 3, "CategoryC": 3}
    assert counts == exp, f"Per-category counts mismatch for large dataset. expected={exp}, actual={counts}"

def test_return_type_dataframe(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales_csv(tmp_path, [
        {"category": "Clothing", "product": "Jacket Winter", "revenue": 4200},
        {"category": "Clothing", "product": "Sneakers Casual", "revenue": 3800},
    ])
    got = main.top_n_products_per_category(top_n=2)
    assert isinstance(got, pd.DataFrame), f"Return type incorrect. expected=pandas.DataFrame, actual={type(got).__name__}"

def test_no_mutation_of_source_dataframe(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = [
        {"category": "Electronics", "product": "Smartwatch Elite", "revenue": 25000},
        {"category": "Electronics", "product": "Wireless Earbuds", "revenue": 16000},
        {"category": "Furniture", "product": "Office Chair", "revenue": 15000},
    ]
    p = _write_sales_csv(tmp_path, rows)
    before = pd.read_csv(p)
    _ = main.top_n_products_per_category(top_n=2)
    after = pd.read_csv(p)
    assert before.equals(after), "Input CSV must not be modified by the function. expected=unchanged, actual=modified"
