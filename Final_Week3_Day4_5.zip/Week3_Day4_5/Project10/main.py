# import pandas as pd

# def calculate_average_sales(sales):
#     s = pd.Series(sales)
#     avg = round(s.mean(), 2)
#     return avg

# if __name__ == "__main__":
#     sales = [2500, 3200, 2800, 4000, 3500]
#     result = calculate_average_sales(sales)
#     print(result)

import pandas as pd

def calculate_average_sales(sales):
    """
    Computes the average of sales and returns the value rounded to two decimals.
    Returns float('nan') if the input sequence is empty.
    """
    series = pd.Series(sales)
    mean = series.mean()
    return float('nan') if series.empty else round(mean, 2)

if __name__ == "__main__":
    # Example test cases
    print(calculate_average_sales([2500, 3200, 2800, 4000, 3500])) # Output: 3200.0
    print(calculate_average_sales([1234.56]))                      # Output: 1234.56
    print(calculate_average_sales([-10, 20, -30, 40]))             # Output: 5.0
    print(calculate_average_sales([10, 20.5, 30.25]))              # Output: 20.25
    print(calculate_average_sales((1, 2, 3)))                      # Output: 2.0
    print(calculate_average_sales([]))                             # Output: nan
