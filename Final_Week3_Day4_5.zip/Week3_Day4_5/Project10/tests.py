# tests.py
import ast
import re
from pathlib import Path
import math
import pytest
import pandas as pd
import main

FUNCTIONS = ["calculate_average_sales"]

HARD_CODE_LITERALS = {
    2500, 3200, 2800, 4000, 3500,
    3200.0, 1234.56,
    1000000, 2000000, 3000000, 2000000.0,
    1.005, 1.0,
    -10, 20, -30, 40, 5.0,
    10, 20.5, 30.25, 20.25,
    10000
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")
    func_bodies = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` is missing in main.py."
        func_bodies.append(node)
    found = set()
    for fn_node in func_bodies:
        for node in ast.walk(fn_node):
            if isinstance(node, ast.Constant):
                found.add(node.value)
    overlap = {v for v in found if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")
    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")
    total_match_cases = 0
    for fn_node in func_bodies:
        for inner in ast.walk(fn_node):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def test_basic_sample_from_prompt():
    sales = [2500, 3200, 2800, 4000, 3500]
    got = main.calculate_average_sales(sales)
    exp = 3200.0
    assert got == exp, f"Average incorrect. expected={exp}, actual={got}"

def test_single_value_identity():
    sales = [1234.56]
    got = main.calculate_average_sales(sales)
    exp = 1234.56
    assert got == exp, f"Single-value average incorrect. expected={exp}, actual={got}"

def test_large_numbers():
    sales = [1000000, 2000000, 3000000]
    got = main.calculate_average_sales(sales)
    exp = 2000000.0
    assert got == exp, f"Large-number average incorrect. expected={exp}, actual={got}"

def test_bankers_rounding_edge():
    sales = [1.005, 1.005]
    got = main.calculate_average_sales(sales)
    exp = 1.0
    assert got == exp, f"Rounding to two decimals incorrect (bankers rounding). expected={exp}, actual={got}"

def test_negative_and_positive_mix():
    sales = [-10, 20, -30, 40]
    got = main.calculate_average_sales(sales)
    exp = 5.0
    assert got == exp, f"Negative/positive mix average incorrect. expected={exp}, actual={got}"

def test_mixed_int_float():
    sales = [10, 20.5, 30.25]
    got = main.calculate_average_sales(sales)
    exp = 20.25
    assert got == exp, f"Mixed int/float average incorrect. expected={exp}, actual={got}"

def test_tuple_input_supported():
    sales = (1, 2, 3)
    got = main.calculate_average_sales(sales)
    exp = 2.0
    assert got == exp, f"Tuple input average incorrect. expected={exp}, actual={got}"

def test_returns_float_type():
    sales = [10, 20, 30]
    got = main.calculate_average_sales(sales)
    assert isinstance(got, float), f"Return type must be float. expected=float, actual={type(got).__name__}"

def test_empty_list_nan():
    sales = []
    got = main.calculate_average_sales(sales)
    assert isinstance(got, float) or pd.isna(got), f"Return should be a float or NaN when empty. actual={got}"
    assert math.isnan(got), f"Empty input should yield NaN after mean+round. expected=nan, actual={got}"

def test_many_values_performance_small():
    sales = [1] * 10000
    got = main.calculate_average_sales(sales)
    exp = 1.0
    assert got == exp, f"Average over many values incorrect. expected={exp}, actual={got}"
