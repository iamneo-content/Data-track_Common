# import pandas as pd

# def sort_employee_salaries():
#     df = pd.read_csv("employees.csv")
#     sorted_df = df.sort_values(by="Salary", ascending=False)
#     return sorted_df

# if __name__ == "__main__":
#     result = sort_employee_salaries()
#     print(result)


import pandas as pd

def sort_employee_salaries() -> pd.DataFrame:
    """
    Reads 'employees.csv', sorts by 'Salary' in descending order, and returns the sorted DataFrame.
    The original file remains untouched.
    """
    df = pd.read_csv("employees.csv")
    sorted_df = df.sort_values(by="Salary", ascending=False)
    return sorted_df

if __name__ == "__main__":
    ranked_df = sort_employee_salaries()
    print(ranked_df)
