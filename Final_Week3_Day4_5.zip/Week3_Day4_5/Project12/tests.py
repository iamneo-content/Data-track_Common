# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["sort_employee_salaries"]

HARD_CODE_LITERALS = {
    "Arjun", "Beena", "Chetan", "Diya", "Esha", "Farah", "Gautam", "Hina",
    "Ishan", "Jaya", "Kiran", "Lata", "Mohan", "Nisha", "Om", "Pooja",
    "IT", "HR", "Marketing", "Operations", "Support",
    75000, 62000, 50000, 48000, -1000, 70000.5, 70000.0, 65000.25, 65000.0, 100, 101, 999,
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_function_node(tree: ast.AST, name: str):
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        fn_node = _get_function_node(tree, fn)
        assert fn_node is not None, f"Required function `{fn}` is missing in main.py."
        func_bodies.append(fn_node)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_employees_csv(tmp_path: Path, rows: list[dict]) -> Path:
    p = tmp_path / "employees.csv"
    pd.DataFrame(rows).to_csv(p, index=False)
    return p

def _is_descending(series: pd.Series) -> bool:
    diffs = series.diff().dropna()
    return (diffs <= 0).all()

def test_basic_descending_sort(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_employees_csv(tmp_path, [
        {"Name": "Arjun", "Salary": 50000, "Department": "Tech"},
        {"Name": "Beena", "Salary": 62000, "Department": "Sales"},
        {"Name": "Chetan", "Salary": 48000, "Department": "HR"},
        {"Name": "Diya", "Salary": 75000, "Department": "Ops"},
    ])
    got_df = main.sort_employee_salaries()
    assert list(got_df.columns) == ["Name", "Salary", "Department"], (
        f"Columns changed. expected={['Name','Salary','Department']}, actual={list(got_df.columns)}"
    )
    assert _is_descending(got_df["Salary"]), (
        f"Salaries not sorted in descending order. expected=non-increasing, actual={got_df['Salary'].tolist()}"
    )
    expected_top = "Diya"
    actual_top = got_df.iloc[0]["Name"]
    assert actual_top == expected_top, f"Top earner mismatch. expected={expected_top}, actual={actual_top}"

def test_float_salaries_supported(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_employees_csv(tmp_path, [
        {"Name": "Esha", "Salary": 70000.5, "Department": "Tech"},
        {"Name": "Farah", "Salary": 70000.0, "Department": "Sales"},
        {"Name": "Gautam", "Salary": 65000.25, "Department": "HR"},
    ])
    got_df = main.sort_employee_salaries()
    expected_order = ["Esha", "Farah", "Gautam"]
    actual_order = got_df["Name"].tolist()
    assert actual_order == expected_order, f"Float salary ordering wrong. expected={expected_order}, actual={actual_order}"

def test_zero_and_negative_salaries(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_employees_csv(tmp_path, [
        {"Name": "Hina", "Salary": 0, "Department": "Ops"},
        {"Name": "Ishan", "Salary": -1000, "Department": "Tech"},
        {"Name": "Jaya", "Salary": 50000, "Department": "Sales"},
    ])
    got_df = main.sort_employee_salaries()
    expected_order = ["Jaya", "Hina", "Ishan"]
    actual_order = got_df["Name"].tolist()
    assert actual_order == expected_order, f"Ordering with zero/negative salaries incorrect. expected={expected_order}, actual={actual_order}"

def test_duplicates_in_salary_still_descending(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_employees_csv(tmp_path, [
        {"Name": "Kiran", "Salary": 65000.0, "Department": "Tech"},
        {"Name": "Lata", "Salary": 65000.0, "Department": "Sales"},
        {"Name": "Mohan", "Salary": 50000, "Department": "HR"},
    ])
    got_df = main.sort_employee_salaries()
    assert _is_descending(got_df["Salary"]), (
        f"Salaries should be non-increasing with ties allowed. expected=non-increasing, actual={got_df['Salary'].tolist()}"
    )
    expected_multiset = sorted([65000.0, 65000.0, 50000], reverse=True)
    actual_multiset = sorted(got_df["Salary"].tolist(), reverse=True)
    assert actual_multiset == expected_multiset, (
        f"Tied salaries changed unexpectedly. expected={expected_multiset}, actual={actual_multiset}"
    )

def test_handles_large_dataset(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = [{"Name": f"Emp{i}", "Salary": i, "Department": "Tech"} for i in range(100)]
    _write_employees_csv(tmp_path, rows)
    got_df = main.sort_employee_salaries()
    expected_top_salary = 99
    actual_top_salary = int(got_df.iloc[0]["Salary"])
    assert actual_top_salary == expected_top_salary, (
        f"Top salary incorrect for large dataset. expected={expected_top_salary}, actual={actual_top_salary}"
    )
    assert len(got_df) == 100, f"Row count changed. expected=100, actual={len(got_df)}"

def test_preserves_other_columns(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_employees_csv(tmp_path, [
        {"Name": "Nisha", "Salary": 101, "Department": "HR"},
        {"Name": "Om", "Salary": 100, "Department": "Ops"},
    ])
    got_df = main.sort_employee_salaries()
    expected_departments = ["HR", "Ops"]
    actual_departments = got_df["Department"].tolist()
    assert actual_departments == expected_departments, (
        f"Non-sorting columns altered or re-ordered incorrectly. expected={expected_departments}, actual={actual_departments}"
    )

def test_missing_file_raises(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    with pytest.raises(FileNotFoundError):
        _ = main.sort_employee_salaries()

def test_input_file_not_modified(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    p = _write_employees_csv(tmp_path, [
        {"Name": "Pooja", "Salary": 62000, "Department": "Sales"},
        {"Name": "Arjun", "Salary": 50000, "Department": "Tech"},
    ])
    before = pd.read_csv(p)
    _ = main.sort_employee_salaries()
    after = pd.read_csv(p)
    assert before.equals(after), (
        f"Input CSV should not be modified by the function. expected=unchanged, actual=modified"
    )

def test_returns_dataframe_type(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_employees_csv(tmp_path, [
        {"Name": "Beena", "Salary": 62000, "Department": "Sales"},
        {"Name": "Chetan", "Salary": 48000, "Department": "HR"},
    ])
    got = main.sort_employee_salaries()
    assert isinstance(got, pd.DataFrame), f"Return type incorrect. expected=pandas.DataFrame, actual={type(got).__name__}"

def test_salary_column_type_numeric(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_employees_csv(tmp_path, [
        {"Name": "Diya", "Salary": 75000, "Department": "Ops"},
        {"Name": "Arjun", "Salary": 50000, "Department": "Tech"},
    ])
    got = main.sort_employee_salaries()
    is_numeric = pd.api.types.is_numeric_dtype(got["Salary"])
    assert is_numeric, f"'Salary' dtype incorrect. expected=numeric dtype, actual={got['Salary'].dtype}"
