# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["flag_cheapest_item_per_category"]

HARD_CODE_LITERALS = {
    "mini.csv", "ties.csv", "bad.csv", "empty.csv", "big.csv",
    "Fruits", "Vegetables", "Beverages", "Snacks", "CatA", "CatB",
    "Apple", "Banana", "Mango", "Grapes", "Orange",
    "Carrot", "Tomato", "Potato", "Onion", "Spinach",
    "Green Tea", "Coffee", "Orange Juice", "Lemonade", "Milkshake",
    "Chips", "Biscuits", "Popcorn", "Cookies", "Nachos",
    "A1", "A2", "A3", "B1", "B2",
    120, 60, 90, 110, 80, 40, 35, 30, 25, 20, 150, 220, 180, 130, 160, 50, 40, 70, 55, 65,
    10, 15, 5, 100, 200
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")
    func_nodes = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` is missing in main.py."
        func_nodes.append(node)
    found = set()
    for fn_node in func_nodes:
        for node in ast.walk(fn_node):
            if isinstance(node, ast.Constant):
                found.add(node.value)
    overlap = {v for v in found if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")
    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")
    total_match_cases = 0
    for fn_node in func_nodes:
        for inner in ast.walk(fn_node):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_prices(tmp_path: Path, rows: list[dict], name: str = "product_prices.csv") -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p

def test_flags_min_price_per_category_basic(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_prices(tmp_path, [
        {"category": "Fruits", "item": "Apple", "price": 120},
        {"category": "Fruits", "item": "Banana", "price": 60},
        {"category": "Fruits", "item": "Mango", "price": 90},
    ])
    got = main.flag_cheapest_item_per_category()
    cheapest = got.loc[got["category"] == "Fruits"].sort_values("price")["is_cheapest"].tolist()
    exp = [True, False, False]
    assert cheapest == exp, f"Cheapest flag incorrect for Fruits. expected={exp}, actual={cheapest}"

def test_ties_min_marks_multiple_true(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_prices(tmp_path, [
        {"category": "Vegetables", "item": "Carrot", "price": 40},
        {"category": "Vegetables", "item": "Tomato", "price": 35},
        {"category": "Vegetables", "item": "Onion", "price": 35},
    ])
    got = main.flag_cheapest_item_per_category()
    flags = got.loc[got["category"] == "Vegetables", ["item", "is_cheapest"]].set_index("item")["is_cheapest"].to_dict()
    exp = {"Carrot": False, "Tomato": True, "Onion": True}
    assert flags == exp, f"Tie handling incorrect. expected={exp}, actual={flags}"

def test_sorting_by_category_price_item_ascending(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_prices(tmp_path, [
        {"category": "Beverages", "item": "Green Tea", "price": 150},
        {"category": "Beverages", "item": "Lemonade", "price": 130},
        {"category": "Beverages", "item": "Milkshake", "price": 160},
        {"category": "Beverages", "item": "Coffee", "price": 220},
        {"category": "Beverages", "item": "Orange Juice", "price": 180},
        {"category": "Snacks", "item": "Chips", "price": 50},
        {"category": "Snacks", "item": "Biscuits", "price": 40},
    ])
    got = main.flag_cheapest_item_per_category()
    pairs = list(zip(got["category"], got["price"], got["item"]))
    exp = [
        ("Beverages", 130, "Lemonade"),
        ("Beverages", 150, "Green Tea"),
        ("Beverages", 160, "Milkshake"),
        ("Beverages", 180, "Orange Juice"),
        ("Beverages", 220, "Coffee"),
        ("Snacks", 40, "Biscuits"),
        ("Snacks", 50, "Chips"),
    ]
    assert pairs == exp, f"Sort order incorrect. expected={exp}, actual={pairs}"

def test_boolean_dtype_for_flag(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_prices(tmp_path, [
        {"category": "Snacks", "item": "Popcorn", "price": 70},
        {"category": "Snacks", "item": "Cookies", "price": 55},
        {"category": "Snacks", "item": "Nachos", "price": 65},
    ])
    got = main.flag_cheapest_item_per_category()
    is_bool = pd.api.types.is_bool_dtype(got["is_cheapest"])
    assert is_bool, f"'is_cheapest' dtype incorrect. expected=bool, actual={got['is_cheapest'].dtype}"

def test_preserves_other_columns(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_prices(tmp_path, [
        {"category": "Fruits", "item": "Orange", "price": 80},
        {"category": "Fruits", "item": "Grapes", "price": 110},
    ])
    got = main.flag_cheapest_item_per_category()
    exp_cols = {"category", "item", "price", "is_cheapest"}
    actual_cols = set(got.columns)
    assert actual_cols == exp_cols, f"Columns changed. expected={sorted(exp_cols)}, actual={sorted(actual_cols)}"

def test_multiple_categories_independent_min(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_prices(tmp_path, [
        {"category": "CatA", "item": "A1", "price": 15},
        {"category": "CatA", "item": "A2", "price": 10},
        {"category": "CatB", "item": "B1", "price": 200},
        {"category": "CatB", "item": "B2", "price": 100},
    ])
    got = main.flag_cheapest_item_per_category()
    cheapest = got[got["is_cheapest"]].groupby("category")["item"].apply(list).to_dict()
    exp = {"CatA": ["A2"], "CatB": ["B2"]}
    assert cheapest == exp, f"Cheapest selection per category incorrect. expected={exp}, actual={cheapest}"

def test_input_file_not_modified(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = [
        {"category": "Fruits", "item": "Apple", "price": 120},
        {"category": "Fruits", "item": "Banana", "price": 60},
    ]
    p = _write_prices(tmp_path, rows)
    before = pd.read_csv(p)
    _ = main.flag_cheapest_item_per_category()
    after = pd.read_csv(p)
    assert before.equals(after), "Input CSV must not be modified. expected=unchanged, actual=modified"

def test_empty_file_raises_emptydataerror(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    p = tmp_path / "empty.csv"
    p.write_text("", encoding="utf-8")
    with pytest.raises(pd.errors.EmptyDataError):
        pd.read_csv(p)
    p.rename(tmp_path / "product_prices.csv")
    with pytest.raises(pd.errors.EmptyDataError):
        _ = main.flag_cheapest_item_per_category()

def test_missing_required_column_raises(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_prices(tmp_path, [
        {"category": "Fruits", "item": "Apple"},  
        {"category": "Fruits", "item": "Banana"},
    ])
    with pytest.raises(KeyError):
        _ = main.flag_cheapest_item_per_category()

def test_large_dataset_scaling(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = []
    for i in range(1, 501):
        rows.append({"category": "CatA", "item": f"A{i}", "price": i})
    for i in range(1, 501):
        rows.append({"category": "CatB", "item": f"B{i}", "price": i + 5})
    _write_prices(tmp_path, rows)
    got = main.flag_cheapest_item_per_category()
    cheapest = got[got["is_cheapest"]].groupby("category")["item"].apply(list).to_dict()
    exp = {"CatA": ["A1"], "CatB": ["B1"]}
    assert cheapest == exp, f"Cheapest items incorrect for large dataset. expected={exp}, actual={cheapest}"


