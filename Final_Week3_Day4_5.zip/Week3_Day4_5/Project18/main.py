# import pandas as pd

# def flag_cheapest_item_per_category() -> pd.DataFrame:
#     items_df = pd.read_csv("product_prices.csv")
#     df = items_df.copy()
#     cat_min = df.groupby("category")["price"].transform("min")
#     df["is_cheapest"] = df["price"].eq(cat_min)
#     out = df.sort_values(["category", "price", "item"]).reset_index(drop=True)
#     return out


# if __name__ == "__main__":
#     result_cod6 = flag_cheapest_item_per_category()
#     print(result_cod6)

import pandas as pd

def flag_cheapest_item_per_category() -> pd.DataFrame:
    # Read CSV into DataFrame
    df = pd.read_csv('product_prices.csv')
    
    # Compute the minimum price per category
    min_prices = df.groupby('category')['price'].transform('min')
    
    # Flag items with minimum price in each category
    df['is_cheapest'] = df['price'] == min_prices
    
    # Sort by category, price, item
    df = df.sort_values(['category', 'price', 'item'], ascending=[True, True, True])
    
    # Reset the index
    df = df.reset_index(drop=True)
    
    return df

if __name__ == "__main__":
    # Function invocation and print output for testing
    result_df = flag_cheapest_item_per_category()
    print(result_df)
