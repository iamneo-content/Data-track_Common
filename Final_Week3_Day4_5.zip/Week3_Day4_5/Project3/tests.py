# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["merge_csv_files"]

HARD_CODE_LITERALS = {
    "file1.csv", "file2.csv", "merged.csv",
    "a.csv", "b.csv", "out.csv",
    "alpha.csv", "beta.csv", "gamma.csv",
    "Laptop", "Mouse", "Keyboard", "Phone", "Tablet",
    "West",
    99, 100, 101, 102, 103,
    120.5, 80.25, 300.0, 450.75, 999.99,
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_function_node(tree: ast.AST, name: str):
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        fn_node = _get_function_node(tree, fn)
        assert fn_node is not None, f"Required function `{fn}` missing in main.py."
        func_bodies.append(fn_node)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    df = pd.DataFrame(rows)
    p = tmp_path / name
    df.to_csv(p, index=False)
    return p

def _read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path)

def test_merge_basic_small_realistic(tmp_path):
    f1 = _write_csv(tmp_path, "file1.csv", [
        {"id": 99, "product": "Laptop", "amount": 120.5},
        {"id": 100, "product": "Mouse", "amount": 80.25},
    ])
    f2 = _write_csv(tmp_path, "file2.csv", [
        {"id": 101, "product": "Keyboard", "amount": 300.0},
    ])
    out = tmp_path / "merged.csv"
    msg = main.merge_csv_files(f1, f2, out)
    df = _read_csv(out)
    assert msg == "Merge successful", f"Expected 'Merge successful', got '{msg}'."
    assert df.shape == (3, 3), f"Merged shape mismatch: expected (3,3), got {df.shape}."

def test_preserves_all_rows_counts(tmp_path):
    f1 = _write_csv(tmp_path, "a.csv", [{"id": 1}, {"id": 2}, {"id": 3}])
    f2 = _write_csv(tmp_path, "b.csv", [{"id": 4}, {"id": 5}])
    out = tmp_path / "out.csv"
    main.merge_csv_files(f1, f2, out)
    df = _read_csv(out)
    exp = 5
    assert len(df) == exp, f"Row count mismatch after merge: expected {exp}, got {len(df)}."

def test_combines_disjoint_schemas(tmp_path):
    f1 = _write_csv(tmp_path, "alpha.csv", [{"id": 1, "amount": 300.0}])
    f2 = _write_csv(tmp_path, "beta.csv", [{"id": 2, "region": "West"}])
    out = tmp_path / "gamma.csv"
    main.merge_csv_files(f1, f2, out)
    df = _read_csv(out)
    for col in {"id", "amount", "region"}:
        assert col in df.columns, f"Missing '{col}' in merged output."

def test_empty_first_file_raises_emptydataerror(tmp_path):
    p1 = tmp_path / "file1.csv"
    p1.write_text("", encoding="utf-8")
    f2 = _write_csv(tmp_path, "file2.csv", [{"id": 101, "amount": 450.75}])
    out = tmp_path / "merged.csv"
    with pytest.raises(pd.errors.EmptyDataError):
        main.merge_csv_files(p1, f2, out)

def test_empty_second_file_raises_emptydataerror(tmp_path):
    f1 = _write_csv(tmp_path, "file1.csv", [{"id": 101, "amount": 450.75}])
    p2 = tmp_path / "file2.csv"
    p2.write_text("", encoding="utf-8")
    out = tmp_path / "merged.csv"
    with pytest.raises(pd.errors.EmptyDataError):
        main.merge_csv_files(f1, p2, out)

def test_creates_output_file(tmp_path):
    f1 = _write_csv(tmp_path, "file1.csv", [{"id": 1, "amount": 120.5}])
    f2 = _write_csv(tmp_path, "file2.csv", [{"id": 2, "amount": 80.25}])
    out = tmp_path / "merged.csv"
    main.merge_csv_files(f1, f2, out)
    assert out.exists(), f"Output file not created at {out}."

def test_row_order_preserved(tmp_path):
    f1 = _write_csv(tmp_path, "file1.csv", [{"id": 1}, {"id": 2}])
    f2 = _write_csv(tmp_path, "file2.csv", [{"id": 3}])
    out = tmp_path / "merged.csv"
    main.merge_csv_files(f1, f2, out)
    df = _read_csv(out)
    got = df["id"].tolist()
    exp = [1, 2, 3]
    assert got == exp, f"Row order mismatch: expected {exp}, got {got}."

def test_numeric_values_intact_after_merge(tmp_path):
    f1 = _write_csv(tmp_path, "file1.csv", [{"id": 101, "amount": 300.0}])
    f2 = _write_csv(tmp_path, "file2.csv", [{"id": 102, "amount": 999.99}])
    out = tmp_path / "merged.csv"
    main.merge_csv_files(f1, f2, out)
    df = _read_csv(out)
    total = df["amount"].sum()
    exp = 1299.99
    assert abs(total - exp) < 1e-9, f"Amount totals incorrect after merge: expected {exp}, got {total}."

def test_string_columns_unchanged(tmp_path):
    f1 = _write_csv(tmp_path, "file1.csv", [{"id": 99, "product": "Phone"}])
    f2 = _write_csv(tmp_path, "file2.csv", [{"id": 100, "product": "Tablet"}])
    out = tmp_path / "merged.csv"
    main.merge_csv_files(f1, f2, out)
    df = _read_csv(out)
    got = df["product"].tolist()
    exp = ["Phone", "Tablet"]
    assert got == exp, f"String values changed after merge: expected {exp}, got {got}."

def test_inputs_not_modified(tmp_path):
    f1 = _write_csv(tmp_path, "file1.csv", [{"id": 1, "amount": 120.5}])
    f2 = _write_csv(tmp_path, "file2.csv", [{"id": 2, "amount": 80.25}])
    in1_before = pd.read_csv(f1)
    in2_before = pd.read_csv(f2)
    out = tmp_path / "merged.csv"
    main.merge_csv_files(f1, f2, out)
    in1_after = pd.read_csv(f1)
    in2_after = pd.read_csv(f2)
    assert in1_before.equals(in1_after), "Input file1 should not be modified by merge."
    assert in2_before.equals(in2_after), "Input file2 should not be modified by merge."
