# import pandas as pd

# def merge_csv_files(file1, file2, output_file):
#     df1 = pd.read_csv(file1)
#     df2 = pd.read_csv(file2)
#     merged = pd.concat([df1, df2], ignore_index=True)
#     merged.to_csv(output_file, index=False)
#     return "Merge successful"

# if __name__ == "__main__":
#     result = merge_csv_files("sales_part1.csv", "sales_part2.csv", "sales_first_half.csv")

# import pandas as pd

# def merge_csv_files(file1, file2, output_file):
#     """
#     Merge two CSV files containing sales records into a single consolidated CSV.
    
#     Parameters:
#         file1 (str or Path): Path to first CSV file.
#         file2 (str or Path): Path to second CSV file.
#         output_file (str or Path): Path to write merged output.
    
#     Returns:
#         str: "Merge successful" on success.
    
#     Raises:
#         pandas.errors.EmptyDataError: If either input file is empty.
#     """
#     try:
#         df1 = pd.read_csv(file1)
#     except pd.errors.EmptyDataError:
#         raise pd.errors.EmptyDataError(f"{file1} is empty or has no data.")
#     try:
#         df2 = pd.read_csv(file2)
#     except pd.errors.EmptyDataError:
#         raise pd.errors.EmptyDataError(f"{file2} is empty or has no data.")
#     merged_df = pd.concat([df1, df2], ignore_index=True, sort=False)
#     merged_df.to_csv(output_file, index=False)
#     return "Merge successful"

# if __name__ == "__main__":
#     # Example usage and test invocation
#     result = merge_csv_files("sales_part1.csv", "sales_part2.csv", "sales_first_half.csv")
#     print(result)



import pandas as pd

def merge_csv_files(file1, file2, output_file):
    # Read both CSV files
    df1 = pd.read_csv(file1)
    df2 = pd.read_csv(file2)
    
    # Concatenate dataframes vertically and handle different schemas
    merged_df = pd.concat([df1, df2], ignore_index=True, sort=False)
    
    # Export merged dataframe to the output file
    merged_df.to_csv(output_file, index=False)
    
    # Return confirmation message
    return "Merge successful"
