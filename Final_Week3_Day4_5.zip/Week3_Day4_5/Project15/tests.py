# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["apply_discount"]

HARD_CODE_LITERALS = {
    "mini.csv", "empty.csv", "invalid.csv", "big.csv", "dupe.csv",
    "Laptop 14-inch", "Laptop 15-inch", "Wireless Mouse", "Mechanical Keyboard",
    "Smartphone 5G", "Tablet 10-inch", "Noise Cancelling Headphones",
    "Smartwatch Series 7", "External Hard Drive 1TB", "Portable SSD 500GB",
    "USB-C Hub 6-in-1", "Bluetooth Speaker", "Webcam HD", "Wireless Charger",
    "Smart TV 43-inch", "Smart TV 55-inch", "Printer Inkjet", "Projector Portable",
    "Router Dual Band", "Keyboard Combo",
    "Electronics", "Accessories", "Storage", "Peripherals", "Networking",
    "HP", "Dell", "Logitech", "Corsair", "Samsung", "Lenovo", "Sony",
    "Apple", "Seagate", "SanDisk", "Anker", "Boat", "Xiaomi", "LG",
    "Canon", "Epson", "TP-Link",
    62000, 68000, 950, 4800, 52000, 27000, 8500, 45000, 5200, 6200,
    3200, 2800, 3400, 2100, 39000, 12500, 31000, 3400, 1800,
    200, 300, 50, 25, 15
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")
    func_nodes = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` missing in main.py."
        func_nodes.append(node)
    found = set()
    for fn_node in func_nodes:
        for node in ast.walk(fn_node):
            if isinstance(node, ast.Constant):
                found.add(node.value)
    overlap = {v for v in found if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")
    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")
    total_match_cases = 0
    for fn_node in func_nodes:
        for inner in ast.walk(fn_node):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p

def test_creates_discounted_price_column(tmp_path):
    fp = _write_csv(tmp_path, "products.csv", [
        {"product_name": "Laptop 14-inch", "price": 1000}
    ])
    got = main.apply_discount(str(fp))
    assert "discounted_price" in got.columns, "Expected new column 'discounted_price' not found in output."

def test_discount_calculation_is_10_percent(tmp_path):
    fp = _write_csv(tmp_path, "mini.csv", [
        {"product_name": "Mouse", "price": 1000},
        {"product_name": "Keyboard", "price": 2000}
    ])
    got = main.apply_discount(str(fp))
    exp = [900.0, 1800.0]
    actual = got["discounted_price"].tolist()
    assert actual == exp, f"Discount calculation incorrect. expected={exp}, actual={actual}"

def test_discounted_price_type_is_float(tmp_path):
    fp = _write_csv(tmp_path, "mini.csv", [
        {"product_name": "Mouse", "price": 500}
    ])
    got = main.apply_discount(str(fp))
    dtype = str(got["discounted_price"].dtype)
    assert "float" in dtype, f"'discounted_price' dtype incorrect. expected=float, actual={dtype}"

def test_works_with_multiple_categories(tmp_path):
    rows = [
        {"product_name": "Laptop", "category": "Electronics", "price": 1000},
        {"product_name": "Mouse", "category": "Accessories", "price": 500}
    ]
    fp = _write_csv(tmp_path, "mini.csv", rows)
    got = main.apply_discount(str(fp))
    exp_len = len(rows)
    actual_len = len(got)
    assert actual_len == exp_len, f"Row count changed after discount. expected={exp_len}, actual={actual_len}"

def test_preserves_original_price_column(tmp_path):
    fp = _write_csv(tmp_path, "mini.csv", [{"product_name": "Tablet", "price": 3000}])
    got = main.apply_discount(str(fp))
    assert "price" in got.columns, "Original 'price' column missing after transformation."

def test_empty_file_raises_error(tmp_path):
    fp = _write_csv(tmp_path, "empty.csv", [])
    with pytest.raises(ValueError):
        _ = main.apply_discount(str(fp))

def test_invalid_price_type_raises(tmp_path):
    fp = _write_csv(tmp_path, "invalid.csv", [{"product_name": "TV", "price": "abc"}])
    with pytest.raises(Exception):
        _ = main.apply_discount(str(fp))

def test_duplicate_rows_maintained(tmp_path):
    rows = [
        {"product_name": "Phone", "price": 1000},
        {"product_name": "Phone", "price": 1000}
    ]
    fp = _write_csv(tmp_path, "dupe.csv", rows)
    got = main.apply_discount(str(fp))
    exp_len = 2
    actual_len = len(got)
    assert actual_len == exp_len, f"Duplicate rows altered. expected={exp_len}, actual={actual_len}"

def test_large_dataset_discount_consistency(tmp_path):
    rows = [{"product_name": f"Item{i}", "price": i * 100} for i in range(1, 501)]
    fp = _write_csv(tmp_path, "big.csv", rows)
    got = main.apply_discount(str(fp))
    exp_first = rows[0]["price"] * 0.9
    actual_first = got.loc[0, "discounted_price"]
    assert actual_first == exp_first, f"Discount mismatch in large dataset. expected={exp_first}, actual={actual_first}"

def test_return_type_dataframe(tmp_path):
    fp = _write_csv(tmp_path, "mini.csv", [{"product_name": "Router", "price": 3400}])
    got = main.apply_discount(str(fp))
    assert isinstance(got, pd.DataFrame), f"Return type incorrect. expected=pandas.DataFrame, actual={type(got).__name__}"
