# import pandas as pd

# def apply_discount(csv_path):
#     df = pd.read_csv(csv_path)
#     df["discounted_price"] = df["price"].apply(lambda x: x * 0.9)
#     return df


# if __name__ == "__main__":
#     result_df = apply_discount("products.csv")
#     print(result_df)

import pandas as pd

def apply_discount(csv_path: str) -> pd.DataFrame:
    """
    Reads a CSV file, applies a 10% discount to the 'price' column,
    and returns a new DataFrame with an additional 'discounted_price' column.
    The original file is NOT modified.
    """
    df = pd.read_csv(csv_path)
    df['discounted_price'] = df['price'] * 0.9
    return df

if __name__ == "__main__":
    # Example test case (uncomment and set the path to test)
    # test_df = apply_discount("products.csv")
    # print(test_df.head())
    pass
