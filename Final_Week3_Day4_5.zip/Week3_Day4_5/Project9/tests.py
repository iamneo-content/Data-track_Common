# tests.py
import ast
import re
from pathlib import Path
import numpy as np
import pytest
import main

FUNCTIONS = ["add_bias_rowwise"]

HARD_CODE_LITERALS = {
    100, 101, 102, 103, 104, 105,
    110, 115, 120, 125, 130, 135, 140, 145, 150,
    155, 160, 165, 170, 175, 180, 185, 190, 195, 200
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` missing in main.py."
        func_bodies.append(node)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def test_basic_bias_addition():
    mat = np.array([[100, 110, 120],
                    [130, 140, 150]])
    bias = np.array([10, 20])
    got = main.add_bias_rowwise(mat, bias)
    exp = np.array([[110, 120, 130],
                    [150, 160, 170]])
    assert np.array_equal(got, exp), f"Incorrect bias addition. expected={exp.tolist()}, actual={got.tolist()}"

def test_different_bias_values():
    mat = np.array([[150, 160, 170],
                    [180, 190, 200]])
    bias = np.array([5, 15])
    got = main.add_bias_rowwise(mat, bias)
    exp = np.array([[155, 165, 175],
                    [195, 205, 215]])
    assert np.array_equal(got, exp), f"Incorrect with different bias values. expected={exp.tolist()}, actual={got.tolist()}"

def test_zero_bias():
    mat = np.array([[110, 120, 130],
                    [140, 150, 160]])
    bias = np.array([0, 0])
    got = main.add_bias_rowwise(mat, bias)
    exp = mat
    assert np.array_equal(got, exp), f"Zero bias should not change matrix. expected={exp.tolist()}, actual={got.tolist()}"

def test_negative_bias():
    mat = np.array([[120, 130, 140],
                    [150, 160, 170]])
    bias = np.array([-10, -20])
    got = main.add_bias_rowwise(mat, bias)
    exp = np.array([[110, 120, 130],
                    [130, 140, 150]])
    assert np.array_equal(got, exp), f"Incorrect with negative bias. expected={exp.tolist()}, actual={got.tolist()}"

def test_single_row_matrix():
    mat = np.array([[150, 160, 170]])
    bias = np.array([10])
    got = main.add_bias_rowwise(mat, bias)
    exp = np.array([[160, 170, 180]])
    assert np.array_equal(got, exp), f"Incorrect single-row bias result. expected={exp.tolist()}, actual={got.tolist()}"

def test_large_matrix():
    mat = np.arange(100, 112).reshape(4, 3)
    bias = np.array([10, 20, 30, 40])
    got = main.add_bias_rowwise(mat, bias)
    exp = np.array([[110, 111, 112],
                    [123, 124, 125],
                    [136, 137, 138],
                    [149, 150, 151]])
    assert np.array_equal(got, exp), f"Incorrect large matrix computation. expected={exp.tolist()}, actual={got.tolist()}"

def test_type_of_output_is_ndarray():
    mat = np.array([[120, 130], [140, 150]])
    bias = np.array([5, 10])
    got = main.add_bias_rowwise(mat, bias)
    assert isinstance(got, np.ndarray), f"Return type mismatch. expected=np.ndarray, actual={type(got)}"

def test_shape_of_output():
    mat = np.array([[100, 110, 120], [130, 140, 150]])
    bias = np.array([10, 20])
    got = main.add_bias_rowwise(mat, bias)
    exp_shape = (2, 3)
    assert got.shape == exp_shape, f"Incorrect output shape. expected={exp_shape}, actual={got.shape}"

def test_input_not_modified():
    mat = np.array([[150, 160], [170, 180]])
    bias = np.array([10, 20])
    mat_copy = mat.copy()
    _ = main.add_bias_rowwise(mat, bias)
    assert np.array_equal(mat, mat_copy), f"Input matrix modified. expected={mat_copy.tolist()}, actual={mat.tolist()}"

def test_mismatched_bias_length_broadcasts_correctly():
    mat = np.array([[100, 110, 120], [130, 140, 150]])
    bias = np.array([10])
    got = main.add_bias_rowwise(mat, bias)
    exp = np.array([[110, 120, 130], [140, 150, 160]])
    assert np.array_equal(got, exp), f"Incorrect broadcasting with single bias value. expected={exp.tolist()}, actual={got.tolist()}"

