# import numpy as np

# def add_bias_rowwise(matrix: np.ndarray, bias: np.ndarray) -> np.ndarray:
#     result = matrix + bias.reshape(-1, 1)
#     return result

# if __name__ == "__main__":
#     mat = np.array([[1, 2, 3],
#                     [4, 5, 6]])
#     bias = np.array([10, 20])
#     output = add_bias_rowwise(mat, bias)
#     print(output)
import numpy as np

def add_bias_rowwise(matrix: np.ndarray, bias: np.ndarray) -> np.ndarray:
    """
    Adds row-wise bias to matrix via NumPy broadcasting.

    Parameters:
        matrix (np.ndarray): shape (R, C), original data
        bias (np.ndarray): shape (R,) or (1,), per-row or global bias

    Returns:
        np.ndarray: new array of shape (R, C) with bias applied
    """
    # Ensure bias is a 1D array
    bias = np.asarray(bias)
    if bias.ndim != 1 or (bias.shape[0] != matrix.shape[0] and bias.shape[0] != 1):
        raise ValueError("bias must be 1-D with length R or length 1.")

    # Reshape bias for broadcasting
    result = matrix + bias.reshape(-1, 1)
    return result

if __name__ == "__main__":
    # Example 1
    matrix1 = np.array([[1, 2, 3], [4, 5, 6]])
    bias1 = np.array([10, 20])
    print(add_bias_rowwise(matrix1, bias1))
    # Output: [[11 12 13] [24 25 26]]

    # Example 2
    matrix2 = np.array([[2, 4, 6], [1, 3, 5]])
    bias2 = np.array([5])
    print(add_bias_rowwise(matrix2, bias2))
    # Output: [[ 7  9 11] [ 6  8 10]]

    # Example 3
    matrix3 = np.array([[3, 3, 3]])
    bias3 = np.array([-2])
    print(add_bias_rowwise(matrix3, bias3))
    # Output: [[1 1 1]]
