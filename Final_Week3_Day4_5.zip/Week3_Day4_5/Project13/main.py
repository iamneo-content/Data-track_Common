# import pandas as pd

# def fill_missing_salary(csv_path):
#     df = pd.read_csv(csv_path)
#     mean_salary = round(df["salary"].mean(), 0)
#     df["salary"] = df["salary"].fillna(mean_salary)
#     df["salary"] = df["salary"].astype(int)
#     return df

# if __name__ == "__main__":
#     result_df = fill_missing_salary("employees.csv")
#     print(result_df)


import pandas as pd
import numpy as np

def fill_missing_salary(csv_path: str) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    # Compute mean of 'salary' column, round to 0 decimals using bankers' rounding (.5 to nearest even)
    salary_mean = df['salary'].mean()
    rounded_mean = int(np.round(salary_mean))
    # Fill missing (NaN) salaries with the rounded mean
    df['salary'] = df['salary'].fillna(rounded_mean)
    # Convert to integer type
    df['salary'] = df['salary'].astype(int)
    return df

if __name__ == "__main__":
    # Example usage
    filled_df = fill_missing_salary("your_file.csv")  # Replace with your actual CSV file path
    print(filled_df)
