# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["fill_missing_salary"]

HARD_CODE_LITERALS = {
    "staff.csv", "nan_only.csv", "bad.csv", "large.csv", "mini.csv",
    "Ava Sharma", "Ravi Mehta", "Mira Kapoor", "Chen Liu", "Diya Patel", "Eren Das",
    "Isha Nair", "Arjun Menon", "Leena Rao", "Tom Jacob", "Nina D’Souza", "Om Prakash",
    "Finance", "IT", "HR", "Marketing", "Operations",
    "Analyst", "Software Engineer", "Recruiter", "Senior Analyst", "Executive",
    "Developer", "Coordinator", "Accountant", "Manager", "Support Engineer",
    "Senior Executive", "Supervisor",
    "Delhi", "Bangalore", "Mumbai", "Chennai", "Ahmedabad", "Pune",
    "Hyderabad", "Kochi", "Jaipur",
    45250, 51750, 60890, 38200, 40340, 48680, 67550, 41980, 53110, 49750,
    1000, 1001, 1002, 200, 300, 250,
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")
    func_nodes = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` is missing in main.py."
        func_nodes.append(node)
    found = set()
    for fn_node in func_nodes:
        for node in ast.walk(fn_node):
            if isinstance(node, ast.Constant):
                found.add(node.value)
    overlap = {v for v in found if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")
    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")
    total_match_cases = 0
    for fn_node in func_nodes:
        for inner in ast.walk(fn_node):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p

def _dataset_like_rows():
    return [
        {"emp_id": "E001", "name": "Ava Sharma",    "dept": "Finance",    "role": "Analyst",           "salary": 45250, "exp": 2, "city": "Delhi"},
        {"emp_id": "E002", "name": "Ravi Mehta",    "dept": "IT",         "role": "Software Engineer", "salary": 51750, "exp": 3, "city": "Bangalore"},
        {"emp_id": "E003", "name": "Mira Kapoor",   "dept": "HR",         "role": "Recruiter",         "salary": None,  "exp": 1, "city": "Mumbai"},
        {"emp_id": "E004", "name": "Chen Liu",      "dept": "Finance",    "role": "Senior Analyst",    "salary": 60890, "exp": 5, "city": "Chennai"},
        {"emp_id": "E005", "name": "Diya Patel",    "dept": "Marketing",  "role": "Executive",         "salary": 38200, "exp": 2, "city": "Ahmedabad"},
        {"emp_id": "E006", "name": "Eren Das",      "dept": "IT",         "role": "Developer",         "salary": None,  "exp": 4, "city": "Pune"},
        {"emp_id": "E007", "name": "Isha Nair",     "dept": "Operations", "role": "Coordinator",       "salary": 40340, "exp": 2, "city": "Hyderabad"},
        {"emp_id": "E008", "name": "Arjun Menon",   "dept": "Finance",    "role": "Accountant",        "salary": 48680, "exp": 3, "city": "Kochi"},
        {"emp_id": "E009", "name": "Leena Rao",     "dept": "HR",         "role": "Manager",           "salary": 67550, "exp": 6, "city": "Mumbai"},
        {"emp_id": "E010", "name": "Tom Jacob",     "dept": "IT",         "role": "Support Engineer",  "salary": 41980, "exp": 2, "city": "Bangalore"},
        {"emp_id": "E011", "name": "Nina D’Souza",  "dept": "Marketing",  "role": "Senior Executive",  "salary": 53110, "exp": 4, "city": "Delhi"},
        {"emp_id": "E012", "name": "Om Prakash",    "dept": "Operations", "role": "Supervisor",        "salary": None,  "exp": 5, "city": "Jaipur"},
    ]

def test_fill_dataset_like_values(tmp_path):
    fp = _write_csv(tmp_path, "employees.csv", _dataset_like_rows())
    got = main.fill_missing_salary(str(fp))
    filled = got.loc[got["name"].isin(["Mira Kapoor", "Eren Das", "Om Prakash"]), "salary"].tolist()
    exp = [49750, 49750, 49750]
    assert filled == exp, f"Filled salaries mismatch. expected={exp}, actual={filled}"
    assert pd.api.types.is_integer_dtype(got["salary"]), f"'salary' dtype mismatch. expected=int dtype, actual={got['salary'].dtype}"

def test_round_half_to_even_down(tmp_path):
    fp = _write_csv(tmp_path, "mini.csv", [
        {"name": "Ava Sharma", "salary": 1000},
        {"name": "Ravi Mehta", "salary": 1001},
        {"name": "Mira Kapoor","salary": None},
    ])
    got = main.fill_missing_salary(str(fp))
    actual = int(got.loc[got["name"] == "Mira Kapoor", "salary"].item())
    exp = 1000
    assert actual == exp, f"Bankers rounding down incorrect. expected={exp}, actual={actual}"

def test_round_half_to_even_up(tmp_path):
    fp = _write_csv(tmp_path, "mini.csv", [
        {"name": "Chen Liu", "salary": 1001},
        {"name": "Diya Patel","salary": 1002},
        {"name": "Om Prakash","salary": None},
    ])
    got = main.fill_missing_salary(str(fp))
    actual = int(got.loc[got["name"] == "Om Prakash", "salary"].item())
    exp = 1002
    assert actual == exp, f"Bankers rounding up incorrect. expected={exp}, actual={actual}"

def test_multiple_nans_same_fill(tmp_path):
    fp = _write_csv(tmp_path, "employees.csv", [
        {"name": "A", "salary": 200},
        {"name": "B", "salary": None},
        {"name": "C", "salary": 300},
        {"name": "D", "salary": None},
    ])
    got = main.fill_missing_salary(str(fp))
    filled = got.loc[got["name"].isin(["B","D"]), "salary"].tolist()
    exp = [250, 250]
    assert filled == exp, f"Multiple NaN fills incorrect. expected={exp}, actual={filled}"

def test_all_nan_raises_on_astype(tmp_path):
    fp = _write_csv(tmp_path, "nan_only.csv", [
        {"name": "Ava Sharma", "salary": None},
        {"name": "Ravi Mehta", "salary": None},
    ])
    with pytest.raises((pd.errors.IntCastingNaNError, ValueError, TypeError)):
        _ = main.fill_missing_salary(str(fp))

def test_non_numeric_salary_raises(tmp_path):
    fp = _write_csv(tmp_path, "bad.csv", [
        {"name": "Chen Liu", "salary": "x"},
        {"name": "Diya Patel", "salary": 1000},
    ])
    with pytest.raises(Exception):
        _ = main.fill_missing_salary(str(fp))

def test_row_count_and_columns_preserved(tmp_path):
    fp = _write_csv(tmp_path, "employees.csv", [
        {"emp_id": "E001", "name": "Arjun Menon", "dept": "Finance", "salary": 45250},
        {"emp_id": "E002", "name": "Leena Rao",   "dept": "HR",      "salary": None},
        {"emp_id": "E003", "name": "Tom Jacob",   "dept": "IT",      "salary": 41980},
    ])
    got = main.fill_missing_salary(str(fp))
    exp_rows = 3
    exp_cols = {"emp_id","name","dept","salary"}
    assert len(got) == exp_rows, f"Row count changed. expected={exp_rows}, actual={len(got)}"
    assert set(got.columns) == exp_cols, f"Columns changed. expected={sorted(exp_cols)}, actual={got.columns.tolist()}"

def test_input_file_not_modified(tmp_path):
    fp = _write_csv(tmp_path, "staff.csv", [
        {"name": "Nina D’Souza", "salary": 53110},
        {"name": "Om Prakash",   "salary": None},
    ])
    before = pd.read_csv(fp)
    _ = main.fill_missing_salary(str(fp))
    after = pd.read_csv(fp)
    assert before.equals(after), "Input CSV must remain unchanged by the function. expected=unchanged, actual=modified"

def test_return_type_dataframe(tmp_path):
    fp = _write_csv(tmp_path, "employees.csv", [
        {"name": "Ava Sharma", "salary": 45250},
        {"name": "Ravi Mehta", "salary": 51750},
    ])
    got = main.fill_missing_salary(str(fp))
    assert isinstance(got, pd.DataFrame), f"Return type incorrect. expected=pandas.DataFrame, actual={type(got).__name__}"

def test_large_dataset_no_nulls_after_fill(tmp_path):
    rows = []
    for i in range(1, 601):
        rows.append({"name": f"Emp{i}", "salary": (i if i % 6 else None)})
    fp = _write_csv(tmp_path, "large.csv", rows)
    got = main.fill_missing_salary(str(fp))
    nulls_after = got["salary"].isna().sum()
    assert nulls_after == 0, f"All NaNs must be filled. expected=0, actual={nulls_after}"
    assert pd.api.types.is_integer_dtype(got["salary"]), f"'salary' dtype incorrect. expected=int dtype, actual={got['salary'].dtype}"
