import numpy as np

# def extract_even_numbers(data):
#     arr = np.array(data)
#     evens = arr[arr % 2 == 0]
#     return evens

# if __name__ == "__main__":
#     numbers = [3, 8, 11, 14, 19, 20]
#     result = extract_even_numbers(numbers)
#     print(result)

import numpy as np

def extract_even_numbers(data):
    """
    Extracts even numbers from a numeric collection (list or numpy array).

    Parameters:
        data (list or numpy.ndarray): Collection of integer values.

    Returns:
        numpy.ndarray: Array of even numbers, preserving original order.
    """
    arr = np.array(data)  # Convert input to NumPy array
    even_mask = (arr % 2 == 0)  # Vectorized check for evenness
    return arr[even_mask]  # Return filtered array
