# tests.py
import ast
import re
from pathlib import Path
import numpy as np
import pytest
import main

FUNCTIONS = ["extract_even_numbers"]

HARD_CODE_LITERALS = {
    100, 101, 102, 103, 104, 105, 106, 107, 108, 109,
    110, 111, 112, 113, 114, 115, 116, 117, 118, 119,
    120, 121, 122, 123, 124, 125, 126, 127, 128, 129,
    130, 131, 132, 133, 134, 135, 136, 137, 138, 139,
    140, 141, 142, 143, 144, 145, 146, 147, 148, 149,
    150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
    160, 161, 162, 163, 164, 165, 166, 167, 168, 169,
    170, 171, 172, 173, 174, 175, 176, 177, 178, 179,
    180, 181, 182, 183, 184, 185, 186, 187, 188, 189,
    190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        n = _get_fn(tree, fn)
        assert n is not None, f"Required function `{fn}` missing in main.py."
        func_bodies.append(n)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def test_basic_even_extraction():
    data = [101, 108, 115, 124, 139, 140]
    got = main.extract_even_numbers(data)
    exp = np.array([108, 124, 140])
    assert np.array_equal(got, exp), f"Incorrect even extraction. expected={exp.tolist()}, actual={got.tolist()}"

def test_all_even_numbers():
    data = [102, 104, 106, 108, 110]
    got = main.extract_even_numbers(data)
    exp = np.array(data)
    assert np.array_equal(got, exp), f"Expected all elements to remain. expected={exp.tolist()}, actual={got.tolist()}"

def test_all_odd_numbers_returns_empty():
    data = [101, 103, 105, 107, 109]
    got = main.extract_even_numbers(data)
    assert got.size == 0, f"Expected empty array for all-odd input, got {got.tolist()}"

def test_mixed_large_numbers():
    data = [150, 175, 180, 195, 200]
    got = main.extract_even_numbers(data)
    exp = np.array([150, 180, 200])
    assert np.array_equal(got, exp), f"Incorrect evens from mixed large numbers. expected={exp.tolist()}, actual={got.tolist()}"

def test_negative_and_zero_values():
    data = [-200, -199, -198, 0, 101, 102]
    got = main.extract_even_numbers(data)
    exp = np.array([-200, -198, 0, 102])
    assert np.array_equal(got, exp), f"Incorrect even extraction including negatives/zero. expected={exp.tolist()}, actual={got.tolist()}"

def test_empty_list_input():
    data = []
    got = main.extract_even_numbers(data)
    assert got.size == 0, f"Expected empty output for empty list, got {got.tolist()}"

def test_numpy_array_input():
    data = np.array([112, 113, 114, 115, 116])
    got = main.extract_even_numbers(data)
    exp = np.array([112, 114, 116])
    assert np.array_equal(got, exp), f"Incorrect even extraction for numpy input. expected={exp.tolist()}, actual={got.tolist()}"

def test_return_type_is_numpy_array():
    data = [120, 121, 122, 123]
    got = main.extract_even_numbers(data)
    assert isinstance(got, np.ndarray), f"Return type mismatch. expected=np.ndarray, actual={type(got)}"

def test_result_contains_only_even_numbers():
    data = [191, 192, 193, 194, 195, 196]
    got = main.extract_even_numbers(data)
    assert np.all(got % 2 == 0), f"Output contains odd numbers. actual={got.tolist()}"

def test_input_not_mutated():
    data = [130, 132, 135, 137, 140, 142]
    orig_copy = list(data)
    _ = main.extract_even_numbers(data)
    assert data == orig_copy, f"Input list was modified. expected={orig_copy}, actual={data}"
