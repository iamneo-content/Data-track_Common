# import pandas as pd

# def revenue_pivot_with_rank() -> pd.DataFrame:
#     sales_df = pd.read_csv("store_revenue.csv")
#     pvt = pd.pivot_table(
#         sales_df,
#         values="revenue",
#         index="store",
#         columns="quarter",
#         aggfunc="sum",
#         fill_value=0,
#     )
#     pvt["Total"] = pvt.sum(axis=1)
#     pvt["RevenueRank"] = pvt["Total"].rank(ascending=False, method="dense")
#     pvt = pvt.sort_values(["RevenueRank", "Total"], ascending=[True, False])
#     return pvt

# if __name__ == "__main__":
#     result_cod2 = revenue_pivot_with_rank()
#     print(result_cod2)


import pandas as pd

def revenue_pivot_with_rank() -> pd.DataFrame:
    # Read CSV into DataFrame
    df = pd.read_csv('store_revenue.csv')
    
    # Pivot to wide format, sum duplicate store–quarter pairs
    pivot = df.pivot_table(
        index='store',
        columns='quarter',
        values='revenue',
        aggfunc='sum',
        fill_value=0
    )

    # Ensure quarter columns appear in the expected order (sort alphabetically if needed)
    pivot = pivot.sort_index(axis=1)

    # Add Total column
    pivot['Total'] = pivot.sum(axis=1)

    # Add RevenueRank column (dense, descending by Total, 1 is highest revenue)
    # Rank method='dense', ascending=False (largest total gets rank 1)
    pivot['RevenueRank'] = pivot['Total'].rank(method='dense', ascending=False)

    # Sort by RevenueRank ascending, then Total descending
    pivot = pivot.sort_values(['RevenueRank', 'Total'], ascending=[True, False])

    return pivot

if __name__ == "__main__":
    df_result = revenue_pivot_with_rank()
    print(df_result)
