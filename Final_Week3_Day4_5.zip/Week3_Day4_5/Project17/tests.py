# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["revenue_pivot_with_rank"]

HARD_CODE_LITERALS = {
    "mini.csv", "partial.csv", "ties.csv", "missing.csv", "empty.csv", "big.csv",
    "Store_A", "Store_B", "Store_C", "Store_D", "Store_E",
    42000, 46000, 38000, 51000,
    40000, 36000, 37000,
    52000, 54000, 49000, 58000,
    25000, 29000, 30000, 31000,
    47000,
    100, 200, 300, 150, 500, 1000, 1500, 2000, 222, 333, 444, 111,
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")
    func_nodes = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` is missing in main.py."
        func_nodes.append(node)
    found = set()
    for fn_node in func_nodes:
        for node in ast.walk(fn_node):
            if isinstance(node, ast.Constant):
                found.add(node.value)
    overlap = {v for v in found if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")
    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")
    total_match_cases = 0
    for fn_node in func_nodes:
        for inner in ast.walk(fn_node):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_sales(tmp_path: Path, rows: list[dict], name: str = "store_revenue.csv") -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p

def test_basic_pivot_totals_and_dense_rank(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales(tmp_path, [
        {"store": "Store_A", "quarter": "Q1", "revenue": 42000},
        {"store": "Store_A", "quarter": "Q4", "revenue": 51000},
        {"store": "Store_B", "quarter": "Q2", "revenue": 40000},
        {"store": "Store_B", "quarter": "Q4", "revenue": 37000},
        {"store": "Store_C", "quarter": "Q1", "revenue": 52000},
        {"store": "Store_C", "quarter": "Q2", "revenue": 54000},
    ])
    got = main.revenue_pivot_with_rank()
    for col in ["Total", "RevenueRank"]:
        assert col in got.columns, f"Missing required column. expected contains '{col}', actual={got.columns.tolist()}"
    exp_total_c = 52000 + 54000
    actual_total_c = int(got.loc["Store_C", "Total"])
    assert actual_total_c == exp_total_c, f"Total for Store_C incorrect. expected={exp_total_c}, actual={actual_total_c}"
    exp_ranks = {"Store_C": 1.0, "Store_A": 2.0, "Store_B": 3.0}
    actual = {idx: float(val) for idx, val in got["RevenueRank"].to_dict().items()}
    assert actual == exp_ranks, f"RevenueRank incorrect. expected={exp_ranks}, actual={actual}"

def test_fill_value_zero_for_missing_quarters(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales(tmp_path, [
        {"store": "Store_A", "quarter": "Q1", "revenue": 111},
        {"store": "Store_A", "quarter": "Q3", "revenue": 222},
        {"store": "Store_B", "quarter": "Q2", "revenue": 333},
    ])
    got = main.revenue_pivot_with_rank()
    assert int(got.loc["Store_A", "Q2"]) == 0, f"Missing quarter must be filled with 0. expected=0, actual={got.loc['Store_A','Q2']}"
    assert int(got.loc["Store_B", "Q1"]) == 0, f"Missing quarter must be filled with 0. expected=0, actual={got.loc['Store_B','Q1']}"
    assert int(got.loc["Store_B", "Q3"]) == 0, f"Missing quarter must be filled with 0. expected=0, actual={got.loc['Store_B','Q3']}"

def test_sorting_by_rank_then_total_desc(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales(tmp_path, [
        {"store": "Store_A", "quarter": "Q1", "revenue": 300},
        {"store": "Store_A", "quarter": "Q2", "revenue": 300},
        {"store": "Store_B", "quarter": "Q1", "revenue": 200},
        {"store": "Store_B", "quarter": "Q2", "revenue": 300},
        {"store": "Store_C", "quarter": "Q1", "revenue": 250},
        {"store": "Store_C", "quarter": "Q2", "revenue": 250},
    ])
    got = main.revenue_pivot_with_rank()
    exp_order = ["Store_A", "Store_B", "Store_C"]
    actual_order = got.index.tolist()
    assert actual_order == exp_order, f"Sorting by RevenueRank then Total failed. expected={exp_order}, actual={actual_order}"

def test_dense_ties_share_same_rank(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales(tmp_path, [
        {"store": "Store_A", "quarter": "Q1", "revenue": 100},
        {"store": "Store_A", "quarter": "Q2", "revenue": 200},
        {"store": "Store_B", "quarter": "Q1", "revenue": 150},
        {"store": "Store_B", "quarter": "Q4", "revenue": 150},
        {"store": "Store_C", "quarter": "Q3", "revenue": 100},
    ])
    got = main.revenue_pivot_with_rank()
    exp = {"Store_A": 1.0, "Store_B": 1.0, "Store_C": 2.0}
    actual = {idx: float(val) for idx, val in got["RevenueRank"].to_dict().items()}
    assert actual == exp, f"Dense ranking with ties incorrect. expected={exp}, actual={actual}"

def test_includes_total_and_rank_and_index(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales(tmp_path, [
        {"store": "Store_A", "quarter": "Q1", "revenue": 42000},
        {"store": "Store_B", "quarter": "Q2", "revenue": 40000},
    ])
    got = main.revenue_pivot_with_rank()
    for col in ["Total", "RevenueRank"]:
        assert col in got.columns, f"Pivot missing required column. expected contains '{col}', actual={got.columns.tolist()}"
    assert "Store_A" in got.index and "Store_B" in got.index, (
        f"Index stores missing. expected to include Store_A and Store_B, actual={got.index.tolist()}"
    )

def test_return_type_dataframe(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales(tmp_path, [{"store": "Store_A", "quarter": "Q1", "revenue": 42000}])
    got = main.revenue_pivot_with_rank()
    assert isinstance(got, pd.DataFrame), f"Return type incorrect. expected=pandas.DataFrame, actual={type(got).__name__}"

def test_input_file_not_modified(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = [
        {"store": "Store_A", "quarter": "Q1", "revenue": 42000},
        {"store": "Store_A", "quarter": "Q2", "revenue": 46000},
        {"store": "Store_B", "quarter": "Q1", "revenue": 38000},
    ]
    p = _write_sales(tmp_path, rows)
    before = pd.read_csv(p)
    _ = main.revenue_pivot_with_rank()
    after = pd.read_csv(p)
    assert before.equals(after), "Input CSV must not be modified by the function. expected=unchanged, actual=modified"

def test_empty_file_raises_emptydataerror(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    p = tmp_path / "empty.csv"
    p.write_text("", encoding="utf-8")
    with pytest.raises(pd.errors.EmptyDataError):
        pd.read_csv(p)
    p.rename(tmp_path / "store_revenue.csv")
    with pytest.raises(pd.errors.EmptyDataError):
        _ = main.revenue_pivot_with_rank()

def test_missing_required_column_raises(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales(tmp_path, [
        {"store": "Store_A", "revenue": 42000},
        {"store": "Store_B", "revenue": 38000},
    ])
    with pytest.raises((KeyError, TypeError)):
        _ = main.revenue_pivot_with_rank()


def test_aggregation_sums_duplicate_rows(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales(tmp_path, [
        {"store": "Store_A", "quarter": "Q1", "revenue": 1000},
        {"store": "Store_A", "quarter": "Q1", "revenue": 500},
        {"store": "Store_A", "quarter": "Q2", "revenue": 2000},
        {"store": "Store_B", "quarter": "Q1", "revenue": 3000},
    ])
    got = main.revenue_pivot_with_rank()
    exp_q1_a = 1500
    actual_q1_a = int(got.loc["Store_A", "Q1"])
    assert actual_q1_a == exp_q1_a, f"Aggregation over duplicate rows failed for Q1. expected={exp_q1_a}, actual={actual_q1_a}"
    exp_total_a = 1500 + 2000
    actual_total_a = int(got.loc["Store_A", "Total"])
    assert actual_total_a == exp_total_a, f"Total aggregation failed. expected={exp_total_a}, actual={actual_total_a}"

def test_sorted_by_rank_then_total_for_prompt_like_data(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_sales(tmp_path, [
        {"store": "Store_A", "quarter": "Q1", "revenue": 42000},
        {"store": "Store_A", "quarter": "Q2", "revenue": 46000},
        {"store": "Store_A", "quarter": "Q3", "revenue": 38000},
        {"store": "Store_A", "quarter": "Q4", "revenue": 51000},
        {"store": "Store_B", "quarter": "Q1", "revenue": 38000},
        {"store": "Store_B", "quarter": "Q2", "revenue": 40000},
        {"store": "Store_B", "quarter": "Q3", "revenue": 36000},
        {"store": "Store_B", "quarter": "Q4", "revenue": 37000},
        {"store": "Store_C", "quarter": "Q1", "revenue": 52000},
        {"store": "Store_C", "quarter": "Q2", "revenue": 54000},
        {"store": "Store_C", "quarter": "Q3", "revenue": 49000},
        {"store": "Store_C", "quarter": "Q4", "revenue": 58000},
        {"store": "Store_D", "quarter": "Q1", "revenue": 25000},
        {"store": "Store_D", "quarter": "Q2", "revenue": 29000},
        {"store": "Store_D", "quarter": "Q3", "revenue": 30000},
        {"store": "Store_D", "quarter": "Q4", "revenue": 31000},
        {"store": "Store_E", "quarter": "Q1", "revenue": 46000},
        {"store": "Store_E", "quarter": "Q2", "revenue": 47000},
        {"store": "Store_E", "quarter": "Q3", "revenue": 49000},
        {"store": "Store_E", "quarter": "Q4", "revenue": 52000},
    ])
    got = main.revenue_pivot_with_rank()
    exp_order = ["Store_C", "Store_E", "Store_A", "Store_B", "Store_D"]
    actual_order = got.index.tolist()
    assert actual_order == exp_order, f"Final sort by RevenueRank then Total incorrect. expected={exp_order}, actual={actual_order}"
