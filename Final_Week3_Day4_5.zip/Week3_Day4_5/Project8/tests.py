# tests.py
import ast
import re
from pathlib import Path
import numpy as np
import pytest
import main

FUNCTIONS = ["merge_and_sort"]

HARD_CODE_LITERALS = {
    100, 101, 102, 103, 104, 105,
    110, 115, 120, 125, 130, 135, 140, 145, 150,
    155, 160, 165, 170, 175, 180, 185, 190, 195, 200
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` missing in main.py."
        func_bodies.append(node)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def test_basic_merge_and_sort():
    a = np.array([120, 150, 130])
    b = np.array([140, 110])
    got = main.merge_and_sort(a, b)
    exp = np.array(sorted([120, 150, 130, 140, 110]))
    assert np.array_equal(got, exp), f"Incorrect merge or sort. expected={exp.tolist()}, actual={got.tolist()}"

def test_merge_with_empty_first_array():
    a = np.array([])
    b = np.array([160, 170, 180])
    got = main.merge_and_sort(a, b)
    exp = np.array([160, 170, 180])
    assert np.array_equal(got, exp), f"Expected only b elements when a empty. expected={exp.tolist()}, actual={got.tolist()}"

def test_merge_with_empty_second_array():
    a = np.array([180, 190, 200])
    b = np.array([])
    got = main.merge_and_sort(a, b)
    exp = np.array([180, 190, 200])
    assert np.array_equal(got, exp), f"Expected only a elements when b empty. expected={exp.tolist()}, actual={got.tolist()}"

def test_merge_with_duplicates():
    a = np.array([150, 160, 160])
    b = np.array([155, 150])
    got = main.merge_and_sort(a, b)
    exp = np.array(sorted([150, 160, 160, 155, 150]))
    assert np.array_equal(got, exp), f"Incorrect handling of duplicates. expected={exp.tolist()}, actual={got.tolist()}"

def test_merge_negative_numbers():
    a = np.array([-100, 110, 120])
    b = np.array([-150, 130])
    got = main.merge_and_sort(a, b)
    exp = np.array(sorted([-100, 110, 120, -150, 130]))
    assert np.array_equal(got, exp), f"Incorrect handling of negatives. expected={exp.tolist()}, actual={got.tolist()}"

def test_merge_large_numbers():
    a = np.array([150, 160, 170])
    b = np.array([180, 190, 200])
    got = main.merge_and_sort(a, b)
    exp = np.array([150, 160, 170, 180, 190, 200])
    assert np.array_equal(got, exp), f"Incorrect sorting for large values. expected={exp.tolist()}, actual={got.tolist()}"

def test_unsorted_inputs_become_sorted():
    a = np.array([180, 110, 150])
    b = np.array([175, 120])
    got = main.merge_and_sort(a, b)
    exp = np.array(sorted([180, 110, 150, 175, 120]))
    assert np.array_equal(got, exp), f"Output not sorted ascending. expected={exp.tolist()}, actual={got.tolist()}"

def test_output_type_is_numpy_array():
    a = np.array([140, 150])
    b = np.array([130, 120])
    got = main.merge_and_sort(a, b)
    assert isinstance(got, np.ndarray), f"Return type mismatch. expected=np.ndarray, actual={type(got)}"

def test_no_modification_to_inputs():
    a = np.array([120, 130, 140])
    b = np.array([150, 160])
    a_copy = a.copy()
    b_copy = b.copy()
    _ = main.merge_and_sort(a, b)
    assert np.array_equal(a, a_copy) and np.array_equal(b, b_copy), f"Input arrays modified. expected a={a_copy.tolist()}, b={b_copy.tolist()}, actual a={a.tolist()}, b={b.tolist()}"

def test_merge_randomized_order():
    a = np.array([125, 145, 135])
    b = np.array([155, 115])
    got = main.merge_and_sort(a, b)
    exp = np.array(sorted([125, 145, 135, 155, 115]))
    assert np.array_equal(got, exp), f"Incorrect sorted order with mixed values. expected={exp.tolist()}, actual={got.tolist()}"
