# import numpy as np

# def merge_and_sort(arr1: np.ndarray, arr2: np.ndarray) -> np.ndarray:
#     merged = np.concatenate((arr1, arr2))
#     sorted_array = np.sort(merged)
#     return sorted_array

# if __name__ == "__main__":
#     a = np.array([5, 1, 3])
#     b = np.array([4, 2])
#     output = merge_and_sort(a, b)
#     print(output)


import numpy as np

def merge_and_sort(arr1: np.ndarray, arr2: np.ndarray) -> np.ndarray:
    """
    Concatenate two numeric 1-D NumPy arrays and return a sorted (ascending) array.
    The original arrays are not mutated.
    """
    merged = np.concatenate((arr1, arr2))
    sorted_merged = np.sort(merged)
    return sorted_merged

if __name__ == "__main__":
    # Example 1
    arr1 = np.array([120, 150, 130])
    arr2 = np.array([140, 110])
    print("Example 1:", merge_and_sort(arr1, arr2))  # Output: [110 120 130 140 150]

    # Example 2
    arr1 = np.array([])
    arr2 = np.array([160, 170, 180])
    print("Example 2:", merge_and_sort(arr1, arr2))  # Output: [160 170 180]

    # Example 3
    arr1 = np.array([150, 160, 160])
    arr2 = np.array([155, 150])
    print("Example 3:", merge_and_sort(arr1, arr2))  # Output: [150 150 155 160 160]

    # Example 4
    arr1 = np.array([-100, 110, 120])
    arr2 = np.array([-150, 130])
    print("Example 4:", merge_and_sort(arr1, arr2))  # Output: [-150 -100  110  120  130]
