def count_words_in_file(filename):
    with open(filename, "r") as f:
        content = f.read()
        words = content.split()
        return len(words)

if __name__ == "__main__":
    result = count_words_in_file("notes.txt")
    print(result)