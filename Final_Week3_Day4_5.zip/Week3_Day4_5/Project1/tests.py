# tests.py
import ast
import re
from pathlib import Path
import pytest
import main

FUNCTIONS = ["count_words_in_file"]

HARD_CODE_LITERALS = {
    "a.txt", "b.txt", "empty.txt", "punct.txt", "unicode.txt", "large.txt", "missing.txt", "ws.txt", "win.txt", "notes.txt",
    "hello", "world", "hello,", "world!", "python.", "it's",
    "one", "two", "three", "four",
    "Café", "naïve", "résumé", "co-operate",
    "alpha", "beta", "gamma",
    0, 2, 3, 4, 10000,
}

ELIF_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root; ensure the file is named 'main.py'."
    return p.read_text(encoding="utf-8")

def _get_function_node(tree: ast.AST, name: str) -> ast.FunctionDef | None:
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        fn_node = _get_function_node(tree, fn)
        assert fn_node is not None, f"Required function `{fn}` is missing in main.py."
        func_bodies.append(fn_node)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > 6:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit 6)")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write(tmp_path: Path, name: str, text: str) -> Path:
    p = tmp_path / name
    p.write_text(text, encoding="utf-8", newline="\n")
    return p

def test_basic_two_tokens(tmp_path):
    fp = _write(tmp_path, "a.txt", "hello world")
    got = main.count_words_in_file(str(fp))
    exp = 2
    assert got == exp, f"Expected {exp} words for 'hello world', got {got}."

def test_mixed_whitespace(tmp_path):
    fp = _write(tmp_path, "b.txt", "one  two\tthree\nfour")
    got = main.count_words_in_file(str(fp))
    exp = 4
    assert got == exp, f"Whitespace splitting incorrect: expected {exp} tokens, got {got}."

def test_trimmed_whitespace(tmp_path):
    fp = _write(tmp_path, "ws.txt", "   a b c   ")
    got = main.count_words_in_file(str(fp))
    exp = 3
    assert got == exp, f"Leading/trailing whitespace handling failed: expected {exp}, got {got}."

def test_empty_file(tmp_path):
    fp = _write(tmp_path, "empty.txt", "")
    got = main.count_words_in_file(str(fp))
    exp = 0
    assert got == exp, f"Empty file should yield {exp} words, got {got}."

def test_punctuation_tokens(tmp_path):
    fp = _write(tmp_path, "punct.txt", "hello, world! it's python.")
    got = main.count_words_in_file(str(fp))
    exp = 4
    assert got == exp, f"Punctuation with whitespace split should yield {exp} tokens, got {got}."

def test_unicode_and_hyphen(tmp_path):
    fp = _write(tmp_path, "unicode.txt", "Café naïve résumé co-operate")
    got = main.count_words_in_file(str(fp))
    exp = 4
    assert got == exp, f"Unicode/hyphenated words should count as {exp}, got {got}."

def test_large_repetition(tmp_path):
    text = ("hello " * 10000).strip()
    fp = _write(tmp_path, "large.txt", text)
    got = main.count_words_in_file(str(fp))
    exp = 10000
    assert got == exp, f"Large file count incorrect: expected {exp}, got {got}."

def test_missing_file_raises(tmp_path):
    missing = tmp_path / "missing.txt"
    with pytest.raises(FileNotFoundError):
        _ = main.count_words_in_file(str(missing))

def test_whitespace_only_lines(tmp_path):
    fp = _write(tmp_path, "ws.txt", "\n \n\t \n")
    got = main.count_words_in_file(str(fp))
    exp = 0
    assert got == exp, f"Whitespace-only file should count as {exp}, got {got}."

def test_crlf_newlines(tmp_path):
    p = tmp_path / "win.txt"
    p.write_bytes(b"alpha\r\nbeta\r\ngamma")
    got = main.count_words_in_file(str(p))
    exp = 3
    assert got == exp, f"CRLF handling failed: expected {exp} tokens, got {got}."
