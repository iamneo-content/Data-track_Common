# import numpy as np

# def row_max_values(matrix: np.ndarray) -> np.ndarray:
#     max_values = np.max(matrix, axis=1)
#     return max_values

# if __name__ == "__main__":
#     mat = np.array([[1, 3, 5],
#                     [7, 2, 9],
#                     [4, 6, 8]])
#     output = row_max_values(mat)
#     print(output)

import numpy as np

def row_max_values(matrix: np.ndarray) -> np.ndarray:
    """
    Returns a 1D array containing the maximum value from each row of the input 2D NumPy array.

    Parameters:
    matrix (np.ndarray): A 2D numeric NumPy array.

    Returns:
    np.ndarray: A 1D array with the maximum value from each row.
    """
    return np.max(matrix, axis=1)

if __name__ == "__main__":
    # Example 1
    input1 = np.array([[1, 3, 5],
                       [7, 2, 9],
                       [4, 6, 8]])
    print(row_max_values(input1))  # Output: [5 9 8]

    # Example 2
    input2 = np.array([[10, 20, 30, 40]])
    print(row_max_values(input2))  # Output: [40]

    # Example 3
    input3 = np.array([[5],
                       [10],
                       [15]])
    print(row_max_values(input3))  # Output: [5 10 15]
