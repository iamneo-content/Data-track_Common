# tests.py
from __future__ import annotations
import ast
import re
from pathlib import Path
import numpy as np
import pytest
import main

FUNCTIONS = ["row_max_values"]

HARD_CODE_LITERALS = {
    100, 101, 102, 103, 104, 105, 106, 107, 108, 109,
    110, 111, 112, 113, 114, 115, 116, 117, 118, 119,
    120, 121, 122, 123, 124, 125, 126, 127, 128, 129,
    130, 131, 132, 133, 134, 135, 136, 137, 138, 139,
    140, 141, 142, 143, 144, 145, 146, 147, 148, 149,
    150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
    160, 161, 162, 163, 164, 165, 166, 167, 168, 169,
    170, 171, 172, 173, 174, 175, 176, 177, 178, 179,
    180, 181, 182, 183, 184, 185, 186, 187, 188, 189,
    190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        n = _get_fn(tree, fn)
        assert n is not None, f"Required function `{fn}` missing in main.py."
        func_bodies.append(n)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def test_basic_row_max():
    mat = np.array([[101, 105, 103],
                    [150, 120, 180],
                    [111, 190, 115]])
    got = main.row_max_values(mat)
    exp = np.array([105, 180, 190])
    assert np.array_equal(got, exp), f"Incorrect row maxima. expected={exp.tolist()}, actual={got.tolist()}"

def test_single_row_matrix():
    mat = np.array([[140, 142, 180, 150]])
    got = main.row_max_values(mat)
    exp = np.array([180])
    assert np.array_equal(got, exp), f"Incorrect max for single row. expected={exp.tolist()}, actual={got.tolist()}"

def test_single_column_matrix():
    mat = np.array([[120], [130], [140], [150]])
    got = main.row_max_values(mat)
    exp = np.array([120, 130, 140, 150])
    assert np.array_equal(got, exp), f"Incorrect max for single column. expected={exp.tolist()}, actual={got.tolist()}"

def test_all_equal_values():
    mat = np.full((3, 4), 150)
    got = main.row_max_values(mat)
    exp = np.array([150, 150, 150])
    assert np.array_equal(got, exp), f"Incorrect max when all elements equal. expected={exp.tolist()}, actual={got.tolist()}"

def test_negative_values():
    mat = np.array([[-120, -140, -130],
                    [-180, -150, -160],
                    [-190, -200, -170]])
    got = main.row_max_values(mat)
    exp = np.array([-120, -150, -170])
    assert np.array_equal(got, exp), f"Incorrect max for negative values. expected={exp.tolist()}, actual={got.tolist()}"

def test_mixed_positive_negative():
    mat = np.array([[-150, 120, -130],
                    [180, -190, 170],
                    [-160, 175, 165]])
    got = main.row_max_values(mat)
    exp = np.array([120, 180, 175])
    assert np.array_equal(got, exp), f"Incorrect max for mixed positive/negative. expected={exp.tolist()}, actual={got.tolist()}"

def test_large_matrix():
    mat = np.arange(100, 145).reshape(5, 9)
    got = main.row_max_values(mat)
    exp = np.max(mat, axis=1)
    assert np.array_equal(got, exp), f"Incorrect max for large matrix. expected={exp.tolist()}, actual={got.tolist()}"

def test_return_type_numpy_array():
    mat = np.array([[101, 102], [103, 104]])
    got = main.row_max_values(mat)
    assert isinstance(got, np.ndarray), f"Return type mismatch. expected=np.ndarray, actual={type(got)}"

def test_shape_of_output():
    mat = np.array([[111, 112, 113],
                    [121, 122, 123],
                    [131, 132, 133]])
    got = main.row_max_values(mat)
    exp_shape = (3,)
    assert got.shape == exp_shape, f"Incorrect output shape. expected={exp_shape}, actual={got.shape}"

def test_does_not_modify_input():
    mat = np.array([[150, 160, 170],
                    [180, 190, 200]])
    original = mat.copy()
    _ = main.row_max_values(mat)
    assert np.array_equal(mat, original), f"Input matrix modified. expected={original.tolist()}, actual={mat.tolist()}"
