# tests.py
import ast
import re
from pathlib import Path
import numpy as np
import pytest
import main

FUNCTIONS = ["extract_middle_row"]

HARD_CODE_LITERALS = {
    22, 24, 26, 23, 25, 27, 21,
    6, 7, 8,
    -3, -2, -1, 0, 10, 11, 12, 13, 14, 15,
    100, 101, 102, 103, 104, 105, 106, 107, 108
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_function_node(tree: ast.AST, name: str):
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")
    func_bodies = []
    for fn in FUNCTIONS:
        n = _get_function_node(tree, fn)
        assert n is not None, f"Required function `{fn}` missing in main.py."
        func_bodies.append(n)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def test_basic_middle_row_from_list():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    got = main.extract_middle_row(data)
    exp = np.array([4, 5, 6])
    assert isinstance(got, np.ndarray), f"Return type mismatch. expected=numpy.ndarray, actual={type(got).__name__}"
    assert got.shape == (3,), f"Shape mismatch. expected=(3,), actual={got.shape}"
    assert np.array_equal(got, exp), f"Middle row values incorrect. expected={exp.tolist()}, actual={got.tolist()}"

def test_accepts_numpy_array_input():
    data = np.array([22, 24, 26, 23, 25, 27, 21, 22, 23])
    got = main.extract_middle_row(data)
    exp = np.array([23, 25, 27])
    assert np.array_equal(got, exp), f"Middle row incorrect for numpy input. expected={exp.tolist()}, actual={got.tolist()}"

def test_accepts_nested_lists_input():
    data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    got = main.extract_middle_row(data)
    exp = np.array([4, 5, 6])
    assert np.array_equal(got, exp), f"Middle row incorrect for nested lists. expected={exp.tolist()}, actual={got.tolist()}"

def test_different_numbers_middle_row():
    data = [100, 101, 102, 103, 104, 105, 106, 107, 108]
    got = main.extract_middle_row(data)
    exp = np.array([103, 104, 105])
    assert np.array_equal(got, exp), f"Middle row values mismatch. expected={exp.tolist()}, actual={got.tolist()}"

def test_handles_negative_and_zero():
    data = [-3, -2, -1, 0, 1, 2, 3, 4, 5]
    got = main.extract_middle_row(data)
    exp = np.array([0, 1, 2])
    assert np.array_equal(got, exp), f"Middle row with negatives/zero incorrect. expected={exp.tolist()}, actual={got.tolist()}"

def test_reshape_error_when_not_9_elements_short():
    data = [1, 2, 3, 4, 5, 6, 7, 8]
    with pytest.raises(ValueError) as e:
        _ = main.extract_middle_row(data)
    assert e.value is not None, f"Expected ValueError for non-9 length input (short). expected=ValueError, actual=None"

def test_reshape_error_when_not_9_elements_long():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    with pytest.raises(ValueError) as e:
        _ = main.extract_middle_row(data)
    assert e.value is not None, f"Expected ValueError for non-9 length input (long). expected=ValueError, actual=None"

def test_output_is_view_or_copy_independent_content():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    out = main.extract_middle_row(data)
    exp = [4, 5, 6]
    assert out.tolist() == exp, f"Content mismatch. expected={exp}, actual={out.tolist()}"

def test_order_preserved_in_middle_row():
    data = [10, 11, 12, 13, 14, 15, 7, 8, 9]
    got = main.extract_middle_row(data)
    exp = np.array([13, 14, 15])
    assert np.array_equal(got, exp), f"Order in middle row incorrect. expected={exp.tolist()}, actual={got.tolist()}"

def test_input_not_modified():
    original = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    data = original.copy()
    _ = main.extract_middle_row(data)
    assert data == original, f"Input mutated. expected={original}, actual={data}"
