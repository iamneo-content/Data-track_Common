# import numpy as np

# def extract_middle_row(data):
#     arr = np.array(data).reshape(3, 3)
#     middle_row = arr[1, :]
#     return middle_row

# if __name__ == "__main__":
#     readings = [22, 24, 26, 23, 25, 27, 21, 22, 23]
#     result = extract_middle_row(readings)
#     print(result)

# import numpy as np

# def extract_middle_row(data) -> np.ndarray:
#     # Convert input to a NumPy array (non-mutating)
#     arr = np.array(data)
#     # Reshape to (3, 3); will raise ValueError if not possible
#     arr_3x3 = arr.reshape(3, 3)
#     # Return the middle row (second row, index 1)
#     return arr_3x3[1]

# if __name__ == "__main__":
#     # Example 1
#     data1 = [1, 2, 3, 4, 5, 6, 7, 8, 9]
#     print(extract_middle_row(data1))  # Output: [4 5 6]
    
#     # Example 2
#     data2 = np.array([10, 11, 12, 13, 14, 15, 7, 8, 9])
#     print(extract_middle_row(data2))  # Output: [13 14 15]
    
#     # Example 3
#     data3 = [[2, 4, 6], [1, 3, 5], [0, 8, 9]]
#     print(extract_middle_row(data3))  # Output: [1 3 5]
    
#     # Example 4 (should raise ValueError)
#     data4 = [1, 2, 3, 4, 5, 6, 7, 8]
#     try:
#         print(extract_middle_row(data4))
#     except ValueError as e:
#         print(repr(e))  # Output: ValueError 

import numpy as np

def extract_middle_row(data):
    # Convert input to a NumPy array (using copy to avoid mutation)
    arr = np.array(data, copy=True)
    
    # Validate total number of elements
    if arr.size != 9:
        raise ValueError("Input must contain exactly 9 elements.")
    
    # Reshape to 3x3 if necessary
    arr_3x3 = arr.reshape((3, 3))
    
    # Extract middle row (row index 1)
    middle_row = arr_3x3[1].copy()
    
    return middle_row

if __name__ == "__main__":
    # Example 1: Flat list
    data1 = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    print(extract_middle_row(data1))  # Output: [4 5 6]
    
    # Example 2: Flat NumPy array
    data2 = np.array([10, 11, 12, 13, 14, 15, 7, 8, 9])
    print(extract_middle_row(data2))  # Output: [13 14 15]
    
    # Example 3: Nested list
    data3 = [[2, 4, 6], [1, 3, 5], [0, 8, 9]]
    print(extract_middle_row(data3))  # Output: [1 3 5]
    
    # Example 4: Tuple
    data4 = (1, 2, 3, 4, 5, 6, 7, 8, 9)
    print(extract_middle_row(data4))  # Output: [4 5 6]
