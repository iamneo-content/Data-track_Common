# import pandas as pd

# def clean_city_data(csv_path):
#     df = pd.read_csv(csv_path)
#     df["city"] = df["city"].astype("string").str.strip().str.title()
#     df = df.drop_duplicates(subset=["city"]).reset_index(drop=True)
#     return df


# if __name__ == "__main__":
#     result_df = clean_city_data("cities.csv")
#     print(result_df)


import pandas as pd

def clean_city_data(csv_path: str) -> pd.DataFrame:
    # Read CSV into a DataFrame
    df = pd.read_csv(csv_path)
    # Ensure 'city' uses pandas string dtype
    df['city'] = df['city'].astype('string')
    # Strip leading/trailing spaces and title-case
    df['city'] = df['city'].str.strip().str.title()
    # Drop duplicates based only on 'city', keep first
    df = df.drop_duplicates(subset=['city'], keep='first')
    # Reset index
    df = df.reset_index(drop=True)
    return df

if __name__ == "__main__":
    # Example usage with test csv
    test_path = "cities.csv"  # Replace with your test CSV file path
    cleaned_df = clean_city_data(test_path)
    print(cleaned_df)
