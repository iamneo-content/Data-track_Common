# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["clean_city_data"]

HARD_CODE_LITERALS = {
    "mini.csv", "mix.csv", "dupes.csv", "blank.csv", "region.csv", "big.csv",
    "Delhi", "Mumbai", "Kolkata", "Chennai", "Bangalore", "Hyderabad", "Ahmedabad",
    "Pune", "Surat", "Jaipur", "Lucknow", "Nagpur", "Indore", "Bhopal",
    "Chandigarh", "Coimbatore",
    "Delhi", "Maharashtra", "West Bengal", "Tamil Nadu", "Karnataka", "Telangana",
    "Gujarat", "Rajasthan", "Uttar Pradesh", "Madhya Pradesh", "Chandigarh",
    "North", "South", "West", "East", "Central",
    # populations
    19800000, 19820000, 20400000, 20350000, 14800000, 14750000, 10700000, 10650000,
    12500000, 9700000, 8400000, 7200000, 6500000, 4300000, 3500000, 3400000,
    3100000, 2800000, 1150000, 2200000
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")
    func_nodes = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` missing in main.py."
        func_nodes.append(node)
    found = set()
    for fn_node in func_nodes:
        for node in ast.walk(fn_node):
            if isinstance(node, ast.Constant):
                found.add(node.value)
    overlap = {v for v in found if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")
    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")
    total_match_cases = 0
    for fn_node in func_nodes:
        for inner in ast.walk(fn_node):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p

# ------------------ 10 TESTS ------------------

def test_trims_and_title_cases_city(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "cities.csv", [
        {"city": " delhi ", "population": 100, "state": "Delhi", "region": "North"},
        {"city": "mumbai", "population": 200, "state": "Maharashtra", "region": "West"}
    ])
    got = main.clean_city_data("cities.csv")
    exp = ["Delhi", "Mumbai"]
    actual = got["city"].tolist()
    assert actual == exp, f"City normalization failed. expected={exp}, actual={actual}"

def test_drops_duplicates_by_city(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "dupes.csv", [
        {"city": " Delhi ", "population": 19800000, "state": "Delhi", "region": "North"},
        {"city": "Delhi", "population": 19820000, "state": "Delhi", "region": "North"},
    ])
    got = main.clean_city_data("dupes.csv")
    exp_rows = 1
    actual_rows = len(got)
    assert actual_rows == exp_rows, f"Duplicate rows not dropped. expected={exp_rows}, actual={actual_rows}"

def test_title_casing_mixed(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "mix.csv", [
        {"city": "MuMbAi ", "population": 10, "state": "Maharashtra", "region": "West"},
        {"city": "  koLkAtA", "population": 15, "state": "West Bengal", "region": "East"}
    ])
    got = main.clean_city_data("mix.csv")
    exp = ["Mumbai", "Kolkata"]
    actual = got["city"].tolist()
    assert actual == exp, f"Mixed-case normalization failed. expected={exp}, actual={actual}"

def test_preserves_other_columns(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "mini.csv", [
        {"city": "Delhi", "population": 10, "state": "Delhi", "region": "North"}
    ])
    got = main.clean_city_data("mini.csv")
    exp_cols = {"city", "population", "state", "region"}
    actual_cols = set(got.columns)
    assert actual_cols == exp_cols, f"Columns changed. expected={sorted(exp_cols)}, actual={sorted(actual_cols)}"

def test_city_column_type_is_string(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "mini.csv", [
        {"city": "Hyderabad", "population": 9700000, "state": "Telangana", "region": "South"}
    ])
    got = main.clean_city_data("mini.csv")
    dtype = str(got["city"].dtype)
    assert "string" in dtype, f"'city' dtype incorrect. expected=string, actual={dtype}"

def test_output_index_reset(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "dupes.csv", [
        {"city": " Pune ", "population": 7200000, "state": "Maharashtra", "region": "West"},
        {"city": "pune", "population": 7200001, "state": "Maharashtra", "region": "West"}
    ])
    got = main.clean_city_data("dupes.csv")
    exp_index = list(range(len(got)))
    actual_index = got.index.tolist()
    assert actual_index == exp_index, f"Index not reset. expected={exp_index}, actual={actual_index}"

def test_empty_file_returns_empty(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    p = _write_csv(tmp_path, "blank.csv", [])
    with pytest.raises(ValueError):
        _ = main.clean_city_data("blank.csv")

def test_no_city_column_raises_keyerror(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "missing.csv", [
        {"population": 10, "state": "Delhi", "region": "North"}
    ])
    with pytest.raises(KeyError):
        _ = main.clean_city_data("missing.csv")

def test_large_dataset_no_duplicates(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = [{"city": f"City{i}", "population": i * 1000, "state": "X", "region": "Y"} for i in range(1, 1001)]
    _write_csv(tmp_path, "big.csv", rows)
    got = main.clean_city_data("big.csv")
    exp_rows = 1000
    actual_rows = len(got)
    assert actual_rows == exp_rows, f"Large dataset row count changed. expected={exp_rows}, actual={actual_rows}"

def test_return_type_dataframe(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "region.csv", [
        {"city": " Surat ", "population": 6500000, "state": "Gujarat", "region": "West"}
    ])
    got = main.clean_city_data("region.csv")
    assert isinstance(got, pd.DataFrame), f"Return type incorrect. expected=pandas.DataFrame, actual={type(got).__name__}"
