# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["find_hottest_city"]

HARD_CODE_LITERALS = {
    "Delhi", "Mumbai", "Kolkata", "Chennai", "Bengaluru", "Hyderabad", "Pune", "Jaipur", "Lucknow", "Bhopal",
    39.2, 35.5, 36.8, 40.0, 41.5, 37.0, 42.1, 29.9, 33.3, 30.2, 25.0, 45.0,
}

ELIF_MAX = 6
MATCH_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")

def _get_fn(tree: ast.AST, name: str):
    for n in ast.walk(tree):
        if isinstance(n, ast.FunctionDef) and n.name == name:
            return n
    return None

def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")
    func_bodies = []
    for fn in FUNCTIONS:
        node = _get_fn(tree, fn)
        assert node is not None, f"Required function `{fn}` missing in main.py."
        func_bodies.append(node)
    found = set()
    for fn_node in func_bodies:
        for node in ast.walk(fn_node):
            if isinstance(node, ast.Constant):
                found.add(node.value)
    overlap = {v for v in found if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")
    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")
    total_match_cases = 0
    for fn_node in func_bodies:
        for inner in ast.walk(fn_node):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > MATCH_MAX:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit {MATCH_MAX})")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def test_basic_three_cities():
    data = {"City": ["Delhi", "Mumbai", "Kolkata"], "Temperature": [39.2, 35.5, 36.8]}
    got = main.find_hottest_city(data)
    exp = "Delhi"
    assert got == exp, f"Hottest city incorrect. expected={exp}, actual={got}"

def test_hottest_city_single_entry():
    data = {"City": ["Chennai"], "Temperature": [40.0]}
    got = main.find_hottest_city(data)
    exp = "Chennai"
    assert got == exp, f"Single city result mismatch. expected={exp}, actual={got}"

def test_multiple_equal_temperatures_returns_first():
    data = {"City": ["Bengaluru", "Hyderabad", "Pune"], "Temperature": [37.0, 37.0, 37.0]}
    got = main.find_hottest_city(data)
    exp = "Bengaluru"
    assert got == exp, f"Equal temperature tie-breaking failed. expected={exp}, actual={got}"

def test_extreme_temperatures():
    data = {"City": ["Jaipur", "Lucknow", "Bhopal"], "Temperature": [29.9, 33.3, 45.0]}
    got = main.find_hottest_city(data)
    exp = "Bhopal"
    assert got == exp, f"Extreme temperature handling failed. expected={exp}, actual={got}"

def test_negative_temperatures():
    data = {"City": ["Shimla", "Manali", "Srinagar"], "Temperature": [-2.0, -5.0, -1.0]}
    got = main.find_hottest_city(data)
    exp = "Srinagar"
    assert got == exp, f"Negative temperature logic incorrect. expected={exp}, actual={got}"

def test_floats_with_two_decimals():
    data = {"City": ["A", "B", "C"], "Temperature": [25.12, 25.15, 25.14]}
    got = main.find_hottest_city(data)
    exp = "B"
    assert got == exp, f"Float comparison incorrect. expected={exp}, actual={got}"

def test_returns_string_type():
    data = {"City": ["A", "B"], "Temperature": [20.0, 30.0]}
    got = main.find_hottest_city(data)
    assert isinstance(got, str), f"Return type must be string. expected=str, actual={type(got).__name__}"

def test_large_dataframe_input():
    cities = [f"City{i}" for i in range(1000)]
    temps = list(range(1000))
    data = {"City": cities, "Temperature": temps}
    got = main.find_hottest_city(data)
    exp = "City999"
    assert got == exp, f"Large dataset handling incorrect. expected={exp}, actual={got}"

def test_dataframe_as_input_directly():
    df = pd.DataFrame({"City": ["A", "B", "C"], "Temperature": [20, 25, 15]})
    got = main.find_hottest_city(df)
    exp = "B"
    assert got == exp, f"DataFrame direct input failed. expected={exp}, actual={got}"

def test_missing_temperature_column_raises_keyerror():
    data = {"City": ["A", "B"]}
    with pytest.raises(KeyError):
        main.find_hottest_city(data)
