# import pandas as pd

# def find_hottest_city(data):
#     df = pd.DataFrame(data)
#     hottest_city = df.loc[df["Temperature"].idxmax(), "City"]
#     return hottest_city

# if __name__ == "__main__":
#     data = {
#         "City": ["Delhi", "Mumbai", "Kolkata"],
#         "Temperature": [39.2, 35.5, 36.8]
#     }
#     result = find_hottest_city(data)
#     print(result)


import pandas as pd

def find_hottest_city(data) -> str:
    # If data is a pandas DataFrame, use it; else, construct a DataFrame
    df = data if isinstance(data, pd.DataFrame) else pd.DataFrame(data)
    # Find index of maximum temperature (first occurrence if ties)
    hottest_idx = df["Temperature"].idxmax()
    # Return the corresponding city name as a string
    return str(df.loc[hottest_idx, "City"])

if __name__ == "__main__":
    # Example 1
    data1 = {"City": ["Delhi", "Mumbai", "Kolkata"], "Temperature": [39.2, 35.5, 36.8]}
    print(find_hottest_city(data1))  # Output: "Delhi"

    # Example 2
    data2 = {"City": ["Chennai"], "Temperature": [40.0]}
    print(find_hottest_city(data2))  # Output: "Chennai"

    # Example 3
    data3 = {"City": ["Bengaluru", "Hyderabad", "Pune"], "Temperature": [37.0, 37.0, 37.0]}
    print(find_hottest_city(data3))  # Output: "Bengaluru"

    # Example 4
    data4 = pd.DataFrame({"City": ["A", "B", "C"], "Temperature": [20, 25, 15]})
    print(find_hottest_city(data4))  # Output: "B"
