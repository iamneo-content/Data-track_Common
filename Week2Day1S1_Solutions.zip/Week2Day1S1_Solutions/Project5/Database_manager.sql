-- Active: 1762239131856@@127.0.0.1@3306@department_performance_db
-- =====================================================================
-- Database : department_performance_db
-- =====================================================================
DROP DATABASE IF EXISTS department_performance_db;
CREATE DATABASE department_performance_db;
USE department_performance_db;

-- ================================================================
-- Table: departments
-- ================================================================
CREATE TABLE departments (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(60) NOT NULL,
    budget DECIMAL(12,2) NOT NULL,
    head_name VARCHAR(80)
);

-- ================================================================
-- Table: students
-- ================================================================
CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    student_name VARCHAR(80) NOT NULL,
    dept_id INT NOT NULL,
    marks DECIMAL(5,2) NOT NULL,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

-- ================================================================
-- Insert department data
-- ================================================================
INSERT INTO departments (dept_name, budget, head_name) VALUES
('Computer Science', 950000.00, 'Dr. Anita Menon'),
('Mechanical Engineering', 880000.00, 'Dr. Ravi Patel'),
('Electrical Engineering', 910000.00, 'Dr. Nisha Iyer'),
('Civil Engineering', 750000.00, 'Dr. Suresh Naik'),
('Electronics & Communication', 920000.00, 'Dr. Arjun Varma'),
('Information Technology', 870000.00, 'Dr. Deepa Thomas'),
('Biotechnology', 700000.00, 'Dr. Kiran Rao'),
('Chemical Engineering', 820000.00, 'Dr. Meena Shah'),
('Business Analytics', 970000.00, 'Dr. Rohit Das'),
('Humanities', 650000.00, 'Dr. Priya Nair');

-- ================================================================
-- Insert student marks
-- ================================================================
INSERT INTO students (student_name, dept_id, marks) VALUES
('Ravi Kumar',1,86.5),('Neha Patel',1,78.0),('Arjun Reddy',1,91.2),('Kavya Das',1,88.6),
('Tina Mathew',2,79.4),('Rahul Das',2,82.3),('Vivek Joshi',2,76.8),('Meera Nair',2,84.5),
('Anita Sharma',3,88.1),('Kiran Dev',3,83.7),('Varun Pillai',3,90.0),('Sonia Dutta',3,85.9),
('Deepak Pillai',4,71.0),('Rohan Das',4,74.5),('Pooja Patel',4,69.8),('Manish Mehta',4,72.4),
('Aarti Nair',5,87.6),('Rita Varma',5,89.0),('Bala Krishnan',5,90.4),('Vikram Patel',5,86.3),
('Sneha Thomas',6,84.7),('Ajay Mehta',6,81.5),('Rahul Rao',6,78.6),('Divya Iyer',6,82.9),
('Suresh Bhat',7,75.4),('Kumar Raj',7,79.2),('Lalitha Devi',7,77.8),('Renu Pillai',7,74.9),
('Ravi Shankar',8,80.5),('Nisha Rao',8,83.1),('Amit Ghosh',8,81.2),('Neha Verma',8,85.4),
('Arun Menon',9,92.3),('Priya Menon',9,88.9),('Kavita Iyer',9,91.4),('Sanjay Joshi',9,90.1),
('Deepa Sharma',10,68.2),('Anu Pillai',10,71.9),('Kiran Pillai',10,73.4),('Vivek Patel',10,69.7);
