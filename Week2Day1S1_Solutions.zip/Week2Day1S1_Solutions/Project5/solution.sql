-- =====================================================================
-- File   : solution.sql
-- Purpose: Multi-CTE join & subquery comparison for Department Report
-- =====================================================================
USE department_performance_db;

-- ================================================================
-- Two-CTE Approach
-- ================================================================
WITH dept_avg_cte AS (
    SELECT
        st.dept_id,
        ROUND(AVG(st.marks),2) AS avg_marks
    FROM students AS st
    GROUP BY st.dept_id
),
budget_rank_cte AS (
    SELECT
        dp.dept_id,
        dp.dept_name,
        dp.budget,
        ROW_NUMBER() OVER (ORDER BY dp.budget DESC) AS budget_rank
    FROM departments AS dp
)
SELECT
    br.dept_name,
    br.budget,
    br.budget_rank,
    da.avg_marks
FROM budget_rank_cte AS br
JOIN dept_avg_cte AS da
    ON br.dept_id = da.dept_id
ORDER BY br.budget_rank;

-- ================================================================
-- Non-CTE (Flat Subquery) Approach
-- ================================================================
SELECT
    dp.dept_name,
    dp.budget,
    (
        SELECT ROUND(AVG(st.marks),2)
        FROM students AS st
        WHERE st.dept_id = dp.dept_id
    ) AS avg_marks,
    ROW_NUMBER() OVER (ORDER BY dp.budget DESC) AS budget_rank
FROM departments AS dp
ORDER BY budget_rank;
