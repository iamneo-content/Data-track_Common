-- Active: 1762231344815@@127.0.0.1@3306@product_category_db
-- =====================================================================
-- Database : product_category_db
-- =====================================================================
DROP DATABASE IF EXISTS product_category_db;
CREATE DATABASE product_category_db;
USE product_category_db;

-- ================================================================
-- Table: categories
-- ================================================================
CREATE TABLE categories (
    cat_id INT PRIMARY KEY AUTO_INCREMENT,
    cat_name VARCHAR(80) NOT NULL,
    parent_cat INT NULL,
    description VARCHAR(150),
    FOREIGN KEY (parent_cat) REFERENCES categories(cat_id)
);

-- ================================================================
-- Table: suppliers
-- ================================================================
CREATE TABLE suppliers (
    supplier_id INT PRIMARY KEY AUTO_INCREMENT,
    cat_id INT NOT NULL,
    supplier_name VARCHAR(80) NOT NULL,
    supplier_city VARCHAR(60),
    contact_email VARCHAR(80),
    FOREIGN KEY (cat_id) REFERENCES categories(cat_id)
);

-- ================================================================
-- Insert category hierarchy
-- ================================================================

INSERT INTO categories (cat_name, parent_cat, description) VALUES
('Electronics', NULL, 'Electronic devices and accessories'),
('Home & Furniture', NULL, 'Household and furnishing products'),
('Apparel', NULL, 'Clothing and accessories for men and women'),
('Sports & Outdoors', NULL, 'Sports gear, fitness and travel'),
('Groceries', NULL, 'Daily essentials and food products'),
('Mobiles & Tablets', 1, 'Smartphones and tablets'),
('Computers & Laptops', 1, 'Desktops, laptops and peripherals'),
('Audio & Video', 1, 'Speakers, headphones and TVs'),
('Android Phones', 6, 'Android smartphones'),
('iPhones', 6, 'Apple iPhones'),
('Laptop Accessories', 7, 'Bags, cooling pads, adapters'),
('Headphones', 8, 'Wired and wireless headphones'),
('Televisions', 8, 'Smart and LED TVs'),
('Living Room Furniture', 2, 'Sofas, coffee tables'),
('Bedroom Furniture', 2, 'Beds, wardrobes'),
('Kitchen Appliances', 2, 'Mixers, ovens, refrigerators'),
('Men Clothing', 3, 'Shirts, trousers, jackets'),
('Women Clothing', 3, 'Dresses, tops, sarees'),
('Footwear', 3, 'Shoes and sandals'),
('Fitness Equipment', 4, 'Treadmills, dumbbells'),
('Outdoor Gear', 4, 'Camping and hiking essentials'),
('Fresh Produce', 5, 'Vegetables and fruits'),
('Packaged Foods', 5, 'Snacks, beverages, cereals'),
('Household Essentials', 5, 'Cleaning and personal care');

-- ================================================================
-- Insert Suppliers (one or more per category)
-- ================================================================
INSERT INTO suppliers (cat_id, supplier_name, supplier_city, contact_email) VALUES
(1, 'TechZone Pvt Ltd', 'Bangalore', 'sales@techzone.in'),
(2, 'HomeDeco Furnishings', 'Mumbai', 'info@homedeco.com'),
(3, 'StyleMart Apparel', 'Delhi', 'support@stylemart.com'),
(4, 'FitPro Sports', 'Pune', 'orders@fitpro.co.in'),
(5, 'DailyFresh Grocers', 'Chennai', 'contact@dailyfresh.in'),
(6, 'MobileHub India', 'Hyderabad', 'sales@mobilehub.in'),
(7, 'CompWorld Systems', 'Bangalore', 'info@compworld.in'),
(8, 'AudioVision Co.', 'Kolkata', 'support@audiovision.in'),
(9, 'Galaxy Traders', 'Delhi', 'galaxytraders@trade.in'),
(10, 'iStore Retail', 'Bangalore', 'hello@istore.in'),
(11, 'AccessoryKart', 'Pune', 'support@accessorykart.in'),
(12, 'SoundWave India', 'Chennai', 'care@soundwave.in'),
(13, 'TVHub Electronics', 'Ahmedabad', 'tvhub@electronics.in'),
(14, 'LivingLux Interiors', 'Mumbai', 'info@livinglux.in'),
(15, 'Bedroom Bliss', 'Delhi', 'help@bedroombliss.com'),
(16, 'KitchenKing Appliances', 'Bangalore', 'sales@kitchenking.in'),
(17, 'UrbanMenswear', 'Chennai', 'contact@urbanmenswear.com'),
(18, 'GraceFashion Women', 'Delhi', 'hello@gracefashion.in'),
(19, 'StepUp Footwear', 'Kolkata', 'support@stepup.in'),
(20, 'ProGym Equipment', 'Pune', 'info@progym.in'),
(21, 'OutdoorVista', 'Bangalore', 'sales@outdoorvista.in'),
(22, 'FreshHarvest', 'Chennai', 'info@freshharvest.in'),
(23, 'SnackWorld Foods', 'Hyderabad', 'orders@snackworld.in'),
(24, 'CleanLiving Supplies', 'Mumbai', 'support@cleanliving.in');
