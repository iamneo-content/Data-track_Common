-- =====================================================================
-- File   : solution.sql
-- Purpose: Recursive CTE for Product Category Tree with Supplier Lookup
-- =====================================================================
USE product_category_db;

-- ================================================================
-- Recursive CTE to list categories with full path and supplier
-- ================================================================
WITH RECURSIVE category_hierarchy AS (
    SELECT
        ct.cat_id,
        ct.cat_name,
        ct.parent_cat,
        ct.description,
        0 AS level_no,
        CAST(ct.cat_name AS CHAR(400)) AS category_path
    FROM categories AS ct
    WHERE ct.parent_cat IS NULL
    UNION ALL
    SELECT
        sub.cat_id,
        sub.cat_name,
        sub.parent_cat,
        sub.description,
        ch.level_no + 1 AS level_no,
        CONCAT(ch.category_path, ' -> ', sub.cat_name) AS category_path
    FROM categories AS sub
    INNER JOIN category_hierarchy AS ch
        ON sub.parent_cat = ch.cat_id
)
SELECT
    ch.cat_id,
    ch.cat_name,
    ch.level_no,
    ch.category_path,
    sp.supplier_name,
    sp.supplier_city,
    sp.contact_email
FROM category_hierarchy AS ch
LEFT JOIN suppliers AS sp
    ON ch.cat_id = sp.cat_id
ORDER BY ch.category_path;
