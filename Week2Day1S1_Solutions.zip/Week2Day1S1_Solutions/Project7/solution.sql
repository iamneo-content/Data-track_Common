-- =====================================================================
-- File   : solution.sql
-- Purpose: Two-CTE query + ANALYZE TABLE demonstration
-- =====================================================================

USE library_performance_db;

-- ================================================================
-- Step 1: CTE approach
--   CTE-1 → total borrow count per category
--   CTE-2 → recent borrows (last 30 days from April 15, 2025)
-- ================================================================
WITH borrow_count_cte AS (
    SELECT
        bk.category,
        COUNT(bl.log_id) AS total_borrows
    FROM books AS bk
    LEFT JOIN borrow_log AS bl
        ON bk.book_id = bl.book_id
    GROUP BY bk.category
),
recent_borrows_cte AS (
    SELECT
        bk.category,
        COUNT(bl.log_id) AS recent_borrows
    FROM books AS bk
    LEFT JOIN borrow_log AS bl
        ON bk.book_id = bl.book_id
    WHERE bl.borrow_date BETWEEN '2025-03-15' AND '2025-04-15'
    GROUP BY bk.category
)
SELECT
    bc.category,
    bc.total_borrows,
    IFNULL(rb.recent_borrows, 0) AS recent_borrows
FROM borrow_count_cte AS bc
LEFT JOIN recent_borrows_cte AS rb
    ON bc.category = rb.category
ORDER BY bc.total_borrows DESC;

-- ================================================================
-- Step 2: Run EXPLAIN ANALYZE before and after ANALYZE TABLE
-- ================================================================
EXPLAIN ANALYZE FORMAT=JSON
WITH borrow_count_cte AS (
    SELECT bk.category, COUNT(bl.log_id) AS total_borrows
    FROM books AS bk
    LEFT JOIN borrow_log AS bl ON bk.book_id = bl.book_id
    GROUP BY bk.category
)
SELECT * FROM borrow_count_cte
\G;

-- Update optimizer statistics to refresh index/cardinality info
ANALYZE TABLE books;
ANALYZE TABLE borrow_log;

-- Re-run EXPLAIN ANALYZE to observe plan difference
EXPLAIN ANALYZE
WITH borrow_count_cte AS (
    SELECT bk.category, COUNT(bl.log_id) AS total_borrows
    FROM books AS bk
    LEFT JOIN borrow_log AS bl ON bk.book_id = bl.book_id
    GROUP BY bk.category
)
SELECT * FROM borrow_count_cte;
