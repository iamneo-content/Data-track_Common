-- Active: 1762244937550@@127.0.0.1@3306@library_performance_db
-- =====================================================================
-- Database : library_performance_db
-- =====================================================================
DROP DATABASE IF EXISTS library_performance_db;
CREATE DATABASE library_performance_db;
USE library_performance_db;

-- ================================================================
-- Table: books
-- ================================================================
CREATE TABLE books (
    book_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    category VARCHAR(60) NOT NULL,
    author_name VARCHAR(80),
    publish_year INT
);

-- ================================================================
-- Table: borrow_log
-- ================================================================
CREATE TABLE borrow_log (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    book_id INT NOT NULL,
    borrow_date DATE NOT NULL,
    borrower_name VARCHAR(80),
    FOREIGN KEY (book_id) REFERENCES books(book_id)
);

-- ================================================================
-- Insert book records
-- ================================================================
INSERT INTO books (title, category, author_name, publish_year) VALUES
('Introduction to Databases', 'Computer Science', 'Anita Sharma', 2018),
('Advanced SQL Techniques', 'Computer Science', 'Vikram Patel', 2020),
('Python for Data Analysis', 'Data Science', 'Ravi Kumar', 2021),
('Machine Learning Basics', 'Data Science', 'Kavya Das', 2022),
('Deep Learning Explained', 'Data Science', 'Arjun Reddy', 2023),
('Civil Engineering Design', 'Engineering', 'Suresh Menon', 2017),
('Fluid Mechanics', 'Engineering', 'Neha Verma', 2016),
('Thermodynamics', 'Engineering', 'Rohan Singh', 2018),
('Digital Marketing 101', 'Business', 'Priya Menon', 2020),
('Financial Analytics', 'Business', 'Meera Nair', 2021),
('Organizational Behavior', 'Business', 'Rahul Das', 2019),
('Modern Physics', 'Science', 'Aarti Nair', 2015),
('Astrophysics for Beginners', 'Science', 'Kiran Dev', 2016),
('Chemistry Simplified', 'Science', 'Deepa Thomas', 2018),
('Fundamentals of Biology', 'Science', 'Anu Pillai', 2020);

-- ================================================================
-- Insert borrow logs
-- ================================================================
INSERT INTO borrow_log (book_id, borrow_date, borrower_name) VALUES
(1, '2025-01-02', 'Ravi Joshi'),
(1, '2025-02-14', 'Neha Patel'),
(2, '2025-02-28', 'Vikram Jain'),
(2, '2025-03-10', 'Sonia Dutta'),
(3, '2025-03-15', 'Ajay Mehta'),
(3, '2025-04-01', 'Rahul Rao'),
(4, '2025-03-25', 'Nisha Reddy'),
(4, '2025-04-05', 'Anita Singh'),
(5, '2025-04-10', 'Arjun Kapoor'),
(6, '2025-01-22', 'Meena Gupta'),
(7, '2025-02-11', 'Ravi Kumar'),
(8, '2025-03-02', 'Preeti Nair'),
(9, '2025-03-09', 'Kavita Iyer'),
(9, '2025-03-20', 'Rohit Das'),
(10, '2025-03-25', 'Lalitha Devi'),
(11, '2025-04-02', 'Sneha Thomas'),
(12, '2025-01-15', 'Vikram Patel'),
(13, '2025-02-16', 'Suresh Bhat'),
(13, '2025-03-18', 'Neha Verma'),
(14, '2025-03-22', 'Kiran Pillai'),
(14, '2025-03-30', 'Anita Sharma'),
(15, '2025-04-01', 'Rahul Das'),
(15, '2025-04-06', 'Divya Iyer'),
(10, '2025-04-10', 'Vivek Joshi'),
(11, '2025-04-15', 'Renu Pillai');
