-- Active: 1762239131856@@127.0.0.1@3306@regional_sales_db
-- =====================================================================
-- Database : regional_sales_db
-- =====================================================================
DROP DATABASE IF EXISTS regional_sales_db;
CREATE DATABASE regional_sales_db;
USE regional_sales_db;

-- ================================================================
-- Table: orders
-- ================================================================
CREATE TABLE orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    region VARCHAR(40) NOT NULL,
    customer_name VARCHAR(80),
    order_date DATE,
    amount DECIMAL(10,2) NOT NULL
);

-- ================================================================
-- Table: returns
-- ================================================================
CREATE TABLE returns (
    return_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    refund_amt DECIMAL(10,2) NOT NULL,
    reason VARCHAR(100),
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- ================================================================
-- Insert order data
-- ================================================================
INSERT INTO orders (region, customer_name, order_date, amount) VALUES
('North',  'Ravi Mehta',     '2025-01-05', 1250.00),
('North',  'Anita Singh',    '2025-01-10', 980.00),
('South',  'Kumar Raj',      '2025-01-12', 1420.00),
('East',   'Neha Patel',     '2025-01-18', 1750.00),
('West',   'Arjun Rao',      '2025-01-20', 1600.00),
('North',  'Suresh Bhat',    '2025-02-01', 2100.00),
('South',  'Meena Iyer',     '2025-02-03', 1550.00),
('East',   'Nikhil Jain',    '2025-02-06', 1780.00),
('West',   'Divya Kapoor',   '2025-02-10', 1850.00),
('North',  'Ajay Sharma',    '2025-02-12', 1190.00),
('East',   'Nisha Reddy',    '2025-03-01', 1650.00),
('South',  'Rohan Das',      '2025-03-02', 1320.00),
('West',   'Sahil Gupta',    '2025-03-05', 1725.00),
('North',  'Reena Thomas',   '2025-03-09', 1380.00),
('South',  'Tina Paul',      '2025-03-15', 1900.00),
('East',   'Amit Ghosh',     '2025-03-18', 1525.00),
('West',   'Kavya Menon',    '2025-03-22', 2050.00),
('South',  'Rahul Rao',      '2025-03-25', 2150.00),
('North',  'Preeti Nair',    '2025-03-30', 1580.00),
('East',   'Kiran Pillai',   '2025-04-01', 1980.00),
('West',   'Maya Deshmukh',  '2025-04-03', 2200.00),
('South',  'Lalitha Devi',   '2025-04-06', 1870.00),
('East',   'Sanjay Joshi',   '2025-04-08', 1690.00),
('North',  'Vivek Patel',    '2025-04-10', 1450.00),
('West',   'Rita Varma',     '2025-04-12', 2100.00);

-- ================================================================
-- Insert returns
-- ================================================================
INSERT INTO returns (order_id, refund_amt, reason) VALUES
(2, 100.00, 'Damaged item'),
(7, 120.00, 'Late delivery'),
(10, 80.00, 'Customer dissatisfaction'),
(14, 150.00, 'Wrong size'),
(15, 200.00, 'Color mismatch'),
(17, 100.00, 'Defective piece'),
(19, 90.00,  'Packaging issue'),
(23, 75.00,  'Delayed shipment');
