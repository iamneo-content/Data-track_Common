-- =====================================================================
-- File   : solution.sql
-- Purpose: Two-CTE vs Subquery comparison for regional net sales
-- =====================================================================
USE regional_sales_db;

-- ================================================================
-- CTE Approach
-- ================================================================
EXPLAIN ANALYZE
WITH regional_sales_cte AS (
    SELECT
        ord.region,
        SUM(ord.amount) AS total_sales
    FROM orders AS ord
    GROUP BY ord.region
),
refund_summary_cte AS (
    SELECT
        ord.region,
        SUM(ret.refund_amt) AS total_refunds
    FROM returns AS ret
    INNER JOIN orders AS ord
        ON ret.order_id = ord.order_id
    GROUP BY ord.region
),
net_sales_cte AS (
    SELECT
        rs.region,
        rs.total_sales,
        IFNULL(rf.total_refunds, 0) AS total_refunds,
        (rs.total_sales - IFNULL(rf.total_refunds, 0)) AS net_revenue
    FROM regional_sales_cte AS rs
    LEFT JOIN refund_summary_cte AS rf
        ON rs.region = rf.region
)
SELECT
    ns.region,
    ns.total_sales,
    ns.total_refunds,
    ns.net_revenue
FROM net_sales_cte AS ns
ORDER BY ns.net_revenue DESC;

-- ================================================================
-- Non-CTE (subquery) approach for comparison
-- ================================================================
EXPLAIN ANALYZE
SELECT
    ord.region,
    SUM(ord.amount) AS total_sales,
    IFNULL((
        SELECT SUM(ret.refund_amt)
        FROM returns AS ret
        INNER JOIN orders AS o2
            ON ret.order_id = o2.order_id
        WHERE o2.region = ord.region
    ), 0) AS total_refunds,
    (SUM(ord.amount) -
     IFNULL((
        SELECT SUM(ret.refund_amt)
        FROM returns AS ret
        INNER JOIN orders AS o3
            ON ret.order_id = o3.order_id
        WHERE o3.region = ord.region
     ), 0)) AS net_revenue
FROM orders AS ord
GROUP BY ord.region
ORDER BY net_revenue DESC;
