-- =====================================================================
-- File   : solution.sql
-- Purpose: Compare 2-CTE vs Temporary Table approaches
-- =====================================================================
USE vehicle_service_db;

-- ================================================================
-- CTE Approach
-- ================================================================
WITH total_cost_cte AS (
    SELECT
        sv.vehicle_id,
        SUM(sv.cost) AS total_cost
    FROM service AS sv
    GROUP BY sv.vehicle_id
),
high_cost_cte AS (
    SELECT
        tc.vehicle_id,
        tc.total_cost
    FROM total_cost_cte AS tc
    WHERE tc.total_cost > 10000
)
SELECT
    vh.vehicle_id,
    vh.registration_no,
    vh.model,
    vh.owner_name,
    tc.total_cost
FROM vehicles AS vh
INNER JOIN high_cost_cte AS tc
    ON vh.vehicle_id = tc.vehicle_id
ORDER BY tc.total_cost DESC;

-- ================================================================
-- Temporary Table (Materialized) Approach
-- ================================================================
DROP TEMPORARY TABLE IF EXISTS temp_total_cost;
CREATE TEMPORARY TABLE temp_total_cost AS
SELECT
    sv.vehicle_id,
    SUM(sv.cost) AS total_cost
FROM service AS sv
GROUP BY sv.vehicle_id;

SELECT
    vh.vehicle_id,
    vh.registration_no,
    vh.model,
    vh.owner_name,
    t.total_cost
FROM vehicles AS vh
INNER JOIN temp_total_cost AS t
    ON vh.vehicle_id = t.vehicle_id
WHERE t.total_cost > 10000
ORDER BY t.total_cost DESC;
