-- Active: 1762239131856@@127.0.0.1@3306@vehicle_service_db
-- =====================================================================
-- Database : vehicle_service_db
-- =====================================================================
DROP DATABASE IF EXISTS vehicle_service_db;
CREATE DATABASE vehicle_service_db;
USE vehicle_service_db;

-- ================================================================
-- Table: vehicles
-- ================================================================
CREATE TABLE vehicles (
    vehicle_id INT PRIMARY KEY AUTO_INCREMENT,
    registration_no VARCHAR(20) NOT NULL,
    model VARCHAR(60) NOT NULL,
    owner_name VARCHAR(60),
    purchase_year INT
);

-- ================================================================
-- Table: service
-- ================================================================
CREATE TABLE service (
    service_id INT PRIMARY KEY AUTO_INCREMENT,
    vehicle_id INT NOT NULL,
    service_date DATE,
    description VARCHAR(100),
    cost DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id)
);

-- ================================================================
-- Insert sample vehicles
-- ================================================================
INSERT INTO vehicles (registration_no, model, owner_name, purchase_year) VALUES
('MH01AB1001','Toyota Corolla','Ravi Kumar',2018),
('DL05CD2211','Honda City','Anita Sharma',2019),
('KA03EF3302','Hyundai Creta','Vikram Patel',2020),
('TN07GH4521','Maruti Baleno','Priya Menon',2021),
('GJ02JK5610','Tata Nexon','Rohan Singh',2019),
('WB04LM6723','Ford Ecosport','Neha Verma',2018),
('PB08NP7832','Kia Seltos','Amit Nair',2021),
('UP09QR8941','Skoda Rapid','Meena Gupta',2020),
('RJ10ST9054','Volkswagen Polo','Arjun Reddy',2017),
('CH11UV0163','Honda Amaze','Kavya Das',2019);

-- ================================================================
-- Insert service records
-- ================================================================
INSERT INTO service (vehicle_id, service_date, description, cost) VALUES
(1,'2025-01-05','Annual maintenance',8500.00),
(1,'2025-03-10','Brake replacement',4200.00),
(2,'2025-02-12','Engine tuning',9500.00),
(2,'2025-04-15','AC repair',3700.00),
(3,'2025-01-20','Major service',12500.00),
(3,'2025-03-22','Tyre change',7200.00),
(4,'2025-02-05','General check-up',2600.00),
(5,'2025-03-09','Suspension fix',8900.00),
(6,'2025-01-30','Oil change',2100.00),
(6,'2025-03-28','Clutch plate replacement',5600.00),
(7,'2025-02-16','Major overhaul',14800.00),
(8,'2025-04-02','Battery replacement',4300.00),
(9,'2025-01-18','Full service',9800.00),
(10,'2025-03-05','General maintenance',3400.00),
(10,'2025-04-10','Paint restoration',6600.00);
