-- =====================================================================
-- Database: website_navigation_db
-- =====================================================================
DROP DATABASE IF EXISTS website_navigation_db;
CREATE DATABASE website_navigation_db;
USE website_navigation_db;
-- ================================================================
-- Table: pages
-- ================================================================
CREATE TABLE pages (
    page_id INT PRIMARY KEY AUTO_INCREMENT,
    page_name VARCHAR(80) NOT NULL,
    parent_page_id INT NULL,
    url_slug VARCHAR(120) NOT NULL,
    last_updated DATE,
    FOREIGN KEY (parent_page_id) REFERENCES pages(page_id)
);

-- ================================================================
-- Table: owners
-- ================================================================
CREATE TABLE owners (
    owner_id INT PRIMARY KEY AUTO_INCREMENT,
    page_id INT NOT NULL,
    owner_name VARCHAR(60) NOT NULL,
    role_title VARCHAR(60),
    FOREIGN KEY (page_id) REFERENCES pages(page_id)
);

-- ================================================================
-- Insert Website Page Hierarchy
-- ================================================================
INSERT INTO pages (page_name, parent_page_id, url_slug, last_updated) VALUES
('Home', NULL, 'home', '2025-01-01'),
('About Us', 1, 'about', '2025-01-03'),
('Products', 1, 'products', '2025-01-04'),
('Services', 1, 'services', '2025-01-05'),
('Blog', 1, 'blog', '2025-01-06'),
('Contact', 1, 'contact', '2025-01-07'),
('Electronics', 3, 'products/electronics', '2025-01-08'),
('Furniture', 3, 'products/furniture', '2025-01-09'),
('Apparel', 3, 'products/apparel', '2025-01-10'),
('Laptops', 7, 'products/electronics/laptops', '2025-01-11'),
('Smartphones', 7, 'products/electronics/smartphones', '2025-01-12'),
('Accessories', 7, 'products/electronics/accessories', '2025-01-13'),
('Office Chairs', 8, 'products/furniture/office-chairs', '2025-01-14'),
('Tables', 8, 'products/furniture/tables', '2025-01-15'),
('Men Clothing', 9, 'products/apparel/men', '2025-01-16'),
('Women Clothing', 9, 'products/apparel/women', '2025-01-17'),
('Consulting', 4, 'services/consulting', '2025-01-18'),
('Installation', 4, 'services/installation', '2025-01-19'),
('Maintenance', 4, 'services/maintenance', '2025-01-20'),
('Tech Insights', 5, 'blog/tech-insights', '2025-01-21'),
('Design Trends', 5, 'blog/design-trends', '2025-01-22'),
('Case Studies', 5, 'blog/case-studies', '2025-01-23'),
('Customer Support', 6, 'contact/support', '2025-01-24'),
('Investor Relations', 6, 'contact/investors', '2025-01-25'),
('Career Opportunities', 6, 'contact/careers', '2025-01-26'),
('SEO Optimization', 5, 'blog/seo-optimization', '2025-01-27');

-- ================================================================
-- Insert Page Owners
-- ================================================================
INSERT INTO owners (page_id, owner_name, role_title) VALUES
(1, 'Ravi Kumar', 'Website Administrator'),
(2, 'Anita Sharma', 'Corporate Communications'),
(3, 'Vikram Patel', 'Product Director'),
(4, 'Priya Menon', 'Services Manager'),
(5, 'Amit Nair', 'Marketing Manager'),
(6, 'Neha Verma', 'Customer Care Head'),
(7, 'Rohan Singh', 'Electronics Lead'),
(8, 'Meena Gupta', 'Furniture Lead'),
(9, 'Arjun Reddy', 'Apparel Lead'),
(10, 'Nisha Rao', 'Laptop Category Manager'),
(11, 'Karan Verma', 'Smartphone Category Manager'),
(12, 'Sneha Thomas', 'Accessory Specialist'),
(13, 'Deepak Pillai', 'Office Furniture Coordinator'),
(14, 'Kavya Das', 'Table Design Specialist'),
(15, 'Tina Mathew', 'Menwear Curator'),
(16, 'Rahul Das', 'Womenwear Curator'),
(17, 'Divya Iyer', 'Consulting Supervisor'),
(18, 'Manish Mehta', 'Installation Engineer'),
(19, 'Rohit Sharma', 'Maintenance Engineer'),
(20, 'Aarti Nair', 'Technology Blogger'),
(21, 'Vivek Joshi', 'Design Blogger'),
(22, 'Ritu Kaur', 'Case Study Editor'),
(23, 'Bala Krishnan', 'Support Supervisor'),
(24, 'Varun Pillai', 'Investor Relations Officer'),
(25, 'Sonia Dutta', 'HR & Careers Specialist'),
(26, 'Pooja Patel', 'SEO Content Coordinator');
