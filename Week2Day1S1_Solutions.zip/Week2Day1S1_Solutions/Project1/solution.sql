-- Active: 1762231344815@@127.0.0.1@3306@website_navigation_db
-- =====================================================================
-- File   : solution.sql
-- Purpose: Recursive CTE for Website Navigation Tree
-- =====================================================================
USE website_navigation_db;

-- ================================================================
-- Recursive CTE: Build full navigation path with page owners
-- ================================================================
WITH RECURSIVE navigation_cte AS (
    -- Base level: root page(s)
    SELECT
        pg.page_id,
        pg.page_name,
        pg.parent_page_id,
        pg.url_slug,
        0 AS level_no,
        CAST(pg.page_name AS CHAR(500)) AS navigation_path
    FROM pages AS pg
    WHERE pg.parent_page_id IS NULL
    UNION ALL
    -- Recursive step: append child pages to their parent path
    SELECT
        ch.page_id,
        ch.page_name,
        ch.parent_page_id,
        ch.url_slug,
        nav.level_no + 1 AS level_no,
        CONCAT(nav.navigation_path, ' → ', ch.page_name) AS navigation_path
    FROM pages AS ch
    INNER JOIN navigation_cte AS nav
        ON ch.parent_page_id = nav.page_id
)
SELECT
    nav.page_id,
    nav.page_name,
    nav.url_slug,
    nav.level_no,
    nav.navigation_path,
    ow.owner_name,
    ow.role_title
FROM navigation_cte AS nav
LEFT JOIN owners AS ow
    ON nav.page_id = ow.page_id
ORDER BY nav.navigation_path;
