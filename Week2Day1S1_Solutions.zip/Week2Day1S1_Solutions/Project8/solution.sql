-- =====================================================================
-- File   : solution.sql
-- Purpose: Query optimization using EXPLAIN ANALYZE and indexing
-- =====================================================================
USE flights_optimization_db;

-- ================================================================
-- Step 1: CTE-based Query (Before Index)
-- ================================================================
EXPLAIN ANALYZE
WITH delhi_flights_cte AS (
    SELECT
        fl.flight_id,
        fl.airline,
        fl.origin,
        fl.destination,
        fl.duration_minutes
    FROM flights AS fl
    WHERE fl.origin = 'Delhi'
),
avg_duration_cte AS (
    SELECT
        destination,
        ROUND(AVG(duration_minutes),2) AS avg_duration
    FROM delhi_flights_cte
    GROUP BY destination
)
SELECT
    ad.destination,
    ad.avg_duration
FROM avg_duration_cte AS ad
ORDER BY ad.avg_duration DESC;

-- ================================================================
-- Step 2: Add index on destination to improve performance
-- ================================================================
CREATE INDEX idx_destination ON flights(destination);

-- Refresh statistics for optimizer
ANALYZE TABLE flights;

-- ================================================================
-- Step 3: Run EXPLAIN ANALYZE again (After Index)
-- ================================================================
EXPLAIN ANALYZE
WITH delhi_flights_cte AS (
    SELECT
        fl.flight_id,
        fl.airline,
        fl.origin,
        fl.destination,
        fl.duration_minutes
    FROM flights AS fl
    WHERE fl.origin = 'Delhi'
),
avg_duration_cte AS (
    SELECT
        destination,
        ROUND(AVG(duration_minutes),2) AS avg_duration
    FROM delhi_flights_cte
    GROUP BY destination
)
SELECT
    ad.destination,
    ad.avg_duration
FROM avg_duration_cte AS ad
ORDER BY ad.avg_duration DESC;

-- ================================================================
-- Step 4: Clean up (optional)
-- ================================================================
DROP INDEX idx_destination ON flights;
