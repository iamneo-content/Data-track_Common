-- Active: 1762247202758@@127.0.0.1@3306@flights_optimization_db
-- =====================================================================
-- Database : flights_optimization_db
-- =====================================================================
DROP DATABASE IF EXISTS flights_optimization_db;
CREATE DATABASE flights_optimization_db;
USE flights_optimization_db;

-- ================================================================
-- Table: flights
-- ================================================================
CREATE TABLE flights (
    flight_id INT PRIMARY KEY AUTO_INCREMENT,
    airline VARCHAR(60) NOT NULL,
    origin VARCHAR(60) NOT NULL,
    destination VARCHAR(60) NOT NULL,
    duration_minutes INT NOT NULL,
    distance_km INT,
    flight_date DATE
);

-- ================================================================
-- Insert flight data
-- ================================================================
INSERT INTO flights (airline, origin, destination, duration_minutes, distance_km, flight_date) VALUES
('IndiGo', 'Delhi', 'Mumbai', 130, 1150, '2025-01-05'),
('Air India', 'Delhi', 'Bangalore', 160, 1740, '2025-01-06'),
('SpiceJet', 'Chennai', 'Delhi', 155, 1750, '2025-01-07'),
('Vistara', 'Kolkata', 'Delhi', 140, 1300, '2025-01-08'),
('GoAir', 'Mumbai', 'Kolkata', 150, 1650, '2025-01-09'),
('Air India', 'Delhi', 'Hyderabad', 145, 1260, '2025-01-10'),
('IndiGo', 'Delhi', 'Chennai', 175, 1750, '2025-01-11'),
('SpiceJet', 'Hyderabad', 'Delhi', 150, 1260, '2025-01-12'),
('AirAsia', 'Bangalore', 'Delhi', 155, 1740, '2025-01-13'),
('IndiGo', 'Mumbai', 'Delhi', 140, 1150, '2025-01-14'),
('Air India', 'Bangalore', 'Chennai', 80, 290, '2025-01-15'),
('SpiceJet', 'Delhi', 'Kolkata', 135, 1300, '2025-01-16'),
('GoAir', 'Hyderabad', 'Mumbai', 125, 710, '2025-01-17'),
('Vistara', 'Chennai', 'Hyderabad', 85, 630, '2025-01-18'),
('IndiGo', 'Kolkata', 'Bangalore', 150, 1560, '2025-01-19'),
('Air India', 'Delhi', 'Pune', 120, 1170, '2025-01-20'),
('SpiceJet', 'Delhi', 'Goa', 115, 1090, '2025-01-21'),
('GoAir', 'Delhi', 'Bangalore', 165, 1740, '2025-01-22'),
('AirAsia', 'Delhi', 'Chennai', 170, 1750, '2025-01-23'),
('Vistara', 'Delhi', 'Hyderabad', 145, 1260, '2025-01-24'),
('IndiGo', 'Pune', 'Delhi', 125, 1170, '2025-01-25'),
('SpiceJet', 'Delhi', 'Jaipur', 60, 280, '2025-01-26'),
('Air India', 'Delhi', 'Kolkata', 130, 1300, '2025-01-27'),
('GoAir', 'Delhi', 'Ahmedabad', 105, 775, '2025-01-28'),
('Vistara', 'Chennai', 'Delhi', 155, 1750, '2025-01-29');
