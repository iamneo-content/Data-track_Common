-- Active: 1762231344815@@127.0.0.1@3306@course_prerequisite_db
-- =====================================================================
-- Database : course_prerequisite_db
-- =====================================================================
DROP DATABASE IF EXISTS course_prerequisite_db;
CREATE DATABASE course_prerequisite_db;
USE course_prerequisite_db;
-- ================================================================
-- Table: courses
-- ================================================================
CREATE TABLE courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    course_name VARCHAR(100) NOT NULL,
    prereq_id INT NULL,
    course_level VARCHAR(30),
    duration_weeks INT,
    FOREIGN KEY (prereq_id) REFERENCES courses(course_id)
);

-- ================================================================
-- Table: faculty
-- ================================================================
CREATE TABLE faculty (
    faculty_id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    faculty_name VARCHAR(60) NOT NULL,
    experience_years INT,
    specialization VARCHAR(80),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- ================================================================
-- Insert course hierarchy
-- ================================================================
INSERT INTO courses (course_name, prereq_id, course_level, duration_weeks) VALUES
('Programming Fundamentals', NULL, 'Beginner', 6),
('Introduction to Databases', 1, 'Beginner', 5),
('Basic SQL', 2, 'Beginner', 4),
('Intermediate SQL', 3, 'Intermediate', 5),
('Advanced SQL', 4, 'Advanced', 6),
('Stored Procedures & Triggers', 5, 'Advanced', 5),
('Query Optimization', 5, 'Advanced', 5),
('Database Design Principles', 2, 'Intermediate', 5),
('Data Modeling Basics', 2, 'Intermediate', 5),
('Database Security Essentials', 5, 'Intermediate', 4),
('Intro to Data Warehousing', 5, 'Intermediate', 6),
('ETL Concepts', 11, 'Intermediate', 5),
('Data Warehousing Advanced', 12, 'Advanced', 6),
('SQL for Analytics', 5, 'Advanced', 5),
('SQL Performance Tuning', 7, 'Advanced', 5),
('NoSQL Fundamentals', NULL, 'Beginner', 4),
('Data Visualization Basics', 11, 'Beginner', 5),
('Business Intelligence Tools', 17, 'Intermediate', 6),
('Python for Data Analysis', NULL, 'Intermediate', 6),
('Data Engineering Overview', 19, 'Intermediate', 5),
('Data Pipelines with SQL', 11, 'Intermediate', 5),
('Cloud Databases', 10, 'Intermediate', 6),
('Database Administration', 5, 'Advanced', 6),
('SQL for Machine Learning', 14, 'Advanced', 6),
('Capstone Project', 23, 'Advanced', 8);

-- ================================================================
-- Faculty assignments (each course handled by one faculty)
-- ================================================================
INSERT INTO faculty (course_id, faculty_name, experience_years, specialization) VALUES
(1, 'Rajesh Kumar', 12, 'Programming'),
(2, 'Anita Sharma', 10, 'Database Fundamentals'),
(3, 'Neha Verma', 8, 'SQL Basics'),
(4, 'Ravi Nair', 9, 'Relational Databases'),
(5, 'Vikram Patel', 11, 'Advanced SQL'),
(6, 'Priya Menon', 9, 'Procedural SQL'),
(7, 'Meena Kapoor', 10, 'Performance Tuning'),
(8, 'Suresh Iyer', 8, 'Database Design'),
(9, 'Deepa Thomas', 7, 'Data Modeling'),
(10, 'Rohan Das', 6, 'Database Security'),
(11, 'Anu Pillai', 9, 'Data Warehousing'),
(12, 'Kiran Dev', 8, 'ETL Processes'),
(13, 'Sneha Reddy', 10, 'Data Warehousing Advanced'),
(14, 'Divya Sharma', 7, 'Analytics SQL'),
(15, 'Ajay Mehta', 9, 'Performance Optimization'),
(16, 'Aarti Nair', 8, 'NoSQL Systems'),
(17, 'Nisha Rao', 7, 'Visualization Tools'),
(18, 'Varun Pillai', 9, 'BI Platforms'),
(19, 'Ravi Joshi', 10, 'Python Analytics'),
(20, 'Sonia Dutta', 8, 'Data Engineering'),
(21, 'Bala Krishnan', 9, 'SQL Pipelines'),
(22, 'Tina Mathew', 7, 'Cloud Databases'),
(23, 'Rohit Singh', 10, 'Database Administration'),
(24, 'Kavya Das', 8, 'ML & SQL Integration'),
(25, 'Manish Mehta', 11, 'Capstone Projects');
