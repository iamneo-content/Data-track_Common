-- =====================================================================
-- File   : solution.sql
-- Purpose: Recursive CTE for Course Prerequisite Planner
-- =====================================================================
USE course_prerequisite_db;

-- ================================================================
-- Recursive CTE: Show prerequisite chain for "Advanced SQL"
-- ================================================================
WITH RECURSIVE prq_chain AS (
    -- Base case: start from target course
    SELECT
        crs.course_id,
        crs.course_name,
        crs.prereq_id,
        crs.course_level,
        crs.duration_weeks,
        0 AS level_no,
        CAST(crs.course_name AS CHAR(400)) AS prereq_path
    FROM courses AS crs
    WHERE crs.course_name = 'Advanced SQL'
    UNION ALL--
    -- Recursive step: move backward to its prerequisites
    SELECT
        pre.course_id,
        pre.course_name,
        pre.prereq_id,
        pre.course_level,
        pre.duration_weeks,
        pc.level_no + 1 AS level_no,
        CONCAT(pre.course_name, ' → ', pc.prereq_path) AS prereq_path
    FROM courses AS pre
    INNER JOIN prq_chain AS pc
        ON pc.prereq_id = pre.course_id
)
SELECT
    pc.course_id,
    pc.course_name,
    pc.course_level,
    pc.duration_weeks,
    pc.level_no,
    pc.prereq_path,
    fct.faculty_name,
    fct.experience_years,
    fct.specialization
FROM prq_chain AS pc
LEFT JOIN faculty AS fct
    ON pc.course_id = fct.course_id
ORDER BY pc.level_no DESC;
