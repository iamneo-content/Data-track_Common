-- =====================================================================
-- File   : solution.sql
-- Purpose: CTE ranking + index performance measurement
-- =====================================================================

USE bank_branch_db;

-- ================================================================
-- Step 1 – Run EXPLAIN ANALYZE without index
-- ================================================================
-- EXPLAIN ANALYZE
WITH branch_sum_cte AS (
    SELECT
        tr.branch_id,
        SUM(tr.amount) AS total_amount
    FROM transactions AS tr
    GROUP BY tr.branch_id
),
branch_rank_cte AS (
    SELECT
        bs.branch_id,
        bs.total_amount,
        ROW_NUMBER() OVER (ORDER BY bs.total_amount DESC) AS amount_rank
    FROM branch_sum_cte AS bs
)
SELECT
    br.branch_name,
    br.city,
    br.manager_name,
    bk.total_amount,
    bk.amount_rank
FROM branches AS br
INNER JOIN branch_rank_cte AS bk
    ON br.branch_id = bk.branch_id
ORDER BY bk.amount_rank;

-- ================================================================
-- Step 2 – Create index on branch_id to improve join/group performance
-- ================================================================
CREATE INDEX idx_branch_id ON transactions(branch_id);

-- Refresh statistics
ANALYZE TABLE transactions;

-- ================================================================
-- Step 3 – Run EXPLAIN ANALYZE again (after index)
-- ================================================================
EXPLAIN ANALYZE
WITH branch_sum_cte AS (
    SELECT
        tr.branch_id,
        SUM(tr.amount) AS total_amount
    FROM transactions AS tr
    GROUP BY tr.branch_id
),
branch_rank_cte AS (
    SELECT
        bs.branch_id,
        bs.total_amount,
        ROW_NUMBER() OVER (ORDER BY bs.total_amount DESC) AS amount_rank
    FROM branch_sum_cte AS bs
)
SELECT
    br.branch_name,
    br.city,
    br.manager_name,
    bk.total_amount,
    bk.amount_rank
FROM branches AS br
INNER JOIN branch_rank_cte AS bk
    ON br.branch_id = bk.branch_id
ORDER BY bk.amount_rank;

-- ================================================================
-- Step 4 – Optional cleanup
-- ================================================================
-- DROP INDEX idx_branch_id ON transactions;