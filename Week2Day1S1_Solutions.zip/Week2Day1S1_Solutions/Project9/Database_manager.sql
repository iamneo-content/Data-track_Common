-- Active: 1762247202758@@127.0.0.1@3306@bank_branch_db
-- =====================================================================
-- Database : bank_branch_db
-- =====================================================================

DROP DATABASE IF EXISTS bank_branch_db;
CREATE DATABASE bank_branch_db;
USE bank_branch_db;

-- ================================================================
-- Table: branches
-- ================================================================
CREATE TABLE branches (
    branch_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_name VARCHAR(80) NOT NULL,
    city VARCHAR(60) NOT NULL,
    manager_name VARCHAR(80)
);

-- ================================================================
-- Table: transactions
-- ================================================================
CREATE TABLE transactions (
    txn_id INT PRIMARY KEY AUTO_INCREMENT,
    branch_id INT NOT NULL,
    txn_date DATE,
    amount DECIMAL(12,2) NOT NULL,
    txn_type VARCHAR(20),
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id)
);

-- ================================================================
-- Insert branch details
-- ================================================================
INSERT INTO branches (branch_name, city, manager_name) VALUES
('Central Branch', 'Mumbai', 'Ravi Kumar'),
('South Extension', 'Chennai', 'Anita Sharma'),
('Tech Park', 'Bangalore', 'Kiran Dev'),
('Connaught Place', 'Delhi', 'Neha Verma'),
('Old Town', 'Kolkata', 'Vikram Patel'),
('Marina Bay', 'Chennai', 'Priya Menon'),
('City Center', 'Pune', 'Arjun Reddy'),
('Hi-Tech City', 'Hyderabad', 'Deepa Thomas'),
('Diamond District', 'Surat', 'Rahul Das'),
('Cyber Tower', 'Gurugram', 'Aarti Nair');

-- ================================================================
-- Insert transactions
-- ================================================================
INSERT INTO transactions (branch_id, txn_date, amount, txn_type) VALUES
(1,'2025-01-03',250000.00,'Deposit'),
(1,'2025-01-18',180000.00,'Withdrawal'),
(2,'2025-02-05',220000.00,'Deposit'),
(2,'2025-02-28',195000.00,'Withdrawal'),
(3,'2025-02-15',310000.00,'Deposit'),
(3,'2025-03-02',260000.00,'Deposit'),
(4,'2025-03-07',275000.00,'Deposit'),
(4,'2025-03-09',95000.00,'Withdrawal'),
(5,'2025-03-12',230000.00,'Deposit'),
(6,'2025-03-20',150000.00,'Deposit'),
(7,'2025-03-21',245000.00,'Deposit'),
(8,'2025-03-25',280000.00,'Deposit'),
(9,'2025-03-26',120000.00,'Deposit'),
(10,'2025-03-28',205000.00,'Deposit'),
(3,'2025-04-02',195000.00,'Withdrawal'),
(4,'2025-04-04',210000.00,'Deposit'),
(5,'2025-04-05',260000.00,'Deposit'),
(6,'2025-04-06',175000.00,'Deposit'),
(7,'2025-04-07',190000.00,'Withdrawal'),
(8,'2025-04-08',300000.00,'Deposit'),
(9,'2025-04-09',165000.00,'Deposit'),
(10,'2025-04-10',215000.00,'Deposit'),
(1,'2025-04-11',205000.00,'Deposit'),
(2,'2025-04-12',210000.00,'Deposit'),
(5,'2025-04-13',185000.00,'Deposit');
