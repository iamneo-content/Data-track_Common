import ast
import json
import re
from pathlib import Path
import pytest
from pyspark.sql import SparkSession, Row
import solution

HARD_CODE_LITERALS = {
    "2024-05-10", "2024-05-11", "2024-05-12", "2024-05-13", "2024-05-14", "2024-05-15",
    "O001","O002","O003","O004","O005","O006","O007","O008","O009","O010",
    "O011","O012","O013","O014","O015","O016","O017","O018","O019","O020",
}
ELIF_MAX = 3

def _assert_not_hardcoded():
    p = Path("solution.py")
    assert p.exists(), "expected 'solution.py' to exist, but file not found"
    src = p.read_text(encoding="utf-8")
    try:
        tree = ast.parse(src, filename="solution.py")
    except SyntaxError as e:
        pytest.fail(f"solution.py has a SyntaxError and cannot be parsed: {e}")
    elif_count = len(re.findall(r"\belif\b", src))
    assert elif_count <= ELIF_MAX, f"style guard failed: expected at most {ELIF_MAX} 'elif' tokens, but found {elif_count}"
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            for sub in ast.walk(node):
                if isinstance(sub, ast.Constant) and isinstance(sub.value, str):
                    lit = sub.value
                    assert lit not in HARD_CODE_LITERALS, f"hardcoding detected: '{lit}' in '{node.name}'"

@pytest.fixture(autouse=True)
def test_hardcoding_and_style_guard():
    _assert_not_hardcoded()

def _write_json(path: Path, obj):
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")

def test_start_spark():
    spark = None
    try:
        spark = solution.start_spark("Unit_Start_Spark")
        assert isinstance(spark, SparkSession), f"expected SparkSession, got {type(spark)}"
        assert SparkSession.getActiveSession() is not None, "expected an active SparkSession after start_spark, got None"
        master = spark.sparkContext.master
        assert master.startswith("local"), f"expected master starting with 'local', got {master!r}"
    finally:
        solution.stop_spark(spark)

def test_stop_spark():
    spark = solution.start_spark("Unit_Stop_Spark")
    assert SparkSession.getActiveSession() is not None, "precondition failed: active session expected before stop_spark"
    solution.stop_spark(spark)
    assert SparkSession.getActiveSession() is None, "after first stop_spark, expected no active session"
    solution.stop_spark(spark)
    assert SparkSession.getActiveSession() is None, "after second stop_spark, expected no active session (idempotent)"

def test_read_sales_data(tmp_path):
    sales = [
        {"order_id": "T001", "total": "450.50", "date": "2024-01-01"},
        {"order_id": "T002", "total": "1200.00", "date": "2024-01-02"},
        {"order_id": "T003", "total": "75.00", "date": "2024-01-03"},
    ]
    f = tmp_path / "sales.json"
    _write_json(f, sales)
    spark = solution.start_spark("Unit_Read_Sales")
    try:
        df = solution.read_sales_data(spark, str(f))
        expected_cols = {"order_id", "total", "date"}
        actual_cols = set(df.columns)
        assert actual_cols == expected_cols, f"columns mismatch\nexpected: {expected_cols}\nactual: {actual_cols}"
        cnt = df.count()
        assert cnt == 3, f"row count mismatch\nexpected: 3\nactual: {cnt}"
        dtypes = dict(df.dtypes)
        assert dtypes.get("total") == "string", f"expected 'total' inferred as string from JSON, got: {dtypes.get('total')}"
    finally:
        solution.stop_spark(spark)

def test_filter_high_value_sales():
    spark = solution.start_spark("Unit_Filter_Sales")
    try:
        rows = [
            Row(order_id="A1", total="999.99", date="2024-01-01"),
            Row(order_id="A2", total="1000.00", date="2024-01-01"),
            Row(order_id="A3", total="1000.01", date="2024-01-01"),
            Row(order_id="A4", total="2500.50", date="2024-01-02"),
            Row(order_id="A5", total="10.00",   date="2024-01-03"),
        ]
        df = spark.createDataFrame(rows)
        out = solution.filter_high_value_sales(spark, df)
        ids = [r["order_id"] for r in out.orderBy("order_id").select("order_id").collect()]
        expected = ["A3", "A4"]
        assert ids == expected, f"filtered ids mismatch for total > 1000\nexpected: {expected}\nactual: {ids}"
        dtypes = dict(out.dtypes)
        assert dtypes.get("total") in ("double", "float"), f"expected 'total' cast to numeric, got: {dtypes.get('total')}"
    finally:
        solution.stop_spark(spark)
