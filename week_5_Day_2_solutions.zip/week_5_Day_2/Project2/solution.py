from pyspark.sql import SparkSession
from pyspark.sql.functions import col


def start_spark(app_name):
    """
    Start and return a SparkSession.
    """
    return (
        SparkSession.builder
        .appName(app_name)
        .getOrCreate()
    )


def stop_spark(spark):
    """
    Stop the provided SparkSession.
    """
    if spark is not None:
        spark.stop()


def read_sales_data(spark, data_path):
    """
    Read sales JSON file and return it as a DataFrame.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session.
    data_path : str
        Path to the sales JSON file (e.g., './data/sales.json').

    Returns
    -------
    DataFrame
        DataFrame created from the JSON file.
    """
    df = (
        spark.read
        .option("multiLine", True)
        .json(data_path)
    )
    return df


def filter_high_value_sales(spark, sales_df):
    """
    Filter the given DataFrame to return rows where total > 1000.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session.
    sales_df : DataFrame
        DataFrame containing sales data.

    Returns
    -------
    DataFrame
        Filtered DataFrame with high-value sales.
    """
    # Convert total column to double for comparison
    sales_df = sales_df.withColumn("total", col("total").cast("double"))

    # Filter records
    filtered_df = sales_df.filter(col("total") > 1000)

    return filtered_df
