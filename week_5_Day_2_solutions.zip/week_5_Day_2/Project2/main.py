# ==================================
# DO NOT MODIFY/EDIT BELOW THIS LINE
# ==================================
import solution

DATA_PATH = "data/sales.json"

def main():
    spark = solution.start_spark("SimpleSalesFilter")

    print("\n=== Reading JSON File ===")
    sales_df = solution.read_sales_data(spark, DATA_PATH)
    sales_df.show(10, truncate=False)

    print("\n=== Filtering Sales with total > 1000 ===")
    filtered_df = solution.filter_high_value_sales(spark, sales_df)
    filtered_df.show(10, truncate=False)

    solution.stop_spark(spark)


if __name__ == "__main__":
    main()
