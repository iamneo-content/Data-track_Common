# ==================================
# DO NOT MODIFY/EDIT BELOW THIS LINE
# ==================================
import solution

DATA_PATH = "data/customers.csv"

def main() -> None:
    spark = solution.start_spark(app_name="CustomersAnalysis")

    print("\n=== Driver: Input Path ===")
    print(f"DATA_PATH: {DATA_PATH}")

    print("\n=== Driver: Intermediate Preview (first 5 rows) ===")
    preview_df = solution.read_customers_data(spark, DATA_PATH)
    preview_df.show(5, truncate=False)

    print("\n=== Operation: Schema & Metrics ===")
    total_rows, distinct_regions = solution.analyze_customers(spark, preview_df)

    print("\n=== Final Output ===")
    print(f"Total rows: {total_rows}")
    print(f"Distinct regions: {distinct_regions}")

    solution.stop_spark(spark)

if __name__ == "__main__":
    main()
