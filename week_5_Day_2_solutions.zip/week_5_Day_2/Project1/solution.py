from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col


def start_spark(app_name):
    """
    Start and return a SparkSession.
    """
    return (
        SparkSession.builder
        .appName(app_name)
        .getOrCreate()
    )


def stop_spark(spark):
    """
    Stop the provided SparkSession.
    """
    if spark is not None:
        spark.stop()


def read_customers_data(spark, data_path):
    """
    Read customers CSV file and return it as a DataFrame.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session.
    data_path : str
        Path to the customers CSV (e.g., './data/customers.csv').

    Returns
    -------
    DataFrame
        DataFrame created from the customers CSV file.
    """
    df = (
        spark.read
        .option("header", True)
        .option("inferSchema", True)
        .csv(data_path)
    )
    return df


def analyze_customers(spark, customers_df):
    """
    Read customers CSV as a DataFrame, print schema, and return metrics.

    Returns
    -------
    tuple[int, int]
        A tuple of (total_row_count, distinct_region_count).
    """
    total_rows = customers_df.count()
    distinct_regions = customers_df.select(col("region")).distinct().count()

    return total_rows, distinct_regions
