import ast
import csv
import re
from pathlib import Path
import pytest
from pyspark.sql import SparkSession
from pyspark.sql import Row
import solution

HARD_CODE_LITERALS = {
    "North", "South", "East", "West",
    "Amara Joseph", "Ravi Kumar", "Diya Patel", "Arjun Mehta",
    "Beena Sharma", "Vikram Das", "Nisha Reddy", "Chirag Jain",
    "Leena Thomas", "Ankit Bansal", "Mira Nair", "Karan Malhotra",
    "Sana Iyer", "Rohit Sinha", "Preeti Kaur", "Sameer Roy",
    "Aisha Khan", "Manoj Pillai", "Divya Das", "Harish Menon",
    "C001", "C002", "C003", "C004", "C005", "C006", "C007", "C008",
    "C009", "C010", "C011", "C012", "C013", "C014", "C015", "C016",
    "C017", "C018", "C019", "C020"
}
ELIF_MAX = 3

def _assert_not_hardcoded():
    src_path = Path("solution.py")
    assert src_path.exists(), "expected 'solution.py' to exist, but file not found"
    src = src_path.read_text(encoding="utf-8")
    try:
        tree = ast.parse(src, filename="solution.py")
    except SyntaxError as e:
        pytest.fail(f"solution.py has a SyntaxError and cannot be parsed: {e}")
    elif_count = len(re.findall(r"\belif\b", src))
    assert elif_count <= ELIF_MAX, f"style guard failed: expected at most {ELIF_MAX} 'elif' tokens, but found {elif_count}"
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            for sub in ast.walk(node):
                if isinstance(sub, ast.Constant) and isinstance(sub.value, str):
                    lit = sub.value
                    assert lit not in HARD_CODE_LITERALS, f"hardcoding detected: '{lit}' in '{node.name}'"

@pytest.fixture(autouse=True)
def test_hardcoding_and_style_guard():
    _assert_not_hardcoded()

def _write_customers_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["customer_id", "name", "region", "age", "active"])
        w.writerows(rows)

def test_start_spark():
    spark = None
    try:
        spark = solution.start_spark(app_name="Unit_Start_Spark")
        assert isinstance(spark, SparkSession), f"expected SparkSession, got {type(spark)}"
        active = SparkSession.getActiveSession()
        assert active is not None, "expected an active SparkSession after start_spark, got None"
        master = spark.sparkContext.master
        assert master.startswith("local"), f"expected master starting with 'local', got {master!r}"
    finally:
        solution.stop_spark(spark)

def test_stop_spark():
    spark = solution.start_spark(app_name="Unit_Stop_Spark")
    assert SparkSession.getActiveSession() is not None, "precondition failed: active session expected before stop_spark"
    solution.stop_spark(spark)
    assert SparkSession.getActiveSession() is None, "after first stop_spark, expected no active session"
    solution.stop_spark(spark)
    assert SparkSession.getActiveSession() is None, "after second stop_spark, expected no active session (idempotent)"

def test_read_customers_data(tmp_path):
    csv_path = tmp_path / "customers.csv"
    _write_customers_csv(csv_path, [
        ["C001", "Alice", "North", 29, True],
        ["C002", "Bob", "South", 35, False],
        ["C003", "Charlie", "East", 40, True],
    ])
    spark = solution.start_spark(app_name="Unit_Read_Customers")
    try:
        df = solution.read_customers_data(spark, str(csv_path))
        expected_cols = ["customer_id", "name", "region", "age", "active"]
        assert df.columns == expected_cols, f"columns mismatch\nexpected: {expected_cols}\nactual: {df.columns}"
        dtypes = dict(df.dtypes)
        age_dtype = dtypes.get("age")
        active_dtype = dtypes.get("active")
        assert age_dtype in ("int", "bigint", "smallint"), f"expected integer type for age, got: {age_dtype}"
        assert active_dtype == "boolean", f"expected boolean type for active, got: {active_dtype}"
        cnt = df.count()
        assert cnt == 3, f"row count mismatch\nexpected: 3\nactual: {cnt}"
        first = df.orderBy("customer_id").first().asDict()
        assert first["customer_id"] == "C001" and first["name"] == "Alice", f"unexpected first row\nexpected: C001/Alice\nactual: {first}"
    finally:
        solution.stop_spark(spark)

def test_analyze_customers():
    spark = solution.start_spark(app_name="Unit_Analyze_Customers")
    try:
        rows = [
            Row(customer_id="C001", name="A", region="North", age=30, active=True),
            Row(customer_id="C002", name="B", region="South", age=31, active=True),
            Row(customer_id="C003", name="C", region="South", age=22, active=False),
            Row(customer_id="C004", name="D", region="East",  age=44, active=True),
            Row(customer_id="C005", name="E", region="East",  age=28, active=True),
        ]
        df = spark.createDataFrame(rows)
        total_rows, distinct_regions = solution.analyze_customers(spark, df)
        assert isinstance(total_rows, int) and isinstance(distinct_regions, int), f"expected tuple[int, int], got ({type(total_rows)}, {type(distinct_regions)})"
        assert total_rows == 5, f"total rows mismatch\nexpected: 5\nactual: {total_rows}"
        assert distinct_regions == 3, f"distinct regions mismatch\nexpected: 3\nactual: {distinct_regions}"
    finally:
        solution.stop_spark(spark)
