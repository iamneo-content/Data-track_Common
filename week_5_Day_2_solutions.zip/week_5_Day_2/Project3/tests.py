import ast
import re
from pathlib import Path
import pytest
from pyspark.sql import SparkSession, Row
import solution

HARD_CODE_LITERALS = {
    "RDDtoDataFrame_Students",
    "Arjun","Beena","Chirag","Diya","Eshan","Fatima","Gaurav","Harini","Irfan","Jaya",
    "Kiran","Lakshmi","Manoj","Neha","Omkar","Priya","Rahul","Sneha","Tanya","Vikram",
    "5","6","7","9","10","11","12","13","14","15","16","17","19","20"
}
ELIF_MAX = 3

def _assert_not_hardcoded():
    p = Path("solution.py")
    assert p.exists(), "expected 'solution.py' to exist, but file not found"
    src = p.read_text(encoding="utf-8")
    try:
        tree = ast.parse(src, filename="solution.py")
    except SyntaxError as e:
        pytest.fail(f"solution.py has a SyntaxError and cannot be parsed: {e}")
    elif_count = len(re.findall(r"\belif\b", src))
    assert elif_count <= ELIF_MAX, f"style guard failed: expected at most {ELIF_MAX} 'elif' tokens, but found {elif_count}"
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            for sub in ast.walk(node):
                if isinstance(sub, ast.Constant) and isinstance(sub.value, str):
                    lit = sub.value
                    assert lit not in HARD_CODE_LITERALS, f"hardcoding detected: '{lit}' in '{node.name}'"

@pytest.fixture(autouse=True)
def test_hardcoding_and_style_guard():
    _assert_not_hardcoded()

def test_start_spark():
    spark = None
    try:
        spark = solution.start_spark(app_name="Unit_Start_Spark")
        assert isinstance(spark, SparkSession), f"expected SparkSession, got {type(spark)}"
        assert SparkSession.getActiveSession() is not None, "expected an active SparkSession after start_spark, got None"
        master = spark.sparkContext.master
        assert master.startswith("local"), f"expected master starting with 'local', got {master!r}"
    finally:
        solution.stop_spark(spark)

def test_stop_spark():
    spark = solution.start_spark(app_name="Unit_Stop_Spark")
    assert SparkSession.getActiveSession() is not None, "precondition failed: active session expected before stop_spark"
    solution.stop_spark(spark)
    assert SparkSession.getActiveSession() is None, "after first stop_spark, expected no active session"
    solution.stop_spark(spark)
    assert SparkSession.getActiveSession() is None, "after second stop_spark, expected no active session (idempotent)"

def test_create_students_rdd():
    spark = solution.start_spark(app_name="Unit_Create_RDD")
    try:
        data = [(1,"A",85),(2,"B",70),(3,"C",92)]
        rdd = solution.create_students_rdd(spark, data)
        sample = rdd.take(3)
        assert sample == data, f"RDD contents mismatch\nexpected: {data}\nactual: {sample}"
        assert rdd.count() == 3, f"RDD count mismatch\nexpected: 3\nactual: {rdd.count()}"
    finally:
        solution.stop_spark(spark)

def test_rdd_to_students_df():
    spark = solution.start_spark(app_name="Unit_RDD_to_DF")
    try:
        data = [(10,"X",81),(11,"Y",90),(12,"Z",76)]
        rdd = spark.sparkContext.parallelize(data)
        df = solution.rdd_to_students_df(spark, rdd)
        expected_cols = ["id","name","score"]
        assert df.columns == expected_cols, f"columns mismatch\nexpected: {expected_cols}\nactual: {df.columns}"
        dtypes = dict(df.dtypes)
        assert dtypes.get("id") in ("int","bigint","smallint"), f"expected integer type for id, got: {dtypes.get('id')}"
        assert dtypes.get("name") == "string", f"expected string type for name, got: {dtypes.get('name')}"
        assert dtypes.get("score") in ("int","bigint","smallint"), f"expected integer type for score, got: {dtypes.get('score')}"
        rows = [tuple(r) for r in df.orderBy("id").collect()]
        assert rows == data, f"data mismatch after conversion\nexpected: {data}\nactual: {rows}"
    finally:
        solution.stop_spark(spark)

def test_filter_high_scorers():
    spark = solution.start_spark(app_name="Unit_Filter")
    try:
        rows = [Row(id=1,name="A",score=80), Row(id=2,name="B",score=81), Row(id=3,name="C",score=95)]
        df = spark.createDataFrame(rows)
        out = solution.filter_high_scorers(df, min_score=80)
        expected_cols = ["id","name","score"]
        assert out.columns == expected_cols, f"columns mismatch after filter\nexpected: {expected_cols}\nactual: {out.columns}"
        ids = [r["id"] for r in out.orderBy("id").select("id").collect()]
        expected_ids = [2,3]
        assert ids == expected_ids, f"filtering mismatch for score > 80\nexpected ids: {expected_ids}\nactual ids: {ids}"
        dtypes = dict(out.dtypes)
        assert dtypes.get("score") in ("int","bigint","smallint"), f"expected integer type for score, got: {dtypes.get('score')}"
    finally:
        solution.stop_spark(spark)
