# ==================================
# DO NOT MODIFY/EDIT BELOW THIS LINE
# ==================================
import solution

def main():
    students_data = [
        (1, "Arjun", 85),
        (2, "Beena", 90),
        (3, "Chirag", 78),
        (4, "Diya", 88),
        (5, "Eshan", 67),
        (6, "Fatima", 92),
        (7, "Gaurav", 73),
        (8, "Harini", 81),
        (9, "Irfan", 76),
        (10, "Jaya", 89),
        (11, "Kiran", 95),
        (12, "Lakshmi", 79),
        (13, "Manoj", 84),
        (14, "Neha", 90),
        (15, "Omkar", 68),
        (16, "Priya", 83),
        (17, "Rahul", 77),
        (18, "Sneha", 91),
        (19, "Tanya", 74),
        (20, "Vikram", 88),
    ]

    spark = solution.start_spark(app_name="RDDtoDataFrame_Students")

    print("\n=== Driver: Input Preview (first 5) ===")
    for row in students_data[:5]:
        print(row)

    print("\n=== Operation: Create RDD from List ===")
    students_rdd = solution.create_students_rdd(spark, students_data)
    print("RDD sample:", students_rdd.take(5))

    print("\n=== Operation: Convert RDD to DataFrame ===")
    students_df = solution.rdd_to_students_df(spark, students_rdd)
    students_df.printSchema()
    students_df.show(10, truncate=False)

    print("\n=== Operation: Filter High Scorers (score > 80) ===")
    high_scorers_df = solution.filter_high_scorers(students_df, min_score=80)
    high_scorers_df.printSchema()
    high_scorers_df.orderBy("score", ascending=False).show(50, truncate=False)

    print("\n=== Final Output: Counts ===")
    total_count = students_df.count()
    high_count = high_scorers_df.count()
    print(f"Total students: {total_count}")
    print(f"Students with score > 80: {high_count}")

    solution.stop_spark(spark)

if __name__ == "__main__":
    main()
