from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType, StructField, IntegerType, StringType


def start_spark(app_name):
    """
    Start and return a SparkSession.

    Parameters
    ----------
    app_name : str
        Spark application name.

    Returns
    -------
    SparkSession
        Active Spark session.
    """
    return (
        SparkSession.builder
        .appName(app_name)
        .getOrCreate()
    )


def stop_spark(spark):
    """
    Stop the provided SparkSession.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session to stop.

    Returns
    -------
    None
    """
    if spark is not None:
        spark.stop()


def create_students_rdd(spark, students_data):
    """
    Create an RDD from a Python list of student tuples.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session.
    students_data : list of tuples
        Each tuple is (id, name, score).

    Returns
    -------
    RDD
        RDD of (id, name, score) tuples.
    """
    return spark.sparkContext.parallelize(students_data)


def rdd_to_students_df(spark, students_rdd):
    """
    Convert an RDD of student tuples into a DataFrame with a defined schema.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session.
    students_rdd : RDD
        RDD containing (id, name, score) tuples.

    Returns
    -------
    DataFrame
        DataFrame with columns: id (int), name (string), score (int).
    """
    schema = StructType([
        StructField("id", IntegerType(), False),
        StructField("name", StringType(), False),
        StructField("score", IntegerType(), False),
    ])
    return spark.createDataFrame(students_rdd, schema=schema)


def filter_high_scorers(students_df, min_score):
    """
    Return only students whose score is greater than the given threshold.

    Parameters
    ----------
    students_df : DataFrame
        Input DataFrame with columns id, name, score.
    min_score : int, optional
        Minimum score threshold (exclusive), default is 80.

    Returns
    -------
    DataFrame
        Filtered DataFrame with columns id, name, score.
    """
    return students_df.filter(students_df["score"] > min_score).select("id", "name", "score")
