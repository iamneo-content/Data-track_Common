# main.py  –  Student Grades Management
import sqlite3
import pandas as pd

# Connect / create DB in memory
conn = sqlite3.connect(":memory:")
cur = conn.cursor()

# Create tables
cur.execute("""
CREATE TABLE students(
    student_id INTEGER PRIMARY KEY,
    student_name TEXT,
    department TEXT
);
""")

cur.execute("""
CREATE TABLE grades(
    student_id INTEGER,
    subject TEXT,
    marks INTEGER,
    FOREIGN KEY(student_id) REFERENCES students(student_id)
);
""")

# Insert ≤10 students + marks
students = [
    (1, "Amit", "CSE"),
    (2, "Neha", "CSE"),
    (3, "Raj", "ECE"),
    (4, "Sara", "EEE"),
    (5, "Vikram", "CSE")
]
grades = [
    (1, "Math", 85), (1, "Physics", 78), (1, "Chemistry", 90),
    (2, "Math", 72), (2, "Physics", 69), (2, "Chemistry", 80),
    (3, "Math", 88), (3, "Physics", 92), (3, "Chemistry", 81),
    (4, "Math", 60), (4, "Physics", 58), (4, "Chemistry", 65),
    (5, "Math", 90), (5, "Physics", 84), (5, "Chemistry", 89)
]
cur.executemany("INSERT INTO students VALUES (?,?,?);", students)
cur.executemany("INSERT INTO grades VALUES (?,?,?);", grades)
conn.commit()

# SQL from Python
sql_query = """
SELECT s.student_name, ROUND(AVG(g.marks),2) AS avg_marks
FROM students s JOIN grades g ON s.student_id = g.student_id
GROUP BY s.student_name
ORDER BY avg_marks DESC;
"""
df = pd.read_sql_query(sql_query, conn)
print(df)

conn.close()
