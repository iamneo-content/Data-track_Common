import pytest
import sqlite3
import pandas as pd
from pathlib import Path
import re

def _extract_sql_from_main():
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    text = p.read_text(encoding="utf-8")
    pattern = r'sql_query\s*=\s*("""|\'\'\')(.*?)\1'
    match = re.search(pattern, text, re.DOTALL)
    assert match, "SQL query not found in main.py."
    return match.group(2).strip()

def _build_test_db():
    conn = sqlite3.connect(":memory:")
    cur = conn.cursor()
    cur.executescript("""
    CREATE TABLE students(
        student_id INTEGER PRIMARY KEY,
        student_name TEXT,
        department TEXT
    );
    CREATE TABLE grades(
        student_id INTEGER,
        subject TEXT,
        marks INTEGER,
        FOREIGN KEY(student_id) REFERENCES students(student_id)
    );
    """)
    students = [
        (1, "Amit", "CSE"),
        (2, "Neha", "CSE"),
        (3, "Raj", "ECE"),
        (4, "Sara", "EEE"),
        (5, "Vikram", "CSE")
    ]
    grades = [
        (1, "Math", 85), (1, "Physics", 78), (1, "Chemistry", 90),
        (2, "Math", 72), (2, "Physics", 69), (2, "Chemistry", 80),
        (3, "Math", 88), (3, "Physics", 92), (3, "Chemistry", 81),
        (4, "Math", 60), (4, "Physics", 58), (4, "Chemistry", 65),
        (5, "Math", 90), (5, "Physics", 84), (5, "Chemistry", 89)
    ]
    cur.executemany("INSERT INTO students VALUES (?,?,?);", students)
    cur.executemany("INSERT INTO grades VALUES (?,?,?);", grades)
    conn.commit()
    return conn

def test_student_avg_marks_output():
    sql = _extract_sql_from_main()
    conn = _build_test_db()
    df = pd.read_sql_query(sql, conn)
    conn.close()

    expected_data = pd.DataFrame({
        "student_name": ["Vikram", "Raj", "Amit", "Neha", "Sara"],
        "avg_marks": [87.67, 87.00, 84.33, 73.67, 61.00]
    })

    expected_data = expected_data.sort_values("avg_marks", ascending=False).reset_index(drop=True)
    df = df.sort_values("avg_marks", ascending=False).reset_index(drop=True)

    expected_cols = list(expected_data.columns)
    actual_cols = list(df.columns)
    assert expected_cols == actual_cols, (
        f"Test Failed: Column mismatch.\nExpected columns: {expected_cols}\nActual columns: {actual_cols}"
    )

    assert len(df) == len(expected_data), (
        f"Test Failed: Expected {len(expected_data)} rows, but got {len(df)} rows."
    )

    for i, (exp_row, act_row) in enumerate(zip(expected_data.itertuples(index=False), df.itertuples(index=False))):
        exp_name, exp_avg = exp_row
        act_name, act_avg = act_row

        assert exp_name == act_name, (
            f"Row {i} student mismatch.\nExpected: {exp_name}\nActual: {act_name}"
        )

        assert round(exp_avg, 2) == round(act_avg, 2), (
            f"Row {i} avg_marks mismatch for student {exp_name}.\nExpected: {exp_avg}\nActual: {act_avg}"
        )

    assert df.equals(expected_data), (
        f"Test Failed: Final DataFrame output mismatch.\n\nExpected:\n{expected_data}\n\nActual:\n{df}"
    )
