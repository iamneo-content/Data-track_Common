import pytest
import sqlite3
import pandas as pd
import ast
from pathlib import Path
from main import create_and_populate_database
from solution import query

HARD_CODE_LITERALS = {
    "Electronics", "Stationery", "Home Essentials",
    4711.0, 2935.0, 1715.0
}

def _assert_not_hardcoded_solution():
    p = Path("solution.py")
    assert p.exists(), "solution.py not found in project root."
    src = p.read_text(encoding="utf-8")
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in solution.py: {e}")
    found_literals = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant):
            found_literals.add(node.value)
    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded output literals detected in solution.py: {sorted(overlap)}")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded_solution()

def test_solution_query_correctness():
    conn = sqlite3.connect(":memory:")
    create_and_populate_database(conn)
    df = pd.read_sql_query(query, conn)
    conn.close()

    expected_cols = {"category", "total_revenue"}
    actual_cols = set(df.columns)
    assert actual_cols == expected_cols, f"Expected columns {expected_cols}, but found {actual_cols}"

    assert not df.empty, "The query returned an empty result set. Expected non-empty results."

    invalid_values = df.loc[df["total_revenue"] <= 0, "total_revenue"].tolist()
    assert invalid_values == [] or all(v > 0 for v in df["total_revenue"]), (
        f"Found non-positive total_revenue values: {invalid_values}. All should be positive."
    )

    expected_categories = {"Electronics", "Stationery", "Home Essentials"}
    actual_categories = set(df["category"])
    assert expected_categories == actual_categories, (
        f"Category mismatch. Expected categories: {expected_categories}, "
        f"but found: {actual_categories}"
    )

    sorted_df = df.sort_values("total_revenue", ascending=False).reset_index(drop=True)
    assert df.equals(sorted_df), (
        f"The results are not sorted by total_revenue in descending order.\n"
        f"Expected order:\n{sorted_df}\n\nActual order:\n{df}"
    )

    total_sum = round(df["total_revenue"].sum(), 2)
    assert 9000 <= total_sum <= 9500, (
        f"Unexpected total revenue sum. Expected between 9000–9500, but found {total_sum}"
    )

    electronics_rev = float(df.loc[df["category"] == "Electronics", "total_revenue"].values[0])
    home_rev = float(df.loc[df["category"] == "Home Essentials", "total_revenue"].values[0])
    stationary_rev = float(df.loc[df["category"] == "Stationery", "total_revenue"].values[0])

    assert 4500 <= electronics_rev <= 4800, (
        f"Electronics revenue out of expected range.\nExpected: 4500–4800, Actual: {electronics_rev}"
    )
    assert 2800 <= home_rev <= 3000, (
        f"Home Essentials revenue out of expected range.\nExpected: 2800–3000, Actual: {home_rev}"
    )
    assert 1600 <= stationary_rev <= 1800, (
        f"Stationery revenue out of expected range.\nExpected: 1600–1800, Actual: {stationary_rev}"
    )

    is_numeric = pd.api.types.is_numeric_dtype(df["total_revenue"])
    assert is_numeric, (
        f"Incorrect data type for total_revenue column. Expected numeric, "
        f"but found {df['total_revenue'].dtype}"
    )
