import sqlite3
import pandas as pd
from solution import query


def create_and_populate_database(connection):
    """Create and populate the products and sales tables with realistic retail data."""
    cursor = connection.cursor()

    # Drop existing tables for clean reruns
    cursor.executescript("""
    DROP TABLE IF EXISTS products;
    DROP TABLE IF EXISTS sales;

    CREATE TABLE products (
        product_id INTEGER PRIMARY KEY,
        product_name TEXT,
        category TEXT,
        unit_price REAL,
        stock_quantity INTEGER
    );

    CREATE TABLE sales (
        sale_id INTEGER PRIMARY KEY,
        product_id INTEGER,
        quantity_sold INTEGER,
        sale_date DATE,
        FOREIGN KEY(product_id) REFERENCES products(product_id)
    );
    """)

    # -----------------------------------
    # Insert Product Master Data
    # -----------------------------------
    cursor.executescript("""
    INSERT INTO products VALUES (1, 'Wireless Mouse', 'Electronics', 25.5, 120);
    INSERT INTO products VALUES (2, 'Mechanical Keyboard', 'Electronics', 70.0, 80);
    INSERT INTO products VALUES (3, 'Laptop Stand', 'Electronics', 40.0, 60);
    INSERT INTO products VALUES (4, 'HDMI Cable', 'Electronics', 10.0, 300);
    INSERT INTO products VALUES (5, 'USB-C Hub', 'Electronics', 35.0, 90);
    INSERT INTO products VALUES (6, 'Notebook', 'Stationery', 5.0, 500);
    INSERT INTO products VALUES (7, 'Ball Pen', 'Stationery', 2.0, 800);
    INSERT INTO products VALUES (8, 'Highlighter Set', 'Stationery', 8.0, 200);
    INSERT INTO products VALUES (9, 'Whiteboard Marker', 'Stationery', 4.0, 250);
    INSERT INTO products VALUES (10, 'Stapler', 'Stationery', 7.5, 150);
    INSERT INTO products VALUES (11, 'Coffee Mug', 'Home Essentials', 12.0, 100);
    INSERT INTO products VALUES (12, 'Wall Clock', 'Home Essentials', 25.0, 75);
    INSERT INTO products VALUES (13, 'Desk Lamp', 'Home Essentials', 40.0, 60);
    INSERT INTO products VALUES (14, 'Photo Frame', 'Home Essentials', 15.0, 90);
    INSERT INTO products VALUES (15, 'Water Bottle', 'Home Essentials', 18.0, 200);
    """)

    # -----------------------------------
    # Insert Sales Transactions (85 rows)
    # -----------------------------------
    cursor.executescript("""
    INSERT INTO sales VALUES
    (1, 1, 3, '2025-01-01'),
    (2, 2, 2, '2025-01-01'),
    (3, 3, 1, '2025-01-02'),
    (4, 4, 5, '2025-01-03'),
    (5, 5, 2, '2025-01-04'),
    (6, 1, 4, '2025-01-05'),
    (7, 2, 3, '2025-01-06'),
    (8, 3, 2, '2025-01-06'),
    (9, 4, 8, '2025-01-07'),
    (10, 5, 4, '2025-01-07'),
    (11, 6, 20, '2025-01-08'),
    (12, 7, 25, '2025-01-08'),
    (13, 8, 10, '2025-01-09'),
    (14, 9, 12, '2025-01-10'),
    (15, 10, 8, '2025-01-11'),
    (16, 11, 6, '2025-01-11'),
    (17, 12, 3, '2025-01-12'),
    (18, 13, 2, '2025-01-12'),
    (19, 14, 5, '2025-01-13'),
    (20, 15, 9, '2025-01-13'),
    (21, 1, 6, '2025-01-14'),
    (22, 2, 4, '2025-01-14'),
    (23, 3, 3, '2025-01-15'),
    (24, 4, 10, '2025-01-15'),
    (25, 5, 5, '2025-01-15'),
    (26, 6, 18, '2025-01-16'),
    (27, 7, 22, '2025-01-16'),
    (28, 8, 8, '2025-01-17'),
    (29, 9, 15, '2025-01-17'),
    (30, 10, 9, '2025-01-18'),
    (31, 11, 7, '2025-01-18'),
    (32, 12, 4, '2025-01-19'),
    (33, 13, 3, '2025-01-19'),
    (34, 14, 4, '2025-01-20'),
    (35, 15, 10, '2025-01-20'),
    (36, 1, 5, '2025-01-21'),
    (37, 2, 2, '2025-01-21'),
    (38, 3, 4, '2025-01-22'),
    (39, 4, 9, '2025-01-22'),
    (40, 5, 6, '2025-01-22'),
    (41, 6, 25, '2025-01-23'),
    (42, 7, 28, '2025-01-23'),
    (43, 8, 12, '2025-01-24'),
    (44, 9, 18, '2025-01-25'),
    (45, 10, 10, '2025-01-25'),
    (46, 11, 8, '2025-01-26'),
    (47, 12, 6, '2025-01-26'),
    (48, 13, 4, '2025-01-26'),
    (49, 14, 5, '2025-01-27'),
    (50, 15, 12, '2025-01-27'),
    (51, 1, 3, '2025-01-28'),
    (52, 2, 5, '2025-01-28'),
    (53, 3, 2, '2025-01-28'),
    (54, 4, 7, '2025-01-29'),
    (55, 5, 3, '2025-01-29'),
    (56, 6, 16, '2025-01-30'),
    (57, 7, 21, '2025-01-30'),
    (58, 8, 10, '2025-01-30'),
    (59, 9, 14, '2025-01-31'),
    (60, 10, 9, '2025-01-31'),
    (61, 11, 9, '2025-02-01'),
    (62, 12, 5, '2025-02-01'),
    (63, 13, 6, '2025-02-01'),
    (64, 14, 5, '2025-02-02'),
    (65, 15, 10, '2025-02-02'),
    (66, 1, 7, '2025-02-03'),
    (67, 2, 4, '2025-02-03'),
    (68, 3, 3, '2025-02-03'),
    (69, 4, 11, '2025-02-04'),
    (70, 5, 4, '2025-02-04'),
    (71, 6, 15, '2025-02-04'),
    (72, 7, 18, '2025-02-04'),
    (73, 8, 7, '2025-02-04'),
    (74, 9, 15, '2025-02-04'),
    (75, 10, 10, '2025-02-04'),
    (76, 11, 5, '2025-02-05'),
    (77, 12, 4, '2025-02-05'),
    (78, 13, 3, '2025-02-05'),
    (79, 14, 4, '2025-02-06'),
    (80, 15, 9, '2025-02-06'),
    (81, 1, 4, '2025-02-07'),
    (82, 2, 3, '2025-02-07'),
    (83, 3, 2, '2025-02-07'),
    (84, 4, 9, '2025-02-07'),
    (85, 5, 5, '2025-02-07');
    """)

    connection.commit()


def execute_student_query(connection, sql_query):
    """Execute the student's SQL query and display results."""
    print("\nRunning your SQL query...")
    try:
        result_df = pd.read_sql_query(sql_query, connection)
        print("\nQuery Result:")
        print(result_df)
    except Exception as error:
        print("\nError executing your query:")
        print(error)


def main():
    """Main entry point for the Retail Analytics scenario."""
    connection = sqlite3.connect(":memory:")
    create_and_populate_database(connection)
    execute_student_query(connection, query)
    connection.close()


if __name__ == "__main__":
    main()
