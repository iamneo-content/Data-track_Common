import pytest
import sqlite3
import pandas as pd
import ast
from pathlib import Path
from main import create_and_populate_database
from solution import query

HARD_CODE_LITERALS = {
    "Sales", "IT", "HR", "Marketing", "Finance",
    4.37, 4.33, 4.30, 4.24
}

def _assert_not_hardcoded_solution():
    p = Path("solution.py")
    assert p.exists(), "solution.py not found in project root."
    src = p.read_text(encoding="utf-8")
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in solution.py: {e}")
    found_literals = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant):
            found_literals.add(node.value)
    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded output literals detected in solution.py: {sorted(overlap)}")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded_solution()

def test_solution_query_correctness():
    conn = sqlite3.connect(":memory:")
    create_and_populate_database(conn)
    df = pd.read_sql_query(query, conn)
    conn.close()

    expected_cols = {"department", "total_employees", "avg_department_rating", "high_performers"}
    actual_cols = set(df.columns)
    assert actual_cols == expected_cols, f"Column mismatch. Expected: {expected_cols}, Actual: {actual_cols}"

    assert not df.empty, "Query returned no rows. Expected department-level results."

    invalid_ratings = df.loc[df["avg_department_rating"] <= 0, "avg_department_rating"].tolist()
    assert invalid_ratings == [] or all(df["avg_department_rating"] > 0), (
        f"Found invalid (non-positive) avg_department_rating values: {invalid_ratings}"
    )

    expected_departments = {"Sales", "IT", "HR", "Marketing", "Finance"}
    actual_departments = set(df["department"])
    assert expected_departments == actual_departments, (
        f"Department mismatch.\nExpected: {expected_departments}\nActual: {actual_departments}"
    )

    sorted_df = df.sort_values("avg_department_rating", ascending=False).reset_index(drop=True)
    assert df.equals(sorted_df), (
        "Result set not sorted by avg_department_rating in descending order.\n"
        f"Expected order:\n{sorted_df[['department','avg_department_rating']]}\n\n"
        f"Actual order:\n{df[['department','avg_department_rating']]}"
    )

    total_employees_sum = int(df["total_employees"].sum())
    assert total_employees_sum >= 20, (
        f"Unexpected total employee count across departments.\nExpected ≥ 20, Actual: {total_employees_sum}"
    )

    avg_range = df["avg_department_rating"].between(4.0, 4.5).all()
    assert avg_range, (
        f"Average department ratings are out of expected range 4.0–4.5.\n"
        f"Actual values:\n{df[['department','avg_department_rating']]}"
    )

    high_perf_check = df.loc[df["high_performers"] <= 0, "high_performers"].tolist()
    assert high_perf_check == [] or all(df["high_performers"] > 0), (
        f"Departments with zero high performers found. Each department should have some high performers.\n"
        f"Affected: {high_perf_check}"
    )

    assert pd.api.types.is_numeric_dtype(df["avg_department_rating"]), (
        f"Invalid data type for avg_department_rating column. Expected numeric, "
        f"Actual dtype: {df['avg_department_rating'].dtype}"
    )

    assert pd.api.types.is_numeric_dtype(df["total_employees"]), (
        f"Invalid data type for total_employees column. Expected integer, "
        f"Actual dtype: {df['total_employees'].dtype}"
    )

    assert pd.api.types.is_numeric_dtype(df["high_performers"]), (
        f"Invalid data type for high_performers column. Expected integer, "
        f"Actual dtype: {df['high_performers'].dtype}"
    )
