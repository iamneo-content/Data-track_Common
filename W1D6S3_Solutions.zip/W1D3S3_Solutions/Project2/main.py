import sqlite3
import pandas as pd
from solution import query


def create_and_populate_database(connection):
    """Create and populate employees and performance tables with realistic HR data."""
    cursor = connection.cursor()

    cursor.executescript("""
    DROP TABLE IF EXISTS employees;
    DROP TABLE IF EXISTS performance;

    CREATE TABLE employees (
        employee_id INTEGER PRIMARY KEY,
        employee_name TEXT,
        department TEXT,
        designation TEXT,
        salary REAL,
        joining_date DATE
    );

    CREATE TABLE performance (
        review_id INTEGER PRIMARY KEY,
        employee_id INTEGER,
        rating REAL,
        review_date DATE,
        reviewer_name TEXT,
        FOREIGN KEY(employee_id) REFERENCES employees(employee_id)
    );
    """)

    # --------------------------------------------------
    # Insert realistic employees (~50 records)
    # --------------------------------------------------
    cursor.executescript("""
    INSERT INTO employees VALUES
    (1, 'Amit Sharma', 'Sales', 'Sales Executive', 52000, '2022-04-01'),
    (2, 'Priya Nair', 'Sales', 'Sales Lead', 74000, '2021-06-10'),
    (3, 'Ravi Kumar', 'Sales', 'Account Manager', 68000, '2023-02-15'),
    (4, 'Neha Singh', 'Sales', 'Sales Executive', 54000, '2023-03-01'),
    (5, 'Vikram Rao', 'Sales', 'Sales Manager', 91000, '2020-08-21'),

    (6, 'Anjali Mehta', 'IT', 'Software Engineer', 75000, '2021-07-11'),
    (7, 'Rohit Das', 'IT', 'Data Engineer', 82000, '2022-02-18'),
    (8, 'Kiran Patil', 'IT', 'DevOps Engineer', 81000, '2021-05-22'),
    (9, 'Sneha Gupta', 'IT', 'Backend Developer', 79000, '2023-01-09'),
    (10, 'Deepak Verma', 'IT', 'Tech Lead', 98000, '2020-12-01'),

    (11, 'Meena Iyer', 'HR', 'HR Executive', 58000, '2022-03-01'),
    (12, 'Karthik Menon', 'HR', 'Recruiter', 60000, '2021-11-13'),
    (13, 'Nisha Pillai', 'HR', 'Training Specialist', 62000, '2023-01-15'),
    (14, 'Rahul Khanna', 'HR', 'HR Manager', 88000, '2020-09-10'),

    (15, 'Pooja Bhat', 'Marketing', 'Marketing Executive', 64000, '2021-10-10'),
    (16, 'Tanya Roy', 'Marketing', 'Content Strategist', 66000, '2022-02-05'),
    (17, 'Harish Jain', 'Marketing', 'SEO Analyst', 67000, '2021-12-12'),
    (18, 'Arjun Sinha', 'Marketing', 'Campaign Manager', 92000, '2020-05-30'),

    (19, 'Rakesh Shetty', 'Finance', 'Accountant', 70000, '2021-09-08'),
    (20, 'Divya Krishnan', 'Finance', 'Financial Analyst', 76000, '2022-03-20'),
    (21, 'Abhinav Joshi', 'Finance', 'Accounts Payable Officer', 71000, '2023-02-12'),
    (22, 'Manisha Dey', 'Finance', 'Finance Manager', 95000, '2019-12-15');
    """)

    # --------------------------------------------------
    # Insert realistic performance reviews (~80 records)
    # --------------------------------------------------
    cursor.executescript("""
    INSERT INTO performance VALUES
    (1, 1, 4.5, '2025-01-15', 'Vikram Rao'),
    (2, 2, 4.2, '2025-01-20', 'Vikram Rao'),
    (3, 3, 3.9, '2025-01-25', 'Vikram Rao'),
    (4, 4, 4.0, '2025-02-01', 'Vikram Rao'),
    (5, 5, 4.7, '2025-02-10', 'CEO'),

    (6, 6, 4.3, '2025-01-10', 'Deepak Verma'),
    (7, 7, 3.8, '2025-01-15', 'Deepak Verma'),
    (8, 8, 4.5, '2025-01-20', 'Deepak Verma'),
    (9, 9, 4.1, '2025-01-25', 'Deepak Verma'),
    (10, 10, 4.6, '2025-02-01', 'CTO'),

    (11, 11, 4.0, '2025-01-10', 'Rahul Khanna'),
    (12, 12, 3.7, '2025-01-18', 'Rahul Khanna'),
    (13, 13, 4.1, '2025-01-26', 'Rahul Khanna'),
    (14, 14, 4.8, '2025-02-02', 'CEO'),

    (15, 15, 3.9, '2025-01-12', 'Arjun Sinha'),
    (16, 16, 4.3, '2025-01-18', 'Arjun Sinha'),
    (17, 17, 4.1, '2025-01-23', 'Arjun Sinha'),
    (18, 18, 4.9, '2025-02-05', 'CEO'),

    (19, 19, 3.8, '2025-01-08', 'Manisha Dey'),
    (20, 20, 4.2, '2025-01-16', 'Manisha Dey'),
    (21, 21, 4.0, '2025-01-22', 'Manisha Dey'),
    (22, 22, 4.6, '2025-02-03', 'CEO'),

    -- second round of reviews
    (23, 1, 4.3, '2025-03-01', 'Vikram Rao'),
    (24, 2, 4.4, '2025-03-01', 'Vikram Rao'),
    (25, 3, 4.0, '2025-03-05', 'Vikram Rao'),
    (26, 4, 4.1, '2025-03-06', 'Vikram Rao'),
    (27, 5, 4.9, '2025-03-10', 'CEO'),
    (28, 6, 4.5, '2025-03-01', 'Deepak Verma'),
    (29, 7, 4.1, '2025-03-03', 'Deepak Verma'),
    (30, 8, 4.7, '2025-03-04', 'Deepak Verma'),
    (31, 9, 4.3, '2025-03-05', 'Deepak Verma'),
    (32, 10, 4.8, '2025-03-07', 'CTO'),
    (33, 11, 4.2, '2025-03-02', 'Rahul Khanna'),
    (34, 12, 3.9, '2025-03-04', 'Rahul Khanna'),
    (35, 13, 4.3, '2025-03-05', 'Rahul Khanna'),
    (36, 14, 4.9, '2025-03-06', 'CEO'),
    (37, 15, 4.1, '2025-03-03', 'Arjun Sinha'),
    (38, 16, 4.5, '2025-03-04', 'Arjun Sinha'),
    (39, 17, 4.0, '2025-03-05', 'Arjun Sinha'),
    (40, 18, 4.8, '2025-03-07', 'CEO'),
    (41, 19, 4.0, '2025-03-02', 'Manisha Dey'),
    (42, 20, 4.4, '2025-03-04', 'Manisha Dey'),
    (43, 21, 4.2, '2025-03-05', 'Manisha Dey'),
    (44, 22, 4.7, '2025-03-07', 'CEO');
    """)

    connection.commit()


def execute_student_query(connection, sql_query):
    """Execute the student's SQL query and display results."""
    print("\nRunning your SQL query...")
    try:
        result_df = pd.read_sql_query(sql_query, connection)
        print("\nQuery Result:")
        print(result_df)
    except Exception as error:
        print("\nError executing your query:")
        print(error)


def main():
    """Main entry point for HR Analytics Scenario."""
    connection = sqlite3.connect(":memory:")
    create_and_populate_database(connection)
    execute_student_query(connection, query)
    connection.close()


if __name__ == "__main__":
    main()
