query = """
-- Task: Department-wise Employee Performance Summary
-- Goal: Calculate average ratings and identify departments with consistently good performance.
-- Output columns: department, total_employees, avg_rating, high_performers

WITH department_ratings AS (
    SELECT
        e.department,
        e.employee_id,
        ROUND(AVG(p.rating), 2) AS avg_rating_per_employee
    FROM employees e
    JOIN performance p
        ON e.employee_id = p.employee_id
    GROUP BY e.department, e.employee_id
)
SELECT
    department,
    COUNT(employee_id) AS total_employees,
    ROUND(AVG(avg_rating_per_employee), 2) AS avg_department_rating,
    SUM(CASE WHEN avg_rating_per_employee >= 4.0 THEN 1 ELSE 0 END) AS high_performers
FROM department_ratings
GROUP BY department
HAVING AVG(avg_rating_per_employee) > 3.5
ORDER BY avg_department_rating DESC;
"""
