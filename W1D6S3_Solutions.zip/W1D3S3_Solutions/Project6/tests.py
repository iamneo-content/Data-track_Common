import pytest
import sqlite3
import re
import pandas as pd
from pathlib import Path

def _extract_sql_from_main():
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    text = p.read_text(encoding="utf-8")
    match = re.search(r'sql_query\s*=\s*("""|\'\'\')(.*?)\1', text, re.DOTALL)
    assert match, "sql_query not found in main.py."
    return match.group(2).strip()

def _build_test_db():
    conn = sqlite3.connect(":memory:")
    cur = conn.cursor()
    cur.executescript("""
    CREATE TABLE employees(
        emp_id INTEGER PRIMARY KEY,
        emp_name TEXT,
        department TEXT,
        base_salary REAL
    );
    CREATE TABLE attendance(
        emp_id INTEGER,
        work_date DATE,
        status TEXT,
        FOREIGN KEY(emp_id) REFERENCES employees(emp_id)
    );
    """)
    employees = [
        (1,"Asha","HR",30000),
        (2,"Vijay","IT",40000),
        (3,"Rina","Finance",35000),
        (4,"Karan","IT",38000),
        (5,"Meera","HR",32000)
    ]
    attendance = [
        (1,"2025-02-01","Present"),(1,"2025-02-02","Absent"),
        (2,"2025-02-01","Present"),(2,"2025-02-02","Present"),
        (3,"2025-02-01","Present"),(3,"2025-02-02","Present"),
        (4,"2025-02-01","Absent"),(4,"2025-02-02","Present"),
        (5,"2025-02-01","Present"),(5,"2025-02-02","Absent")
    ]
    cur.executemany("INSERT INTO employees VALUES (?,?,?,?);", employees)
    cur.executemany("INSERT INTO attendance VALUES (?,?,?);", attendance)
    conn.commit()
    return conn

def test_sql_query_results():
    sql = _extract_sql_from_main()
    conn = _build_test_db()
    df = pd.read_sql_query(sql, conn)
    conn.close()

    expected = pd.DataFrame({
        "emp_name": ["Asha", "Vijay", "Rina", "Karan", "Meera"],
        "department": ["HR", "IT", "Finance", "IT", "HR"],
        "base_salary": [30000.0, 40000.0, 35000.0, 38000.0, 32000.0],
        "days_present": [1, 2, 2, 1, 1],
        "total_days": [2, 2, 2, 2, 2]
    })

    # Validate structure
    expected_cols = list(expected.columns)
    actual_cols = list(df.columns)
    assert expected_cols == actual_cols, (
        f"Column mismatch.\nExpected: {expected_cols}\nActual: {actual_cols}"
    )

    # Validate record count
    assert len(df) == len(expected), (
        f"Row count mismatch.\nExpected {len(expected)} rows, got {len(df)}."
    )

    # Validate values
    df_sorted = df.sort_values("emp_name").reset_index(drop=True)
    expected_sorted = expected.sort_values("emp_name").reset_index(drop=True)

    for i, (exp_row, act_row) in enumerate(zip(expected_sorted.itertuples(index=False), df_sorted.itertuples(index=False))):
        for col in expected.columns:
            exp_val = getattr(exp_row, col)
            act_val = getattr(act_row, col)
            assert exp_val == pytest.approx(act_val, rel=1e-2), (
                f"Mismatch at row {i} column '{col}'.\nExpected: {exp_val}\nActual: {act_val}"
            )
