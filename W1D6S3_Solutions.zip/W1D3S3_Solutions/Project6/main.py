# main.py – Employee Attendance & Payroll (Fixed)
import sqlite3
import pandas as pd

conn = sqlite3.connect(":memory:")
cur = conn.cursor()

cur.executescript("""
CREATE TABLE employees(
    emp_id INTEGER PRIMARY KEY,
    emp_name TEXT,
    department TEXT,
    base_salary REAL
);
CREATE TABLE attendance(
    emp_id INTEGER,
    work_date DATE,
    status TEXT,
    FOREIGN KEY(emp_id) REFERENCES employees(emp_id)
);
""")

employees = [
    (1,"Asha","HR",30000),
    (2,"Vijay","IT",40000),
    (3,"Rina","Finance",35000),
    (4,"Karan","IT",38000),
    (5,"Meera","HR",32000)
]
attendance = [
    (1,"2025-02-01","Present"),(1,"2025-02-02","Absent"),
    (2,"2025-02-01","Present"),(2,"2025-02-02","Present"),
    (3,"2025-02-01","Present"),(3,"2025-02-02","Present"),
    (4,"2025-02-01","Absent"),(4,"2025-02-02","Present"),
    (5,"2025-02-01","Present"),(5,"2025-02-02","Absent")
]
cur.executemany("INSERT INTO employees VALUES (?,?,?,?);", employees)
cur.executemany("INSERT INTO attendance VALUES (?,?,?);", attendance)
conn.commit()

# include base_salary in query
sql_query = """
SELECT e.emp_name,
       e.department,
       e.base_salary,
       SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS days_present,
       COUNT(*) AS total_days
FROM employees e
JOIN attendance a ON e.emp_id=a.emp_id
GROUP BY e.emp_name, e.department, e.base_salary;
"""
df = pd.read_sql_query(sql_query, conn)

# Python-level calculations
df["attendance_pct"] = round(df["days_present"] / df["total_days"] * 100, 2)
df["deduction"] = (df["total_days"] - df["days_present"]) * 500
df["net_salary"] = df["base_salary"] - df["deduction"]

print(df[["emp_name", "department", "attendance_pct", "net_salary"]])

conn.close()
