import pytest
import sqlite3
import pandas as pd
import ast
from pathlib import Path
from main import create_and_populate_database
from solution import query

HARD_CODE_LITERALS = {
    "John Smith", "David Lee", "Grace Kim", "Daniel Johnson",
    "Alice Brown", "Sophia Wilson", "Ethan Patel", "Michael Chen",
    "Olivia Martinez", "Emily Davis", 215.0, 190.0, 170.0, 155.0
}

def _assert_not_hardcoded_solution():
    p = Path("solution.py")
    assert p.exists(), "solution.py not found in project root."
    src = p.read_text(encoding="utf-8")
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in solution.py: {e}")
    found_literals = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant):
            found_literals.add(node.value)
    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded output literals detected in solution.py: {sorted(overlap)}")

@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded_solution()

def test_solution_query_correctness():
    conn = sqlite3.connect(":memory:")
    create_and_populate_database(conn)
    df = pd.read_sql_query(query, conn)
    conn.close()

    expected_cols = {
        "customer_name",
        "total_orders",
        "total_spent",
        "avg_order_value",
        "spend_rank",
        "order_activity_level",
    }
    actual_cols = set(df.columns)
    assert actual_cols == expected_cols, f"Column mismatch. Expected: {expected_cols}, Actual: {actual_cols}"

    assert not df.empty, "The query returned no rows. Expected top 10 ranked customers."

    row_count = len(df)
    assert row_count == 10, f"Expected top 10 customers only, but got {row_count}"

    ranks = df["spend_rank"].tolist()
    expected_ranks = list(range(1, 11))
    assert ranks == expected_ranks, (
        f"Spend ranks not sequential from 1 to 10.\nExpected: {expected_ranks}\nActual: {ranks}"
    )

    top_spent = df.iloc[0]["total_spent"]
    last_spent = df.iloc[-1]["total_spent"]
    assert top_spent >= last_spent, (
        f"Ranking error. The top customer's total_spent ({top_spent}) "
        f"should be greater than or equal to the last customer's total_spent ({last_spent})."
    )

    avg_order_values_valid = df["avg_order_value"].between(20, 80).all()
    assert avg_order_values_valid, (
        f"Average order values out of realistic range (20–80).\n"
        f"Actual values:\n{df[['customer_name','avg_order_value']]}"
    )

    unique_customers = df["customer_name"].nunique()
    assert unique_customers == 10, (
        f"Duplicate or missing customers detected in result. Expected 10 unique, found {unique_customers}."
    )

    activity_levels = set(df["order_activity_level"])
    allowed_levels = {"Above Average Activity", "Below Average Activity"}
    unexpected_levels = activity_levels - allowed_levels
    assert not unexpected_levels, (
        f"Unexpected values in order_activity_level column.\n"
        f"Allowed: {allowed_levels}\nFound: {activity_levels}"
    )

    num_above_avg = (df["order_activity_level"] == "Above Average Activity").sum()
    assert num_above_avg >= 5, (
        f"At least half of the top customers should be 'Above Average Activity'. "
        f"Found only {num_above_avg} such entries."
    )

    for col in ["total_orders", "total_spent", "avg_order_value", "spend_rank"]:
        assert pd.api.types.is_numeric_dtype(df[col]), (
            f"Invalid data type for column '{col}'. Expected numeric, Actual: {df[col].dtype}"
        )

    for col in ["customer_name", "order_activity_level"]:
        assert pd.api.types.is_string_dtype(df[col]), (
            f"Invalid data type for column '{col}'. Expected text, Actual: {df[col].dtype}"
        )

    missing_values = df.isnull().sum().sum()
    assert missing_values == 0, (
        f"Result contains missing/null values in output. Total missing count: {missing_values}"
    )
