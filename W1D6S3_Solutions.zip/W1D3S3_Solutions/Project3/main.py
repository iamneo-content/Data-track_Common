# ==================================
# DO NOT MODIFY/EDIT BELOW THIS LINE
# ==================================
import sqlite3
import pandas as pd
from solution import query


def create_and_populate_database(connection):
    """Create and populate the customers, orders, and order_items tables."""
    cursor = connection.cursor()

    cursor.executescript("""
    DROP TABLE IF EXISTS customers;
    DROP TABLE IF EXISTS orders;
    DROP TABLE IF EXISTS order_items;

    CREATE TABLE customers (
        customer_id INTEGER PRIMARY KEY,
        customer_name TEXT,
        city TEXT,
        signup_date DATE
    );

    CREATE TABLE orders (
        order_id INTEGER PRIMARY KEY,
        customer_id INTEGER,
        order_date DATE,
        order_status TEXT,
        FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
    );

    CREATE TABLE order_items (
        item_id INTEGER PRIMARY KEY,
        order_id INTEGER,
        product_name TEXT,
        category TEXT,
        quantity INTEGER,
        unit_price REAL,
        FOREIGN KEY(order_id) REFERENCES orders(order_id)
    );
    """)

    # -----------------------------------
    # Insert realistic customers (~20)
    # -----------------------------------
    cursor.executescript("""
    INSERT INTO customers VALUES
    (1, 'John Smith', 'New York', '2022-03-15'),
    (2, 'Alice Brown', 'Chicago', '2022-05-22'),
    (3, 'David Lee', 'San Francisco', '2023-01-12'),
    (4, 'Sophia Wilson', 'Los Angeles', '2023-03-10'),
    (5, 'Michael Chen', 'Boston', '2021-09-18'),
    (6, 'Emily Davis', 'Austin', '2022-07-25'),
    (7, 'Daniel Johnson', 'Seattle', '2022-08-03'),
    (8, 'Olivia Martinez', 'Denver', '2023-02-20'),
    (9, 'Ethan Patel', 'New York', '2022-11-05'),
    (10, 'Grace Kim', 'Chicago', '2022-12-19');
    """)

    # -----------------------------------
    # Insert orders (~40)
    # -----------------------------------
    cursor.executescript("""
    INSERT INTO orders VALUES
    (1, 1, '2025-01-05', 'Delivered'),
    (2, 1, '2025-01-20', 'Delivered'),
    (3, 2, '2025-01-09', 'Delivered'),
    (4, 3, '2025-01-15', 'Delivered'),
    (5, 3, '2025-01-25', 'Delivered'),
    (6, 4, '2025-02-01', 'Delivered'),
    (7, 5, '2025-02-03', 'Delivered'),
    (8, 6, '2025-02-05', 'Delivered'),
    (9, 7, '2025-02-10', 'Delivered'),
    (10, 8, '2025-02-12', 'Delivered'),
    (11, 9, '2025-02-14', 'Delivered'),
    (12, 10, '2025-02-15', 'Delivered'),
    (13, 2, '2025-02-18', 'Delivered'),
    (14, 3, '2025-02-20', 'Delivered'),
    (15, 4, '2025-02-22', 'Delivered'),
    (16, 5, '2025-02-25', 'Delivered'),
    (17, 6, '2025-02-27', 'Delivered'),
    (18, 7, '2025-03-01', 'Delivered'),
    (19, 8, '2025-03-03', 'Delivered'),
    (20, 9, '2025-03-05', 'Delivered'),
    (21, 10, '2025-03-07', 'Delivered'),
    (22, 1, '2025-03-10', 'Delivered'),
    (23, 2, '2025-03-12', 'Delivered'),
    (24, 3, '2025-03-14', 'Delivered'),
    (25, 4, '2025-03-15', 'Delivered'),
    (26, 5, '2025-03-17', 'Delivered'),
    (27, 6, '2025-03-20', 'Delivered'),
    (28, 7, '2025-03-22', 'Delivered'),
    (29, 8, '2025-03-23', 'Delivered'),
    (30, 9, '2025-03-24', 'Delivered'),
    (31, 10, '2025-03-25', 'Delivered'),
    (32, 2, '2025-03-26', 'Delivered'),
    (33, 3, '2025-03-27', 'Delivered'),
    (34, 4, '2025-03-28', 'Delivered'),
    (35, 5, '2025-03-29', 'Delivered'),
    (36, 6, '2025-03-30', 'Delivered'),
    (37, 7, '2025-03-31', 'Delivered'),
    (38, 8, '2025-03-31', 'Delivered'),
    (39, 9, '2025-03-31', 'Delivered'),
    (40, 10, '2025-03-31', 'Delivered');
    """)

    # -----------------------------------
    # Insert order items (~100)
    # -----------------------------------
    cursor.executescript("""
    INSERT INTO order_items VALUES
    (1, 1, 'Wireless Mouse', 'Electronics', 1, 25.0),
    (2, 1, 'Laptop Sleeve', 'Accessories', 1, 30.0),
    (3, 2, 'Keyboard', 'Electronics', 1, 45.0),
    (4, 3, 'Bluetooth Speaker', 'Electronics', 1, 55.0),
    (5, 4, 'Desk Lamp', 'Home', 2, 35.0),
    (6, 5, 'USB Cable', 'Accessories', 3, 10.0),
    (7, 6, 'Notebook', 'Stationery', 4, 5.0),
    (8, 7, 'Pen Set', 'Stationery', 5, 8.0),
    (9, 8, 'Coffee Mug', 'Home', 2, 12.0),
    (10, 9, 'Wireless Charger', 'Electronics', 1, 40.0),
    (11, 10, 'Mouse Pad', 'Accessories', 2, 10.0),
    (12, 11, 'USB-C Hub', 'Electronics', 1, 35.0),
    (13, 12, 'Photo Frame', 'Home', 3, 15.0),
    (14, 13, 'HDMI Cable', 'Electronics', 2, 10.0),
    (15, 14, 'Wall Clock', 'Home', 1, 25.0),
    (16, 15, 'Desk Organizer', 'Home', 2, 20.0),
    (17, 16, 'Sticky Notes', 'Stationery', 5, 3.0),
    (18, 17, 'Power Bank', 'Electronics', 1, 50.0),
    (19, 18, 'Earphones', 'Electronics', 2, 30.0),
    (20, 19, 'Marker Set', 'Stationery', 4, 4.0),
    (21, 20, 'Notebook', 'Stationery', 6, 5.0),
    (22, 21, 'Laptop Stand', 'Accessories', 1, 40.0),
    (23, 22, 'Keyboard', 'Electronics', 2, 45.0),
    (24, 23, 'Coffee Mug', 'Home', 3, 12.0),
    (25, 24, 'USB Cable', 'Accessories', 4, 10.0),
    (26, 25, 'Desk Lamp', 'Home', 1, 35.0),
    (27, 26, 'Mouse Pad', 'Accessories', 2, 10.0),
    (28, 27, 'Wireless Mouse', 'Electronics', 1, 25.0),
    (29, 28, 'Keyboard', 'Electronics', 1, 45.0),
    (30, 29, 'Notebook', 'Stationery', 4, 5.0),
    (31, 30, 'HDMI Cable', 'Electronics', 2, 10.0),
    (32, 31, 'Laptop Stand', 'Accessories', 1, 40.0),
    (33, 32, 'Photo Frame', 'Home', 2, 15.0),
    (34, 33, 'Power Bank', 'Electronics', 1, 50.0),
    (35, 34, 'Coffee Mug', 'Home', 3, 12.0),
    (36, 35, 'Notebook', 'Stationery', 4, 5.0),
    (37, 36, 'Marker Set', 'Stationery', 5, 4.0),
    (38, 37, 'Wall Clock', 'Home', 1, 25.0),
    (39, 38, 'USB-C Hub', 'Electronics', 1, 35.0),
    (40, 39, 'Bluetooth Speaker', 'Electronics', 1, 55.0),
    (41, 40, 'Laptop Sleeve', 'Accessories', 1, 30.0);
    """)

    connection.commit()


def execute_student_query(connection, sql_query):
    """Execute the student's SQL query and display results."""
    print("\nRunning your SQL query...")
    try:
        result_df = pd.read_sql_query(sql_query, connection)
        print("\nQuery Result:")
        print(result_df)
    except Exception as error:
        print("\nError executing your query:")
        print(error)


def main():
    """Main entry point for the E-Commerce Insights scenario."""
    connection = sqlite3.connect(":memory:")
    create_and_populate_database(connection)
    execute_student_query(connection, query)
    connection.close()


if __name__ == "__main__":
    main()
