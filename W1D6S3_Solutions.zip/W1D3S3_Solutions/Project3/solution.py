query = """
-- Task: E-Commerce Customer Performance Dashboard
-- Objective:
-- Find top customers by total spending, their average order value,
-- and highlight how many orders each placed compared to the average.

WITH customer_orders AS (
    SELECT
        c.customer_id,
        c.customer_name,
        COUNT(DISTINCT o.order_id) AS total_orders,
        ROUND(SUM(oi.quantity * oi.unit_price), 2) AS total_spent
    FROM customers c
    JOIN orders o
        ON c.customer_id = o.customer_id
    JOIN order_items oi
        ON o.order_id = oi.order_id
    GROUP BY c.customer_id, c.customer_name
),
overall_stats AS (
    SELECT
        ROUND(AVG(total_spent), 2) AS avg_spending,
        ROUND(AVG(total_orders), 2) AS avg_orders
    FROM customer_orders
),
ranked_customers AS (
    SELECT
        customer_id,
        customer_name,
        total_orders,
        total_spent,
        ROUND(total_spent / total_orders, 2) AS avg_order_value,
        RANK() OVER (ORDER BY total_spent DESC) AS spend_rank
    FROM customer_orders
)
SELECT
    r.customer_name,
    r.total_orders,
    r.total_spent,
    r.avg_order_value,
    r.spend_rank,
    CASE
        WHEN r.total_orders >= (SELECT avg_orders FROM overall_stats)
             THEN 'Above Average Activity'
        ELSE 'Below Average Activity'
    END AS order_activity_level
FROM ranked_customers r
WHERE r.spend_rank <= 10
ORDER BY r.spend_rank;
"""
