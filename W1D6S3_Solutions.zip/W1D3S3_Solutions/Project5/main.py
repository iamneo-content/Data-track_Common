# main.py  –  Bookstore Inventory & Sales
import sqlite3
import pandas as pd

conn = sqlite3.connect(":memory:")
cur = conn.cursor()

cur.executescript("""
CREATE TABLE books(
    book_id INTEGER PRIMARY KEY,
    title TEXT,
    genre TEXT,
    price REAL,
    stock INTEGER
);
CREATE TABLE sales(
    sale_id INTEGER PRIMARY KEY,
    book_id INTEGER,
    quantity INTEGER,
    sale_date DATE,
    FOREIGN KEY(book_id) REFERENCES books(book_id)
);
""")

books = [
    (1,"Python Basics","Programming",30.0,6),
    (2,"Data Science 101","Programming",45.0,4),
    (3,"Digital Marketing","Marketing",25.0,7),
    (4,"Finance Essentials","Finance",40.0,3),
    (5,"Design Thinking","Creativity",35.0,5)
]
sales = [
    (1,1,2,"2025-01-05"),
    (2,2,1,"2025-01-06"),
    (3,3,3,"2025-01-07"),
    (4,4,2,"2025-01-08"),
    (5,5,1,"2025-01-09")
]
cur.executemany("INSERT INTO books VALUES (?,?,?,?,?);", books)
cur.executemany("INSERT INTO sales VALUES (?,?,?,?);", sales)
conn.commit()

sql_query = """
SELECT b.genre,
       SUM(s.quantity*b.price) AS total_revenue,
       SUM(s.quantity) AS total_sold
FROM books b JOIN sales s ON b.book_id=s.book_id
GROUP BY b.genre
ORDER BY total_revenue DESC;
"""
df = pd.read_sql_query(sql_query, conn)
print("Revenue by Genre:\n", df)

cur.execute("UPDATE books SET stock = stock - 1 WHERE book_id = 2;")
conn.commit()

stock_df = pd.read_sql_query("SELECT title,stock FROM books;", conn)
print("\nUpdated Stock:\n", stock_df)

conn.close()
