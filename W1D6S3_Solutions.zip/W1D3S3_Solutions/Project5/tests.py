import pytest
import sqlite3
import re
from pathlib import Path

def _extract_sql_from_main():
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    text = p.read_text(encoding="utf-8")
    match = re.search(r'sql_query\s*=\s*("""|\'\'\')(.*?)\1', text, re.DOTALL)
    assert match, "sql_query not found in main.py."
    return match.group(2).strip()

def _build_test_db():
    conn = sqlite3.connect(":memory:")
    cur = conn.cursor()
    cur.executescript("""
    CREATE TABLE books(
        book_id INTEGER PRIMARY KEY,
        title TEXT,
        genre TEXT,
        price REAL,
        stock INTEGER
    );
    CREATE TABLE sales(
        sale_id INTEGER PRIMARY KEY,
        book_id INTEGER,
        quantity INTEGER,
        sale_date DATE,
        FOREIGN KEY(book_id) REFERENCES books(book_id)
    );
    """)
    books = [
        (1,"Python Basics","Programming",30.0,6),
        (2,"Data Science 101","Programming",45.0,4),
        (3,"Digital Marketing","Marketing",25.0,7),
        (4,"Finance Essentials","Finance",40.0,3),
        (5,"Design Thinking","Creativity",35.0,5)
    ]
    sales = [
        (1,1,2,"2025-01-05"),
        (2,2,1,"2025-01-06"),
        (3,3,3,"2025-01-07"),
        (4,4,2,"2025-01-08"),
        (5,5,1,"2025-01-09")
    ]
    cur.executemany("INSERT INTO books VALUES (?,?,?,?,?);", books)
    cur.executemany("INSERT INTO sales VALUES (?,?,?,?);", sales)
    conn.commit()
    return conn

def test_sql_and_stock_results():
    sql = _extract_sql_from_main()
    conn = _build_test_db()
    cur = conn.cursor()

    # Run student's SQL query
    cur.execute(sql)
    actual_rows = cur.fetchall()
    actual_headers = [desc[0] for desc in cur.description]

    expected_headers = ["genre", "total_revenue", "total_sold"]
    assert actual_headers == expected_headers, (
        f"Column mismatch.\nExpected: {expected_headers}\nActual: {actual_headers}"
    )

    expected_data = [
        ("Programming", 105.0, 3),
        ("Finance", 80.0, 2),
        ("Marketing", 75.0, 3),
        ("Creativity", 35.0, 1)
    ]

    assert len(actual_rows) == len(expected_data), (
        f"Row count mismatch.\nExpected {len(expected_data)} rows, got {len(actual_rows)}."
    )

    for i, (exp_row, act_row) in enumerate(zip(expected_data, actual_rows)):
        for j, (exp_val, act_val) in enumerate(zip(exp_row, act_row)):
            assert exp_val == pytest.approx(act_val, rel=1e-2), (
                f"Row {i} mismatch in column {expected_headers[j]}.\nExpected: {exp_val}\nActual: {act_val}"
            )

    # Update query and verify stock
    cur.execute("UPDATE books SET stock = stock - 1 WHERE book_id = 2;")
    conn.commit()

    cur.execute("SELECT title, stock FROM books ORDER BY book_id;")
    stock_rows = cur.fetchall()
    expected_stock = [
        ("Python Basics", 6),
        ("Data Science 101", 3),
        ("Digital Marketing", 7),
        ("Finance Essentials", 3),
        ("Design Thinking", 5)
    ]

    assert stock_rows == expected_stock, (
        f"Stock data mismatch.\nExpected:\n{expected_stock}\n\nActual:\n{stock_rows}"
    )

    conn.close()
