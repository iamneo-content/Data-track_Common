# import pandas as pd

# def combine_department_reports(csv_files):
#     combined_frames = []

#     for file_path in csv_files:
#         df = pd.read_csv(file_path)
#         df = df.copy()
#         month_name = file_path.replace(".csv", "")
#         df["month"] = month_name
#         combined_frames.append(df)

#     combined_df = pd.concat(combined_frames, ignore_index=True)
#     combined_df = combined_df.sort_values(["dept_id", "month"]).reset_index(drop=True)
#     return combined_df

# if __name__ == "__main__":
#     result_cod1 = combine_department_reports(["2025_01.csv", "2025_02.csv", "2025_03.csv"])
#     print(result_cod1)



import pandas as pd

def combine_department_reports(csv_files: list[str]) -> pd.DataFrame:
    """
    Combine multiple monthly department CSV reports into a single consolidated DataFrame for year-to-date reporting.

    Parameters:
        csv_files (list[str]): List of CSV filenames representing monthly reports.

    Returns:
        pd.DataFrame: Consolidated DataFrame with an additional 'month' column.
    """
    frames = []
    for file in csv_files:
        # Infer the month from the filename (e.g., "2025_01.csv" ⇒ "2025_01")
        month = file.replace('.csv', '')
        df = pd.read_csv(file)
        df['month'] = month
        frames.append(df)
    # Concatenate all DataFrames vertically
    combined = pd.concat(frames, ignore_index=True)
    # Sort by dept_id and month (lexicographical order for month)
    combined = combined.sort_values(by=['dept_id', 'month'], ascending=[True, True])
    # Reset index for clean DataFrame
    combined = combined.reset_index(drop=True)
    return combined

if __name__ == "__main__":
    # Example usage
    test_files = ["2025_01.csv", "2025_02.csv", "2025_03.csv"]
    combined_df = combine_department_reports(test_files)
    print(combined_df)
