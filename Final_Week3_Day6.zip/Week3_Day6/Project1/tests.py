# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main


FUNCTIONS = ["combine_department_reports"]
HARD_CODE_LITERALS = {
    "Sales", "Marketing", "HR", "Finance", "IT", "Operations",
    101, 102, 103, 104, 105, 106,
    320000, 210000, 95000, 150000, 180000,
    340000, 220000, 97000, 152000, 160000,
    355000, 100000, 155000, 195000, 172000,
    10, 11, 12, 15, 16, 17, 7, 8, 9
}

ELIF_MAX = 6


def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root; ensure the file is named 'main.py'."
    return p.read_text(encoding="utf-8")


def _get_function_node(tree: ast.AST, name: str) -> ast.FunctionDef | None:
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        fn_node = _get_function_node(tree, fn)
        assert fn_node is not None, f"Required function `{fn}` is missing in main.py."
        func_bodies.append(fn_node)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > 6:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit 6)")


@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()


def _write_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p

def test_combines_three_months(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "2025_01.csv", [{"dept_id": 101, "dept_name": "Sales", "headcount": 15, "monthly_expense": 320000}])
    _write_csv(tmp_path, "2025_02.csv", [{"dept_id": 101, "dept_name": "Sales", "headcount": 16, "monthly_expense": 340000}])
    _write_csv(tmp_path, "2025_03.csv", [{"dept_id": 101, "dept_name": "Sales", "headcount": 17, "monthly_expense": 355000}])
    got = main.combine_department_reports(["2025_01.csv", "2025_02.csv", "2025_03.csv"])
    assert len(got) == 3, f"Combined DataFrame should include all rows from all files. Got={len(got)}"


def test_month_column_added_correctly(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "2025_01.csv", [{"dept_id": 101, "dept_name": "Sales", "headcount": 10, "monthly_expense": 100}])
    _write_csv(tmp_path, "2025_02.csv", [{"dept_id": 102, "dept_name": "Marketing", "headcount": 12, "monthly_expense": 200}])
    got = main.combine_department_reports(["2025_01.csv", "2025_02.csv"])
    assert "month" in got.columns, "Missing 'month' column."
    assert set(got["month"]) == {"2025_01", "2025_02"}, f"Month names incorrect. Got={set(got['month'])}"


def test_output_sorted_by_deptid_then_month(monkeypatch, tmp_path):
    """
    Expect sort by dept_id (asc), then month (asc lexicographically).
    Data:
      - 2025_01 has dept_id=102
      - 2025_02 has dept_id=101
    Sorted result should have (101, '2025_02') before (102, '2025_01').
    """
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "2025_01.csv", [{"dept_id": 102, "dept_name": "Marketing", "headcount": 11, "monthly_expense": 200}])
    _write_csv(tmp_path, "2025_02.csv", [{"dept_id": 101, "dept_name": "Sales", "headcount": 15, "monthly_expense": 300}])
    got = main.combine_department_reports(["2025_01.csv", "2025_02.csv"])
    actual = list(zip(got["dept_id"], got["month"]))
    expected = [(101, "2025_02"), (102, "2025_01")]
    assert actual == expected, f"DataFrame should be sorted by dept_id and month. Expected={expected}, Got={actual}"


def test_includes_all_columns(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "2025_01.csv", [{"dept_id": 101, "dept_name": "Sales", "headcount": 10, "monthly_expense": 100}])
    got = main.combine_department_reports(["2025_01.csv"])
    expected_cols = {"dept_id", "dept_name", "headcount", "monthly_expense", "month"}
    assert expected_cols.issubset(set(got.columns)), f"Missing expected columns. Got={got.columns.tolist()}"


def test_no_file_mutation(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = [{"dept_id": 101, "dept_name": "Sales", "headcount": 10, "monthly_expense": 100}]
    p = _write_csv(tmp_path, "2025_01.csv", rows)
    before = pd.read_csv(p)
    _ = main.combine_department_reports(["2025_01.csv"])
    after = pd.read_csv(p)
    assert before.equals(after), "Input CSV must not be modified."


def test_handles_missing_department_in_some_months(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "2025_01.csv", [{"dept_id": 101, "dept_name": "Sales", "headcount": 15, "monthly_expense": 320000}])
    _write_csv(tmp_path, "2025_02.csv", [{"dept_id": 102, "dept_name": "Marketing", "headcount": 11, "monthly_expense": 220000}])
    got = main.combine_department_reports(["2025_01.csv", "2025_02.csv"])
    assert 101 in got["dept_id"].values and 102 in got["dept_id"].values, "Should include all departments from all months."


def test_output_is_dataframe(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "2025_01.csv", [{"dept_id": 101, "dept_name": "Sales", "headcount": 10, "monthly_expense": 100}])
    got = main.combine_department_reports(["2025_01.csv"])
    assert isinstance(got, pd.DataFrame), f"Expected pandas DataFrame, got {type(got).__name__}"


def test_row_count_equals_sum_of_all(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "2025_01.csv", [{"dept_id": 101, "dept_name": "Sales", "headcount": 10, "monthly_expense": 100}])
    _write_csv(tmp_path, "2025_02.csv", [{"dept_id": 102, "dept_name": "Marketing", "headcount": 12, "monthly_expense": 200}])
    got = main.combine_department_reports(["2025_01.csv", "2025_02.csv"])
    assert len(got) == 2, f"Row count mismatch. Expected=2, Got={len(got)}"


def test_month_column_string_type(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "2025_01.csv", [{"dept_id": 105, "dept_name": "IT", "headcount": 8, "monthly_expense": 180000}])
    got = main.combine_department_reports(["2025_01.csv"])
    assert pd.api.types.is_string_dtype(got["month"]), f"'month' column must be string dtype. Got={got['month'].dtype}"


def test_multi_dept_multi_month_sorting(monkeypatch, tmp_path):
    """
    Pure logic check: with two months and two departments each, final order must be
    by dept_id, then by month.
    """
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "2025_01.csv", [
        {"dept_id": 101, "dept_name": "Sales", "headcount": 15, "monthly_expense": 300000},
        {"dept_id": 102, "dept_name": "Marketing", "headcount": 11, "monthly_expense": 200000},
    ])
    _write_csv(tmp_path, "2025_02.csv", [
        {"dept_id": 102, "dept_name": "Marketing", "headcount": 12, "monthly_expense": 210000},
        {"dept_id": 101, "dept_name": "Sales", "headcount": 16, "monthly_expense": 310000},
    ])
    got = main.combine_department_reports(["2025_02.csv", "2025_01.csv"])
    actual = list(zip(got["dept_id"], got["month"]))
    expected = [(101, "2025_01"), (101, "2025_02"), (102, "2025_01"), (102, "2025_02")]
    assert actual == expected, f"Sorting across multiple depts/months incorrect. Expected={expected}, Got={actual}"
