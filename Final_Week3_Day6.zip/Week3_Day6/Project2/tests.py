# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["generate_customer_spending_report"]

HARD_CODE_LITERALS = {
    "C001", "C002", "C003", "C004", "C005",
    "Arjun Sharma", "Beena Patel", "Chirag Rao", "Divya Menon", "Ravi Iyer",
    "North", "South", "East", "West",
    "O1001", "O1002", "O1003", "O1004", "O1005", "O1006", "O1007",
    "2025-03-05", "2025-03-06", "2025-03-08", "2025-03-09",
    "2025-03-10", "2025-03-11", "2025-03-12",
    "Laptop", "Mouse", "Smartphone", "Keyboard", "Headphones",
    "Tablet", "Case", "Smartwatch", "Charger", "Monitor", "Router",
    "USB Cable",
    61600.0, 25000.0, 3500.0, 19200.0, 10000.0, 24000.0, 3400.0,
    65100.0, 49000.0, 19200.0, 10000.0, 3400.0
}

ELIF_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root; ensure the file is named 'main.py'."
    return p.read_text(encoding="utf-8")


def _get_function_node(tree: ast.AST, name: str) -> ast.FunctionDef | None:
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        fn_node = _get_function_node(tree, fn)
        assert fn_node is not None, f"Required function `{fn}` is missing in main.py."
        func_bodies.append(fn_node)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > 6:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit 6)")


@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p


def _seed_sample_files(tmp_path: Path):
    customers = [
        {"customer_id": "C001", "customer_name": "Arjun Sharma", "region": "North"},
        {"customer_id": "C002", "customer_name": "Beena Patel", "region": "South"},
        {"customer_id": "C003", "customer_name": "Chirag Rao", "region": "East"},
        {"customer_id": "C004", "customer_name": "Divya Menon", "region": "West"},
        {"customer_id": "C005", "customer_name": "Ravi Iyer", "region": "North"},
    ]
    orders = [
        {"order_id": "O1001", "customer_id": "C001", "order_date": "2025-03-05"},
        {"order_id": "O1002", "customer_id": "C002", "order_date": "2025-03-06"},
        {"order_id": "O1003", "customer_id": "C001", "order_date": "2025-03-08"},
        {"order_id": "O1004", "customer_id": "C003", "order_date": "2025-03-09"},
        {"order_id": "O1005", "customer_id": "C004", "order_date": "2025-03-10"},
        {"order_id": "O1006", "customer_id": "C002", "order_date": "2025-03-11"},
        {"order_id": "O1007", "customer_id": "C005", "order_date": "2025-03-12"},
    ]
    items = [
        {"order_id": "O1001", "product_name": "Laptop", "quantity": 1, "unit_price": 60000},
        {"order_id": "O1001", "product_name": "Mouse", "quantity": 2, "unit_price": 800},
        {"order_id": "O1002", "product_name": "Smartphone", "quantity": 1, "unit_price": 25000},
        {"order_id": "O1003", "product_name": "Keyboard", "quantity": 1, "unit_price": 1500},
        {"order_id": "O1003", "product_name": "Headphones", "quantity": 1, "unit_price": 2000},
        {"order_id": "O1004", "product_name": "Tablet", "quantity": 1, "unit_price": 18000},
        {"order_id": "O1004", "product_name": "Case", "quantity": 1, "unit_price": 1200},
        {"order_id": "O1005", "product_name": "Smartwatch", "quantity": 1, "unit_price": 9000},
        {"order_id": "O1005", "product_name": "Charger", "quantity": 1, "unit_price": 1000},
        {"order_id": "O1006", "product_name": "Monitor", "quantity": 2, "unit_price": 12000},
        {"order_id": "O1007", "product_name": "Router", "quantity": 1, "unit_price": 2500},
        {"order_id": "O1007", "product_name": "USB Cable", "quantity": 3, "unit_price": 300},
    ]

    cf = _write_csv(tmp_path, "customers.csv", customers)
    of = _write_csv(tmp_path, "orders.csv", orders)
    it = _write_csv(tmp_path, "order_items.csv", items)
    return cf, of, it

def test_basic_aggregation_expected_values(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    cf, of, it = _seed_sample_files(tmp_path)
    got = main.generate_customer_spending_report(cf, of, it)

    expected = {
        ("C001", "Arjun Sharma"): {"order_count": 2, "total_spend": 65100.0},
        ("C002", "Beena Patel"):  {"order_count": 2, "total_spend": 49000.0},
        ("C003", "Chirag Rao"):   {"order_count": 1, "total_spend": 19200.0},
        ("C004", "Divya Menon"):  {"order_count": 1, "total_spend": 10000.0},
        ("C005", "Ravi Iyer"):    {"order_count": 1, "total_spend": 3400.0},
    }
    actual = {
        (r["customer_id"], r["customer_name"]): {
            "order_count": int(r["order_count"]), "total_spend": float(r["total_spend"])
        }
        for _, r in got.iterrows()
    }
    assert actual == expected, f"Aggregation mismatch.\nExpected={expected}\nGot={actual}"


def test_sorted_by_total_spend_desc(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    cf, of, it = _seed_sample_files(tmp_path)
    got = main.generate_customer_spending_report(cf, of, it)
    spends = got["total_spend"].tolist()
    assert spends == sorted(spends, reverse=True), "Result must be sorted by total_spend descending."


def test_output_types_and_columns(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    cf, of, it = _seed_sample_files(tmp_path)
    got = main.generate_customer_spending_report(cf, of, it)

    assert isinstance(got, pd.DataFrame), f"Expected DataFrame, got {type(got).__name__}"
    for col in ["customer_id", "customer_name", "order_count", "total_spend"]:
        assert col in got.columns, f"Missing expected column {col}"

    assert pd.api.types.is_integer_dtype(got["order_count"]), "order_count should be integer dtype"
    # Accept numeric dtype (int or float) for total_spend
    assert pd.api.types.is_numeric_dtype(got["total_spend"]), "total_spend should be numeric dtype"


def test_line_total_sum_per_order(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customers.csv", [
        {"customer_id": "C001", "customer_name": "Arjun Sharma", "region": "North"},
    ])
    _write_csv(tmp_path, "orders.csv", [
        {"order_id": "O1", "customer_id": "C001", "order_date": "2025-01-01"},
    ])
    _write_csv(tmp_path, "order_items.csv", [
        {"order_id": "O1", "product_name": "A", "quantity": 3, "unit_price": 100},
        {"order_id": "O1", "product_name": "B", "quantity": 2, "unit_price": 50},
    ])
    got = main.generate_customer_spending_report("customers.csv", "orders.csv", "order_items.csv")
    assert got.loc[0, "order_count"] == 1
    assert got.loc[0, "total_spend"] == pytest.approx(3*100 + 2*50, rel=0, abs=1e-9)


def test_nunique_order_count(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customers.csv", [
        {"customer_id": "C001", "customer_name": "Arjun Sharma", "region": "North"},
    ])
    _write_csv(tmp_path, "orders.csv", [
        {"order_id": "OX", "customer_id": "C001", "order_date": "2025-01-01"},
        {"order_id": "OY", "customer_id": "C001", "order_date": "2025-01-02"},
    ])
    _write_csv(tmp_path, "order_items.csv", [
        {"order_id": "OX", "product_name": "A", "quantity": 1, "unit_price": 100},
        {"order_id": "OX", "product_name": "B", "quantity": 1, "unit_price": 50},
        {"order_id": "OY", "product_name": "C", "quantity": 2, "unit_price": 25},
    ])
    got = main.generate_customer_spending_report("customers.csv", "orders.csv", "order_items.csv")
    assert got.loc[0, "order_count"] == 2
    assert got.loc[0, "total_spend"] == pytest.approx(100 + 50 + 2*25, abs=1e-9)


def test_result_row_count_equals_customer_count(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    cf, of, it = _seed_sample_files(tmp_path)
    got = main.generate_customer_spending_report(cf, of, it)
    customers = pd.read_csv(cf)
    assert len(got) == len(customers), "Row count should equal number of customers."


def test_top_spender_is_first(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    cf, of, it = _seed_sample_files(tmp_path)
    got = main.generate_customer_spending_report(cf, of, it)
    first_row = got.iloc[0]
    assert first_row["customer_id"] == "C001"
    assert first_row["total_spend"] == pytest.approx(65100.0, abs=1e-9)


def test_any_input_file_order_same_output(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    cf, of, it = _seed_sample_files(tmp_path)
    got1 = main.generate_customer_spending_report(cf, of, it)
    # Call again with the same (correct) argument order; output should be identical
    got2 = main.generate_customer_spending_report(cf, of, it)
    pd.testing.assert_frame_equal(got1, got2)


def test_column_order_is_as_expected(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    cf, of, it = _seed_sample_files(tmp_path)
    got = main.generate_customer_spending_report(cf, of, it)
    expected_cols = ["customer_id", "customer_name", "order_count", "total_spend"]
    assert list(got.columns) == expected_cols, f"Unexpected column order. Expected={expected_cols}, Got={list(got.columns)}"


def test_values_for_specific_customer(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    cf, of, it = _seed_sample_files(tmp_path)
    got = main.generate_customer_spending_report(cf, of, it)
    row = got[got["customer_id"] == "C002"].iloc[0]
    assert row["customer_name"] == "Beena Patel"
    assert row["order_count"] == 2
    assert row["total_spend"] == pytest.approx(49000.0, abs=1e-9)
