# import pandas as pd

# def generate_customer_spending_report(customers_file: str, orders_file: str, order_items_file: str) -> pd.DataFrame:
#     customers_df = pd.read_csv(customers_file)
#     orders_df = pd.read_csv(orders_file)
#     items_df = pd.read_csv(order_items_file)

#     merged_orders = customers_df.merge(orders_df, on="customer_id", how="left")
#     merged_data = merged_orders.merge(items_df, on="order_id", how="left")

#     merged_data["line_total"] = merged_data["quantity"] * merged_data["unit_price"]

#     summary_df = (merged_data
#                   .groupby(["customer_id", "customer_name"], dropna=False)
#                   .agg(order_count=("order_id", "nunique"),
#                        total_spend=("line_total", "sum"))
#                   .reset_index())

#     summary_df["order_count"] = summary_df["order_count"].fillna(0).astype(int)
#     summary_df["total_spend"] = summary_df["total_spend"].fillna(0.0)
#     summary_df = summary_df.sort_values("total_spend", ascending=False).reset_index(drop=True)
#     return summary_df

# if __name__ == "__main__":
#     result_cod2 = generate_customer_spending_report("customers.csv", "orders.csv", "order_items.csv")
#     print(result_cod2)

import pandas as pd

def generate_customer_spending_report(customers_file: str,
                                      orders_file: str,
                                      order_items_file: str) -> pd.DataFrame:
    # Load CSVs into DataFrames
    customers = pd.read_csv(customers_file)
    orders = pd.read_csv(orders_file)
    order_items = pd.read_csv(order_items_file)

    # Left join customers to orders
    cust_orders = pd.merge(customers, orders, how='left', on='customer_id')

    # Left join to order_items
    cust_orders_items = pd.merge(cust_orders, order_items, how='left', on='order_id')

    # Calculate line_total (for rows with available quantity & unit_price; NaN means zero spend)
    cust_orders_items['line_total'] = cust_orders_items['quantity'].fillna(0) * cust_orders_items['unit_price'].fillna(0)

    # Group/aggregate required metrics: order_count and total_spend
    summary = (
        cust_orders_items.groupby(['customer_id', 'customer_name'], dropna=False)
        .agg(
            order_count=pd.NamedAgg(column='order_id', aggfunc=lambda x: x.nunique() if x.notnull().any() else 0),
            total_spend=pd.NamedAgg(column='line_total', aggfunc='sum')
        )
        .reset_index()
    )

    # Ensure correct types
    summary['order_count'] = summary['order_count'].astype(int)
    summary['total_spend'] = summary['total_spend'].astype(float)

    # Add zero values for customers with no orders or spend
    summary['order_count'] = summary['order_count'].fillna(0)
    summary['total_spend'] = summary['total_spend'].fillna(0.0)

    # Sort by total_spend descending
    summary = summary.sort_values('total_spend', ascending=False).reset_index(drop=True)

    return summary

if __name__ == "__main__":
    # Example usage
    result = generate_customer_spending_report("customers.csv", "orders.csv", "order_items.csv")
    print(result)
