# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import main

FUNCTIONS = ["transform_product_sales_format"]

HARD_CODE_LITERALS = {
    "north", "south", "east", "west",
    "P001", "P002", "P003", "P004", "P005", "P006", "P007", "P008",
    "P009", "P010", "P011", "P012", "P013", "P014", "P015",
    "Laptop", "Smartphone", "Tablet", "Office Chair", "Desk",
    "Headphones", "Keyboard", "Mouse", "Smartwatch", "Printer",
    "Bookshelf", "Table Lamp", "Power Bank", "Bluetooth Speaker", "Monitor",
    "Electronics", "Furniture", "Accessories",
    60000, 55000, 58000, 61000, 25000, 27000, 26000, 24000,
    18000, 19000, 20000, 17500, 12000, 11000, 11500, 13000
}

ELIF_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root; ensure the file is named 'main.py'."
    return p.read_text(encoding="utf-8")


def _get_function_node(tree: ast.AST, name: str) -> ast.FunctionDef | None:
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    func_bodies = []
    for fn in FUNCTIONS:
        fn_node = _get_function_node(tree, fn)
        assert fn_node is not None, f"Required function `{fn}` is missing in main.py."
        func_bodies.append(fn_node)

    found_literals = set()
    for fn in func_bodies:
        for node in ast.walk(fn):
            if isinstance(node, ast.Constant):
                found_literals.add(node.value)

    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample input/output literals detected inside function bodies: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")

    total_match_cases = 0
    for fn in func_bodies:
        for inner in ast.walk(fn):
            if hasattr(ast, "Match") and isinstance(inner, getattr(ast, "Match")):
                total_match_cases += len(inner.cases)
    if total_match_cases > 6:
        pytest.fail(f"Too many match/case patterns in functions: {total_match_cases} (limit 6)")


@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()


def _write_sales_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p


def _mini_dataset():
    return [
        {"product_id": "P001", "product_name": "Laptop", "category": "Electronics",
         "north": 60000, "south": 55000, "east": 58000, "west": 61000},
        {"product_id": "P004", "product_name": "Office Chair", "category": "Furniture",
         "north": 12000, "south": 11000, "east": 11500, "west": 13000},
    ]


def _regions_from(df: pd.DataFrame):
    return [c for c in df.columns if c not in ("product_id", "product_name", "category")]

def test_returns_two_dataframes_and_types(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    _write_sales_csv(tmp_path, "regional_sales.csv", data)
    got_long, got_wide = main.transform_product_sales_format("regional_sales.csv")
    assert isinstance(got_long, pd.DataFrame) and isinstance(got_wide, pd.DataFrame)


def test_long_shape_is_products_times_regions(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    p = _write_sales_csv(tmp_path, "regional_sales.csv", data)
    wide = pd.read_csv(p)
    R = len(_regions_from(wide))
    P = len(wide)
    got_long, _ = main.transform_product_sales_format("regional_sales.csv")
    assert len(got_long) == P * R
    assert set(got_long.columns) == {"product_id", "product_name", "category", "region", "revenue"}


def test_long_contains_expected_rows_for_one_product(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    _write_sales_csv(tmp_path, "regional_sales.csv", data)
    got_long, _ = main.transform_product_sales_format("regional_sales.csv")
    rows = got_long[got_long["product_id"] == "P001"].sort_values("region")
    exp = {"east": 58000, "north": 60000, "south": 55000, "west": 61000}
    actual = dict(zip(rows["region"].tolist(), rows["revenue"].tolist()))
    assert actual == exp


def test_long_region_labels_match_input_columns(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    p = _write_sales_csv(tmp_path, "regional_sales.csv", data)
    wide = pd.read_csv(p)
    reg = set(_regions_from(wide))
    got_long, _ = main.transform_product_sales_format("regional_sales.csv")
    assert set(got_long["region"].unique()) == reg


def test_pivot_roundtrip_values_equal_original(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    p = _write_sales_csv(tmp_path, "regional_sales.csv", data)
    original = pd.read_csv(p)
    _, got_wide = main.transform_product_sales_format("regional_sales.csv")
    merged = original.merge(
        got_wide, on=["product_id", "product_name", "category"], suffixes=("_orig", "_got")
    )
    for region in _regions_from(original):
        assert (merged[f"{region}_orig"] == merged[f"{region}_got"]).all(), \
            f"Mismatch in region '{region}' after pivot."


def test_wide_has_columns_name_none(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    _write_sales_csv(tmp_path, "regional_sales.csv", data)
    _, got_wide = main.transform_product_sales_format("regional_sales.csv")
    assert got_wide.columns.name is None


def test_wide_index_reset(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    _write_sales_csv(tmp_path, "regional_sales.csv", data)
    _, got_wide = main.transform_product_sales_format("regional_sales.csv")
    assert list(got_wide.index) == list(range(len(got_wide)))


def test_long_revenue_is_numeric(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    _write_sales_csv(tmp_path, "regional_sales.csv", data)
    got_long, _ = main.transform_product_sales_format("regional_sales.csv")
    assert pd.api.types.is_numeric_dtype(got_long["revenue"])


def test_multiple_categories_preserved(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    _write_sales_csv(tmp_path, "regional_sales.csv", data)
    got_long, got_wide = main.transform_product_sales_format("regional_sales.csv")
    for df in (got_long, got_wide):
        cats = set(df["category"].unique())
        assert cats == {"Electronics", "Furniture"}


def test_total_sum_preserved_through_reshape(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    data = _mini_dataset()
    p = _write_sales_csv(tmp_path, "regional_sales.csv", data)
    original = pd.read_csv(p)
    got_long, got_wide = main.transform_product_sales_format("regional_sales.csv")

    regions = _regions_from(original)
    orig_total = original[regions].to_numpy().sum()
    long_total = got_long["revenue"].to_numpy().sum()
    wide_total = got_wide[regions].to_numpy().sum()

    assert long_total == orig_total == wide_total
