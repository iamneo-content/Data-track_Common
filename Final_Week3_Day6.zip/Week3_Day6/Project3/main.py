# import pandas as pd

# def transform_product_sales_format(sales_file):
#     wide_df = pd.read_csv(sales_file)

#     long_df = wide_df.melt(
#         id_vars=["product_id", "product_name", "category"],
#         value_vars=[c for c in wide_df.columns if c not in ("product_id", "product_name", "category")],
#         var_name="region",
#         value_name="revenue"
#     )

#     reshaped_wide = (
#         long_df
#         .pivot_table(
#             index=["product_id", "product_name", "category"],
#             columns="region",
#             values="revenue",
#             aggfunc="sum",
#             fill_value=0
#         )
#         .reset_index()
#     )

#     reshaped_wide.columns.name = None
#     return long_df, reshaped_wide

# if __name__ == "__main__":
#     result_long, result_wide = transform_product_sales_format("regional_sales.csv")
#     print(result_long)
#     print(result_wide)

import pandas as pd

def transform_product_sales_format(sales_file):
    # Read the CSV as wide format
    wide_df = pd.read_csv(sales_file)
    
    # Identifier columns
    id_cols = ['product_id', 'product_name', 'category']
    # All other columns are treated as regions
    region_cols = [col for col in wide_df.columns if col not in id_cols]
    
    # Melt to long format
    long_df = wide_df.melt(
        id_vars=id_cols,
        value_vars=region_cols,
        var_name='region',
        value_name='revenue'
    )
    
    # Pivot to wide format, filling missing revenue with 0
    reshaped_wide = long_df.pivot_table(
        index=id_cols,
        columns='region',
        values='revenue',
        aggfunc='sum',
        fill_value=0
    ).reset_index()
    
    # Remove columns name (if present, avoid group name in columns)
    reshaped_wide.columns.name = None

    return long_df, reshaped_wide

if __name__ == "__main__":
    long_df, reshaped_wide = transform_product_sales_format("regional_sales.csv")
    print(long_df.head())
    print(reshaped_wide.head())
