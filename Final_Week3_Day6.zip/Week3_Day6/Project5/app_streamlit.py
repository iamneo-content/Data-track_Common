import streamlit as st
import main

st.title("Monthly Sales Line Plot")
fig = main.plot_monthly_sales("monthly_sales.csv")
st.pyplot(fig)
