import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import matplotlib
import matplotlib.pyplot as plt
import main

FUNCTIONS = ["plot_monthly_sales"]

HARD_CODE_LITERALS = {
    "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
    25000, 27000, 30000, 28000, 35000, 37000, 36000, 39000, 40000, 42000, 45000, 48000,
}

ELIF_MAX = 6


def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root."
    return p.read_text(encoding="utf-8")


def _get_function_node(tree: ast.AST, name: str):
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def _assert_not_hardcoded() -> None:
    src = _read_source()
    tree = ast.parse(src)
    fn = _get_function_node(tree, FUNCTIONS[0])
    assert fn, f"Function `{FUNCTIONS[0]}` missing."
    found_literals = {n.value for n in ast.walk(fn) if isinstance(n, ast.Constant)}
    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded CSV values found in function: {sorted(overlap)}")
    elif_count = len(re.findall(r"\belif\b", src))
    assert elif_count <= ELIF_MAX, f"Too many elifs ({elif_count}) — simplify logic."


@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()


def _write_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p


def _sample_rows():
    return [
        {"month": m, "sales": s}
        for m, s in zip(
            ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            [25000, 27000, 30000, 28000, 35000, 37000, 36000, 39000, 40000, 42000, 45000, 48000],
        )
    ]


def _horizontal_lines(ax):
    lines = []
    for line in ax.lines:
        ydata = list(line.get_ydata())
        if len(ydata) > 1 and abs(max(ydata) - min(ydata)) < 1e-6:
            lines.append(line)
    return lines


def test_returns_valid_figure(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "monthly_sales.csv", _sample_rows())
    fig = main.plot_monthly_sales("monthly_sales.csv")
    assert isinstance(fig, matplotlib.figure.Figure), (
        f"Expected 'matplotlib.figure.Figure', got '{type(fig).__name__}'."
    )


def test_plot_contains_lines(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "monthly_sales.csv", _sample_rows())
    fig = main.plot_monthly_sales("monthly_sales.csv")
    ax = fig.axes[0]
    assert ax.lines, "Expected at least one line plotted on chart."


def test_avg_line_or_reference_present(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "monthly_sales.csv", _sample_rows())
    ax = main.plot_monthly_sales("monthly_sales.csv").axes[0]
    hlines = _horizontal_lines(ax)
    assert hlines, "No horizontal reference line found — expected average sales marker."


def test_title_descriptive(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "monthly_sales.csv", _sample_rows())
    title = main.plot_monthly_sales("monthly_sales.csv").axes[0].get_title()
    assert any(k in title for k in ["Sales", "Trend", "Monthly"]), (
        f"Title not descriptive enough — got '{title}'."
    )


def test_x_and_y_labels_present(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "monthly_sales.csv", _sample_rows())
    ax = main.plot_monthly_sales("monthly_sales.csv").axes[0]
    assert ax.get_xlabel(), f"Missing X-axis label, got '{ax.get_xlabel()}'."
    assert ax.get_ylabel(), f"Missing Y-axis label, got '{ax.get_ylabel()}'."


def test_legend_is_visible(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "monthly_sales.csv", _sample_rows())
    ax = main.plot_monthly_sales("monthly_sales.csv").axes[0]
    legend = ax.get_legend()
    assert legend is not None, "Legend missing — ensure ax.legend() is used."


def test_xticks_reasonable(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "monthly_sales.csv", _sample_rows())
    ax = main.plot_monthly_sales("monthly_sales.csv").axes[0]
    tick_count = len(ax.get_xticks())
    assert tick_count >= 6, f"Too few x-ticks — found {tick_count}, expected at least 6 for months."


def test_multiple_calls_yield_new_figures(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "monthly_sales.csv", _sample_rows())
    f1 = main.plot_monthly_sales("monthly_sales.csv")
    f2 = main.plot_monthly_sales("monthly_sales.csv")
    assert f1 is not f2, "Same figure object reused — should return new Figure per call."
    plt.close(f1)
    plt.close(f2)


def test_datafile_not_modified(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = _sample_rows()
    p = _write_csv(tmp_path, "monthly_sales.csv", rows)
    before = pd.read_csv(p)
    _ = main.plot_monthly_sales("monthly_sales.csv")
    after = pd.read_csv(p)
    assert before.equals(after), "Input CSV was modified during function execution."
