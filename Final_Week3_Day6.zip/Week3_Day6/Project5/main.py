# import pandas as pd
# import matplotlib.pyplot as plt

# def plot_monthly_sales(csv_file):
#     df = pd.read_csv(csv_file)
#     df["growth"] = df["sales"].diff().fillna(0)
#     avg_sales = df["sales"].mean()
#     best_month = df.loc[df["sales"].idxmax(), "month"]
#     df_sorted = df.sort_values("sales")
#     fig, ax = plt.subplots()
#     ax.plot(df["month"], df["sales"], marker="o", color="teal", label="Monthly Sales")
#     ax.axhline(y=avg_sales, color="orange", linestyle="--", label=f"Avg Sales ({int(avg_sales)})")
#     ax.set_title(f"Monthly Sales Trend (Best: {best_month})")
#     ax.set_xlabel("Month")
#     ax.set_ylabel("Sales")
#     ax.legend()
#     ax.grid(True, linestyle="--", alpha=0.5)

#     return fig

# if __name__ == "__main__":
#     figure_cod1 = plot_monthly_sales("monthly_sales.csv")

import pandas as pd
import matplotlib.pyplot as plt

def plot_monthly_sales(csv_file):
    """
    Reads monthly sales from csv_file, computes growth, average, best month,
    and returns a matplotlib Figure with a configured line chart.

    Parameters
    ----------
    csv_file : str
        Path to the monthly_sales.csv file, containing columns 'month', 'sales'.

    Returns
    -------
    matplotlib.figure.Figure
        Figure object containing the line chart.
    """
    # Load the dataset
    df = pd.read_csv(csv_file)
    
    # Helper column: Month-over-month growth (first diff, first row is 0)
    df['growth'] = df['sales'].diff().fillna(0)
    
    # Average monthly sales
    avg_sales = df['sales'].mean()
    
    # Best month: month with maximum sales
    best_month = df.loc[df['sales'].idxmax(), 'month']
    
    # Plotting
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(df['month'], df['sales'], marker='o', label='Monthly Sales')
    
    ax.axhline(avg_sales, color='orange', linestyle='--', linewidth=2,
               label=f'Average Sales ({avg_sales:.2f})')
    
    ax.set_title(f'Monthly Sales Trend (Best Month: {best_month})', fontsize=14)
    ax.set_xlabel('Month')
    ax.set_ylabel('Sales')
    ax.grid(True, linestyle=':', alpha=0.7)
    ax.legend()
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    return fig

if __name__ == "__main__":
    # Example call – change "monthly_sales.csv" to your actual CSV filename
    fig = plot_monthly_sales("monthly_sales.csv")
    fig.show()
