import streamlit as st
import main

st.title("Category-wise Sales Bar Chart")

fig = main.plot_category_sales("category_sales.csv")
st.pyplot(fig)
