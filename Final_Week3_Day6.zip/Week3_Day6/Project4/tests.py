# tests.py
import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import matplotlib
import matplotlib.pyplot as plt
import main

FUNCTIONS = ["plot_category_sales"]

HARD_CODE_LITERALS = {
    "Electronics", "Furniture", "Clothing", "Accessories", "Groceries",
    125000, 92000, 58000, 45000, 78000,
}
ELIF_MAX = 6

def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found in project root; ensure the file is named 'main.py'."
    return p.read_text(encoding="utf-8")


def _get_function_node(tree: ast.AST, name: str):
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def _assert_not_hardcoded() -> None:
    src = _read_source()
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        pytest.fail(f"Syntax error in main.py: {e}")

    fn = _get_function_node(tree, FUNCTIONS[0])
    assert fn is not None, f"Required function `{FUNCTIONS[0]}` is missing in main.py."

    found_literals = {n.value for n in ast.walk(fn) if isinstance(n, ast.Constant)}
    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded sample literals found in function body: {sorted(overlap)}")

    elif_count = len(re.findall(r"\belif\b", src))
    if elif_count > ELIF_MAX:
        pytest.fail(f"Too many 'elif' branches: {elif_count} (limit {ELIF_MAX})")


@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()

def _write_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p


def _sample_rows():
    return [
        {"category": "Electronics", "total_sales": 125000},
        {"category": "Furniture",   "total_sales":  92000},
        {"category": "Clothing",    "total_sales":  58000},
        {"category": "Accessories", "total_sales":  45000},
        {"category": "Groceries",   "total_sales":  78000},
    ]


def _get_bars(ax):
    for c in ax.containers:
        if isinstance(c, matplotlib.container.BarContainer):
            return c
    return None

def test_returns_figure(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "category_sales.csv", _sample_rows())
    fig = main.plot_category_sales("category_sales.csv")
    assert isinstance(fig, matplotlib.figure.Figure), "Function should return a matplotlib Figure."


def test_single_axes_present(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "category_sales.csv", _sample_rows())
    fig = main.plot_category_sales("category_sales.csv")
    assert len(fig.axes) >= 1, "Expected at least one Axes on the Figure."


def test_uses_bar_chart(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "category_sales.csv", _sample_rows())
    fig = main.plot_category_sales("category_sales.csv")
    ax = fig.axes[0]
    bars = _get_bars(ax)
    assert bars is not None, "Expected a bar plot (BarContainer) on the Axes."


def test_bar_count_matches_rows(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = _sample_rows()
    _write_csv(tmp_path, "category_sales.csv", rows)
    fig = main.plot_category_sales("category_sales.csv")
    ax = fig.axes[0]
    bars = _get_bars(ax)
    assert bars is not None, "Expected bar container."
    assert len(bars.patches) == len(rows), "Number of bars should match number of rows in CSV."


def test_bar_heights_follow_total_sales(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = _sample_rows()
    _write_csv(tmp_path, "category_sales.csv", rows)
    fig = main.plot_category_sales("category_sales.csv")
    ax = fig.axes[0]
    bars = _get_bars(ax)
    heights = [b.get_height() for b in bars.patches]
    expected = [r["total_sales"] for r in rows]
    assert heights == expected, f"Bar heights should equal 'total_sales'. Expected {expected}, got {heights}"


def test_xticks_count_matches_rows(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = _sample_rows()
    _write_csv(tmp_path, "category_sales.csv", rows)
    fig = main.plot_category_sales("category_sales.csv")
    ax = fig.axes[0]
    assert len(ax.get_xticks()) >= len(rows), "Expected at least one xtick per bar."


def test_x_tick_labels_exist_but_not_names(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = _sample_rows()
    _write_csv(tmp_path, "category_sales.csv", rows)
    fig = main.plot_category_sales("category_sales.csv")
    ax = fig.axes[0]
    labels = [t.get_text() for t in ax.get_xticklabels()]
    assert len(labels) >= len(rows), "Expected labels for x ticks."


def test_y_grid_enabled_in_some_form(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "category_sales.csv", _sample_rows())
    fig = main.plot_category_sales("category_sales.csv")
    ax = fig.axes[0]
    gridlines = ax.get_ygridlines()
    assert len(gridlines) > 0, "Expected y-axis gridlines to be enabled."


def test_reading_csv_does_not_modify_file(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    rows = _sample_rows()
    p = _write_csv(tmp_path, "category_sales.csv", rows)
    before = pd.read_csv(p)
    _ = main.plot_category_sales("category_sales.csv")
    after = pd.read_csv(p)
    assert before.equals(after), "Input CSV should not be modified by the function."


def test_each_call_returns_fresh_figure(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "category_sales.csv", _sample_rows())
    fig1 = main.plot_category_sales("category_sales.csv")
    fig2 = main.plot_category_sales("category_sales.csv")
    assert fig1 is not fig2, "Each call should return a new Figure."
    plt.close(fig1)
    plt.close(fig2)
