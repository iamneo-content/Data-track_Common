# import pandas as pd
# import matplotlib.pyplot as plt

# def plot_category_sales(csv_file):
#     df = pd.read_csv(csv_file)
#     fig, ax = plt.subplots()
#     ax.bar(df["category"], df["total_sales"], color=["skyblue", "salmon", "limegreen", "violet"])
#     ax.set_title("Category-wise Sales")
#     ax.set_xlabel("Product Category")
#     ax.set_ylabel("Total Sales")
#     ax.tick_params(axis='x', rotation=15)
#     ax.grid(axis="y", linestyle="--", alpha=0.5)
#     return fig

# if __name__ == "__main__":
#     figure_cod2 = plot_category_sales("category_sales.csv")


import pandas as pd
import matplotlib.pyplot as plt

def plot_category_sales(csv_file):
    """
    Reads category sales data from a CSV and returns a Figure with a bar chart.

    Parameters:
        csv_file (str): Path to the category_sales.csv file.

    Returns:
        matplotlib.figure.Figure: A figure containing a single bar chart.
    """
    # Read CSV into DataFrame
    df = pd.read_csv(csv_file)

    # Create the plot
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.bar(df['category'], df['total_sales'])

    # Set title and axis labels
    ax.set_title('Total Sales by Category')
    ax.set_xlabel('Product Category')
    ax.set_ylabel('Total Sales')

    # Rotate x-tick labels slightly for readability
    plt.setp(ax.get_xticklabels(), rotation=20, ha='right')

    # Enable y-axis gridlines
    ax.yaxis.grid(True)

    # Return the Figure object
    return fig

if __name__ == "__main__":
    # Example usage
    # fig = plot_category_sales("category_sales.csv")
    # fig.show()
    pass  # Remove this and uncomment above lines to test with actual file
