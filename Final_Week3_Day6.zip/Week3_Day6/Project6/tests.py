import ast
import re
from pathlib import Path
import pandas as pd
import pytest
import matplotlib
import matplotlib.pyplot as plt
import main


FUNCTIONS = ["plot_purchase_distribution"]

HARD_CODE_LITERALS = {
    "C001", "C002", "C003", "C004", "C005", "C006", "C007", "C008", "C009", "C010",
    "C011", "C012", "C013", "C014", "C015", "C016", "C017", "C018", "C019", "C020",
    "C021", "C022", "C023", "C024", "C025", "C026", "C027", "C028", "C029", "C030",
    "C031", "C032", "C033", "C034", "C035", "C036", "C037", "C038", "C039", "C040",
    "C041", "C042", "C043", "C044", "C045", "C046", "C047", "C048", "C049", "C050",
    750, 980, 1200, 1350, 1600, 1450, 1750, 1900, 2100, 2400,
    2600, 2800, 3100, 3400, 3600, 3800, 4200, 4500, 4700,
    4950, 5200, 5400, 5600, 5800, 6000, 6300, 6500, 6700, 6900,
}

ELIF_MAX = 6


def _read_source() -> str:
    p = Path("main.py")
    assert p.exists(), "main.py not found — ensure it exists in project root."
    return p.read_text(encoding="utf-8")


def _get_function_node(tree: ast.AST, name: str):
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    return None


def _assert_not_hardcoded() -> None:
    src = _read_source()
    tree = ast.parse(src)
    fn = _get_function_node(tree, FUNCTIONS[0])
    assert fn, f"Function `{FUNCTIONS[0]}` missing in main.py."

    found_literals = {n.value for n in ast.walk(fn) if isinstance(n, ast.Constant)}
    overlap = {v for v in found_literals if v in HARD_CODE_LITERALS}
    if overlap:
        pytest.fail(f"Hardcoded test input values found inside function: {sorted(overlap)}")

    elif_count = len(re.findall(r'\belif\b', src))
    assert elif_count <= ELIF_MAX, f"Too many elif branches ({elif_count}) — limit is {ELIF_MAX}."


@pytest.fixture(autouse=True)
def hardcode_guard_before_each_test():
    _assert_not_hardcoded()


def _write_csv(tmp_path: Path, name: str, rows: list[dict]) -> Path:
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p


def _sample_rows():
    return [
        {"customer_id": f"C{i:03d}", "purchase_amount": amt}
        for i, amt in enumerate(
            [750, 980, 1200, 1350, 1600, 1450, 1750, 1900, 2100, 2400,
             2600, 2800, 3100, 3400, 3600, 3800, 4000, 4200, 4500, 4700,
             4950, 5200, 5400, 5600, 5800, 6000, 6300, 6500, 6700, 6900],
            start=1,
        )
    ]


def _vertical_lines(ax):
    lines = []
    for line in ax.lines:
        x = list(line.get_xdata())
        y = list(line.get_ydata())
        if x and len(set(x)) == 1 and len(set(y)) > 1:
            lines.append(line)
    return lines


def test_returns_figure(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customer_purchases.csv", _sample_rows())
    fig = main.plot_purchase_distribution("customer_purchases.csv")
    assert isinstance(fig, matplotlib.figure.Figure), (
        f"Expected return type matplotlib.figure.Figure, got {type(fig).__name__}"
    )


def test_histogram_bars_exist(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customer_purchases.csv", _sample_rows())
    fig = main.plot_purchase_distribution("customer_purchases.csv")
    ax = fig.axes[0]
    bars = [p for p in ax.patches if hasattr(p, 'get_height')]
    assert bars, "Expected histogram bars, found none — check sns.histplot or plt.bar usage."


def test_multiple_vertical_lines_exist(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customer_purchases.csv", _sample_rows())
    fig = main.plot_purchase_distribution("customer_purchases.csv")
    vlines = _vertical_lines(fig.axes[0])
    assert len(vlines) >= 3, (
        f"Expected ≥3 vertical summary lines (avg, min, max), found {len(vlines)}"
    )


def test_kde_curve_present(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customer_purchases.csv", _sample_rows())
    fig = main.plot_purchase_distribution("customer_purchases.csv")
    ax = fig.axes[0]
    kde_lines = [
        line for line in ax.lines
        if len(set(line.get_xdata())) > 5 and len(set(line.get_ydata())) > 5
    ]
    assert kde_lines, "Expected a smooth KDE curve — check sns.histplot(kde=True)."

def test_axis_labels_exist(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customer_purchases.csv", _sample_rows())
    ax = main.plot_purchase_distribution("customer_purchases.csv").axes[0]
    assert ax.get_xlabel(), f"Missing X-axis label, got {ax.get_xlabel()!r}"
    assert ax.get_ylabel(), f"Missing Y-axis label, got {ax.get_ylabel()!r}"


def test_legend_present(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customer_purchases.csv", _sample_rows())
    ax = main.plot_purchase_distribution("customer_purchases.csv").axes[0]
    legend = ax.get_legend()
    assert legend is not None, "Expected legend with summary labels, found None."


def test_gridlines_enabled(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customer_purchases.csv", _sample_rows())
    ax = main.plot_purchase_distribution("customer_purchases.csv").axes[0]
    ygrids = ax.get_ygridlines()
    assert ygrids, "Expected horizontal gridlines for readability, none found."


def test_segmentation_logic_visible_in_title(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customer_purchases.csv", _sample_rows())
    fig = main.plot_purchase_distribution("customer_purchases.csv")
    title = fig.axes[0].get_title()
    assert any(k in title for k in ["Low", "Mid", "High", "Segments"]), (
        f"Segmentation not visible in title. Got title: {title!r}"
    )


def test_multiple_calls_return_new_figures(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    _write_csv(tmp_path, "customer_purchases.csv", _sample_rows())
    f1 = main.plot_purchase_distribution("customer_purchases.csv")
    f2 = main.plot_purchase_distribution("customer_purchases.csv")
    assert f1 is not f2, (
        "Expected new Figure object for each call; same figure reused unexpectedly."
    )
    plt.close(f1)
    plt.close(f2)
