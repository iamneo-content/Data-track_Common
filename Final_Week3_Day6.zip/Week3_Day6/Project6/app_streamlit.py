import streamlit as st
import main

st.title("Purchase Distribution")

fig = main.plot_purchase_distribution("customer_purchases.csv")
st.pyplot(fig)
