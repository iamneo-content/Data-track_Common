# import pandas as pd
# import seaborn as sns
# import matplotlib.pyplot as plt

# def plot_purchase_distribution(csv_file):
#     df = pd.read_csv(csv_file)
#     avg_purchase = df["purchase_amount"].mean()
#     max_purchase = df["purchase_amount"].max()
#     min_purchase = df["purchase_amount"].min()
#     df["segment"] = pd.cut(
#         df["purchase_amount"],
#         bins=[0, 2000, 4000, 7000],
#         labels=["Low Spender", "Mid Spender", "High Spender"]
#     )
#     segment_counts = df["segment"].value_counts().to_dict()
#     fig, ax = plt.subplots()
#     sns.histplot(df["purchase_amount"], bins=12, kde=True, color="lightblue", ax=ax)
#     ax.axvline(avg_purchase, color="orange", linestyle="--", label=f"Average ({int(avg_purchase)})")
#     ax.axvline(max_purchase, color="green", linestyle=":", label=f"Max ({max_purchase})")
#     ax.axvline(min_purchase, color="red", linestyle=":", label=f"Min ({min_purchase})")
#     ax.set_title(f"Customer Purchase Distribution \nSegments: {segment_counts}")
#     ax.set_xlabel("Purchase Amount")
#     ax.set_ylabel("Frequency")
#     ax.legend()
#     return fig

# if __name__ == "__main__":
#     figure_cod3 = plot_purchase_distribution("customer_purchases.csv")

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

def plot_purchase_distribution(csv_file):
    # Read CSV into a DataFrame
    df = pd.read_csv(csv_file)
    
    # Ensure purchase_amount column exists
    if 'purchase_amount' not in df.columns:
        raise ValueError("CSV must contain a 'purchase_amount' column.")
    
    amounts = df['purchase_amount']
    
    # Compute statistics
    min_amt = amounts.min()
    mean_amt = amounts.mean()
    max_amt = amounts.max()
    
    # Bin into segments: Low, Mid, High spenders
    bins = np.linspace(min_amt, max_amt, 4)  # 3 segments
    labels = ['Low', 'Mid', 'High']
    df['segment'] = pd.cut(amounts, bins=bins, labels=labels, include_lowest=True)
    
    # Count in each segment
    seg_counts = df['segment'].value_counts().sort_index()
    seg_dict = {label: int(seg_counts.get(label, 0)) for label in labels}
    
    # Plotting
    fig, ax = plt.subplots(figsize=(8,6))
    sns.histplot(amounts, kde=True, ax=ax, bins=30, color='skyblue', edgecolor='gray')
    
    # Reference lines
    ax.axvline(min_amt, color='green', linestyle='--', linewidth=2, label=f"Min: {min_amt:.2f}")
    ax.axvline(mean_amt, color='orange', linestyle='-', linewidth=2, label=f"Mean: {mean_amt:.2f}")
    ax.axvline(max_amt, color='red', linestyle='-.', linewidth=2, label=f"Max: {max_amt:.2f}")
    
    # Title and axis labels
    ax.set_title(f"Purchase Amount Distribution\nSegment Counts: {seg_dict}", fontsize=14)
    ax.set_xlabel("Purchase Amount")
    ax.set_ylabel("Frequency")
    ax.legend(loc='upper right')
    
    # Horizontal gridlines
    ax.grid(axis='y', linestyle=':', linewidth=0.8)
    
    return fig

if __name__ == "__main__":
    # Example usage (change the file path as needed)
    fig = plot_purchase_distribution("customer_purchases.csv")
    plt.show()
