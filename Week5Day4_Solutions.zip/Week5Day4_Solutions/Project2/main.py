from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, split

# Create SparkSession with streaming enabled
spark = SparkSession.builder \
    .appName("SocketWordCount") \
    .getOrCreate()
    
# Read stream from socket (localhost:9999)
lines = spark.readStream \
    .format("socket") \
    .option("host", "localhost") \
    .option("port", 9999) \
    .load()

# Split lines into words
words = lines.select(explode(split(lines.value, " ")).alias("word"))

# Count occurrences
wordCounts = words.groupBy("word").count()

# Output results continuously to console
query = wordCounts.writeStream \
    .outputMode("complete") \
    .format("console") \
    .option("truncate", "false") \
    .start()

query.awaitTermination()
