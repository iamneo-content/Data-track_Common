from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StringType, TimestampType, StructField

# Create Spark Session
spark = SparkSession.builder.appName("WindowedEventCount").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# Define schema for JSON input
schema = StructType([
    StructField("device", StringType(), True),
    StructField("event", StringType(), True),
    StructField("timestamp", TimestampType(), True)
])

# Read stream from socket
raw_stream = (
    spark.readStream
    .format("socket")
    .option("host", "localhost")
    .option("port", 9999)
    .load()
)

# Parse JSON lines
events_df = (
    raw_stream
    .select(from_json(col("value"), schema).alias("data"))
    .select("data.*")
)

# Apply watermark + 5-minute tumbling window
windowed_counts = (
    events_df
    .withWatermark("timestamp", "10 minutes")
    .groupBy(window(col("timestamp"), "5 minutes"))
    .agg(count("*").alias("event_count"))
)

query = (
    windowed_counts
    .writeStream
    .outputMode("update")
    .format("console")
    .option("truncate", False)
    .start()
)

query.awaitTermination()
