cp storage/employees_1.csv data/employees_trigger1.csv
sleep 10s
cp storage/employees_2.csv data/employees_trigger2.csv
sleep 10s
cp storage/employees_3.csv data/employees_trigger3.csv
sleep 10s
cp storage/employees_4.csv data/employees_trigger4.csv
sleep 10s
cp storage/employees_5.csv data/employees_trigger5.csv
sleep 10s