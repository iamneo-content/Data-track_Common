from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import StructType, StructField, IntegerType, StringType

# Create SparkSession
spark = SparkSession.builder.appName("FileStreamWithOutput").getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# Define schema (required if folder is initially empty)
schema = StructType([
    StructField("id", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("department", StringType(), True),
    StructField("amount", IntegerType(), True)
])

# Read streaming data from CSV directory
df = spark.readStream \
    .format("csv") \
    .option("header", True) \
    .schema(schema) \
    .load("data/")

# Apply simple filter transformation
filtered_df = df.filter(col("amount") > 1000)

# Write stream output to both console and CSV output directory
query_console = filtered_df.writeStream \
    .outputMode("append") \
    .format("console") \
    .option("truncate", False) \
    .start()

query_file = filtered_df.writeStream \
    .outputMode("append") \
    .format("csv") \
    .option("path", "data/output/") \
    .option("checkpointLocation", "data/checkpoints/") \
    .option("header", True) \
    .start()

# Keep the stream running
spark.streams.awaitAnyTermination()
