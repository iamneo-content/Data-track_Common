#!/bin/bash
set -e

echo "======================================"
echo "Stopping Hadoop (HDFS + YARN) & cleanup"
echo "======================================"

# --- Stop HDFS Services ---
echo "[HDFS] Stopping NameNode, DataNode, SecondaryNameNode..."
hdfs --daemon stop namenode || true
hdfs --daemon stop datanode || true
hdfs --daemon stop secondarynamenode || true

# --- Stop YARN Services ---
echo "[YARN] Stopping ResourceManager and NodeManager..."
yarn --daemon stop resourcemanager || true
yarn --daemon stop nodemanager || true

# --- Clean stale PID files ---
echo "[CLEANUP] Removing stale Hadoop PID files from /tmp..."
rm -f /tmp/hadoop-*/*.pid 2>/dev/null || true
rm -f /tmp/hadoop-*.pid 2>/dev/null || true

# --- Kill any leftover Java daemons if still running ---
echo "[CLEANUP] Checking for lingering Hadoop Java processes..."
for svc in NameNode DataNode SecondaryNameNode ResourceManager NodeManager; do
  pid=$(jps | grep "$svc" | awk '{print $1}')
  if [ -n "$pid" ]; then
    echo " - Killing $svc (PID $pid)"
    kill -9 "$pid" 2>/dev/null || true
  fi
done

echo " All Hadoop and YARN services stopped."
echo "======================================"
