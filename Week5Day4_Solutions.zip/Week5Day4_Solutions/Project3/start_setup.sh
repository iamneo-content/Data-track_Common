#!/bin/bash
set -e

echo "======================================"
echo " Starting Hadoop (HDFS + YARN) & Kafka"
echo "======================================"

# --- HDFS Services ---
echo "[HDFS] Starting NameNode, DataNode, and SecondaryNameNode..."
hdfs --daemon start namenode          || true
hdfs --daemon start datanode          || true
hdfs --daemon start secondarynamenode || true

# --- YARN Services ---
echo "[YARN] Starting ResourceManager and NodeManager..."
yarn --daemon start resourcemanager   || true
yarn --daemon start nodemanager       || true
