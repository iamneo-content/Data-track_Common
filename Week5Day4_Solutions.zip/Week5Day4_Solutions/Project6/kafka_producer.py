from kafka import KafkaProducer
import json, time, random

producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

products = ['laptop', 'phone', 'headphones']

print(" Sending random orders to Kafka topic 'orders'...")
while True:
    msg = {"product": random.choice(products), "price": random.randint(100, 2000)}
    producer.send('orders', value=msg)
    print("Produced:", msg)
    time.sleep(1)
