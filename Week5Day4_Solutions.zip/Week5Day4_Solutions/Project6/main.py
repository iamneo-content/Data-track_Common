from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, count
from pyspark.sql.types import StructType, StringType, IntegerType

spark = SparkSession.builder \
    .appName("KafkaOrderAggregator") \
    .getOrCreate()

schema = StructType() \
    .add("product", StringType()) \
    .add("price", IntegerType())

df = (spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "orders")
      .load())

parsed = df.select(from_json(col("value").cast("string"), schema).alias("data")).select("data.*")

agg = parsed.groupBy("product").agg(count("*").alias("order_count"))

query = (agg.writeStream
          .outputMode("complete")
          .format("console")
          .option("truncate", "false")
          .start())

query.awaitTermination()
