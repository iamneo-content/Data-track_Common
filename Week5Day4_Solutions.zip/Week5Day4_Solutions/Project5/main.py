from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col
from pyspark.sql.types import StructType, StringType, DoubleType

# Define schema for JSON messages
schema = StructType() \
    .add("user", StringType()) \
    .add("action", StringType()) \
    .add("ts", DoubleType())

# Initialize Spark session
spark = SparkSession.builder \
    .appName("KafkaConsumer") \
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

# Read stream from Kafka topic
df = (spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "user_logs")
      .option("startingOffsets", "earliest")
      .load())

# Parse JSON values from the Kafka message value field
json_df = (df.select(from_json(col("value").cast("string"), schema).alias("data"))
              .select("data.*"))

# Write stream output to console
query = (json_df.writeStream
         .outputMode("append")
         .format("console")
         .option("truncate", False)
         .start())

query.awaitTermination()
