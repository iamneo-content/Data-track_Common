from kafka import KafkaProducer
import json, time, random
from datetime import datetime

KAFKA_BROKER = "localhost:9092"
TOPIC = "user_logs"

producer = KafkaProducer(
    bootstrap_servers=KAFKA_BROKER,
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

users = ["alice", "bob", "carol", "david", "emma"]
actions = ["login", "browse", "add_to_cart", "purchase", "logout"]

print(f" Producing messages to Kafka topic '{TOPIC}'... (Press Ctrl+C to stop)\n")

try:
    while True:
        msg = {
            "user": random.choice(users),
            "action": random.choice(actions),
            "ts": float(time.time())  
        }
        producer.send(TOPIC, value=msg)
        print(f" Produced: {msg}")
        time.sleep(0.2)  
except KeyboardInterrupt:
    print("\n Stopped producing messages.")
finally:
    producer.close()
