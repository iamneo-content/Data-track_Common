#!/bin/bash
echo " Stopping all services..."

# Stop Kafka
pkill -f kafka.Kafka || true

# Stop YARN
yarn --daemon stop nodemanager || true
yarn --daemon stop resourcemanager || true

# Stop HDFS
hdfs --daemon stop secondarynamenode || true
hdfs --daemon stop datanode || true
hdfs --daemon stop namenode || true

echo " All Hadoop & Kafka processes stopped."
