#!/bin/bash
set -e

echo "======================================"
echo " Starting Hadoop (HDFS + YARN) & Kafka"
echo "======================================"

# --- HDFS Services ---
echo "[HDFS] Starting NameNode, DataNode, and SecondaryNameNode..."
hdfs --daemon start namenode          || true
hdfs --daemon start datanode          || true
hdfs --daemon start secondarynamenode || true

# --- YARN Services ---
echo "[YARN] Starting ResourceManager and NodeManager..."
yarn --daemon start resourcemanager   || true
yarn --daemon start nodemanager       || true

# --- Kafka (KRaft Mode) ---
echo "[Kafka] Formatting storage directories (only if needed)..."
if [ ! -d "/tmp/kraft-combined-logs" ]; then
  $KAFKA_HOME/bin/kafka-storage.sh format \
    --config $KAFKA_HOME/config/kraft/server.properties \
    --cluster-id $($KAFKA_HOME/bin/kafka-storage.sh random-uuid)
  echo "[Kafka] Storage formatted."
else
  echo "[Kafka] Storage already formatted. Skipping..."
fi

echo "[Kafka] Starting Kafka server in KRaft mode..."
$KAFKA_HOME/bin/kafka-server-start.sh -daemon $KAFKA_HOME/config/kraft/server.properties

# --- Verification ---
sleep 5
echo " Verifying running Java daemons..."
jps

echo " Checking important ports..."
ss -lntp | egrep ':(9000|9870|9864|8088|8042|9092)' || true

echo "======================================"
echo " All core services are up and running!"
echo "======================================"
