from kafka import KafkaProducer
import json, time, random
from datetime import datetime

# Connect to Kafka broker
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Define some sample users and pages
users = ["alice", "bob", "maya", "john", "riya"]
pages = ["/home", "/product", "/cart", "/checkout", "/help"]

print(" Streaming page view events to topic 'page_views' ... (Ctrl+C to stop)")

try:
    while True:
        msg = {
            "page": random.choice(pages),
            "user": random.choice(users),
            "timestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")
        }
        producer.send("page_views", value=msg)
        print("Produced:", msg)
        time.sleep(1)
except KeyboardInterrupt:
    print("\n Stopped producing messages.")
finally:
    producer.close()
