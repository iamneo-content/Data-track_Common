from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json, col, window
from pyspark.sql.types import StructType, StringType, TimestampType

spark = SparkSession.builder \
    .appName("KafkaWindowAggregation") \
    .getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

schema = StructType() \
    .add("page", StringType()) \
    .add("user", StringType()) \
    .add("timestamp", StringType())

df = (spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", "localhost:9092")
      .option("subscribe", "page_views")
      .load())

parsed_df = df.select(from_json(col("value").cast("string"), schema).alias("data")).select("data.*")

with_ts = parsed_df.withColumn("timestamp", col("timestamp").cast(TimestampType()))

windowed_counts = (with_ts
    .groupBy(window(col("timestamp"), "10 seconds"), col("page"))
    .count()
    .orderBy(col("window").asc()))

query = (windowed_counts.writeStream
         .outputMode("complete")
         .format("console")
         .option("truncate", "false")
         .start())

query.awaitTermination()
