spark-submit \
  --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0,org.apache.kafka:kafka-clients:3.5.1 \
  --conf "spark.ui.showConsoleProgress=false" \
  --conf "spark.driver.extraJavaOptions=-Dlog4j.rootCategory=ERROR,console" \
  main.py 2>/dev/null
